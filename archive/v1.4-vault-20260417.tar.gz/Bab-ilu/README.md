# Bab-ilu

**为 AI 创作时代设计的美学知识系统。**

当你做 UI 设计、生成图像、生成视频、规划 UX 流程、研究绘画传统时，Bab-ilu 产出**有学术血统的高质量提示词与卡片**——而非通用风格标签堆砌。

---

## 哲学锚点：LLM Wiki 的镜像模式

> **Karpathy 原版 LLM Wiki** —— 用户提问 → LLM 沉积答案成 wiki
> **Bab-ilu** —— 用户策图 → LLM 沉积美学 + 三模态提示词 + 学术溯源

同一个 raw / wiki / schema 三层架构；用户是策展人而非查询者；LLM 负责所有簿记——包括 Warburg 面板维护、Panofsky 三层分析、Getty AAT / Iconclass / 博物馆 ID 解析、跨域交叉链接。

---

## 空 vault 第一步（~3 分钟）

```
1. 把一张参考图粘到 Claude Code 聊天窗口
2. 说: /taste
3. 刷新 Obsidian 查看 wiki/aesthetics/<域>/
   你会看到第一张 Aesthetic 卡 + 三模态提示词 + 学术溯源
```

就这么简单。图像从未离开本地，分析在你的终端跑。

---

## Vault 的 6 个入口

| 入口 | 内容 |
|---|---|
| `wiki/index.md` | **人类可读全内容目录**（Karpathy primitive，推荐首站） |
| `wiki/log.md` | 写入动作时间轴，最新在顶 |
| `wiki/aesthetics/{域}/` | Aesthetic 卡，按 9 域组织（cinema/photo/ui/**ux**/graphic/game/architecture/illustration/**painting**；**粗体**为 v1.4 新增） |
| `wiki/_panels/` | Warburg 跨时代跨媒介面板 |
| `wiki/_refs/` | 权威参考骨架（Warburg/Panofsky/Gombrich 脊椎 + Getty/Iconclass/Met/MoMA 等机构 + 9 域经典著作） |
| `wiki/my/` | 你的笔记命名空间（LLM 只读） |

---

## 7 + 22 个命令

### 核心 7 个（Bab-ilu 原生）

| 命令 | 用途 |
|---|---|
| `/genesis` | 初始化 vault，检测 agent，建立符号链接 |
| `/ingest` | 吞纳任意素材，派发到下游 pipeline |
| `/taste` | **美学考古**，核心交付命令 |
| `/ask` | 自然语言查询 vault |
| `/distill` | 非母语素材的认知重构 |
| `/check` | schema 契约健康审计 |
| `/prompt` | 生成、测试、promote 提示词菜谱 |

### OmegaWiki 继承 22 个（学术 pipeline）

`/research` · `/survey` · `/novelty` · `/ideate` · `/exp-design` · `/exp-run` · `/exp-eval` · `/exp-status` · `/paper-plan` · `/paper-draft` · `/paper-compile` · `/rebuttal` · `/review` · `/refine` · `/prefill` · `/reset` · `/setup` · `/daily-arxiv` · …

v1.4 将它们从"文档声称"落地为"物理安装"，包括 MCP `llm-review` 服务器、`tools/` Python 基础设施（5,079 LOC）、`tests/` 33 个测试、arXiv daily cron。

---

## 学术血统（"重档"承诺）

Bab-ilu 显式继承三条学术脊椎：

- **Aby Warburg** —— Mnemosyne Atlas 1924–29, Nachleben（图像的来世）原则 → 驱动 `taste-lineage` 子代理与 `wiki/_panels/` 的组织
- **Erwin Panofsky** —— 三层图像学（pre-iconographic / iconographic / iconological）→ 映射到 `taste-icon` / `taste-synthesis` 子代理职责与 Aesthetic frontmatter 的 `panofsky_layer` 字段
- **Ernst Gombrich** —— Art and Illusion 1960, Aby Warburg 传记（1970）→ `_refs/_spine/` 理论脊椎

**三大受控词表**：
- **Getty AAT**（~55,000 概念 · 风格/材料/时期）→ `aat_id:` 字段
- **Wikidata**（链接开放数据）→ `wikidata:` 字段
- **Iconclass**（Leiden 1973 · Panofsky 图像学嫡系 · 描绘主题分类）→ `iconclass:` 字段（v1.4 新增）

**博物馆/机构 ID**（按域选填）：Met · MoMA · Cooper Hewitt · Rijks · Tate · NGA · BFI · Magnum · Archnet · RIBA · LoC · GCD · MobyGames · IGDB …

每张 aesthetic / panel **至少有一个权威出处字段非空**——这是 v1.4 的硬规则。

---

## 如果 vault 已有内容

本 vault 当前已有（v0 种子）：

- 6 张 Warburg 面板：[[sublime-solitude]] · [[volumetric-light-descent]] · [[geometric-silence]] · [[wandering-blade]] · [[tactical-feminine]] · [[chromatic-organism]]
- 24 张 Aesthetic 卡横跨 7 域

全目录看 [[wiki/index]]。时间轴看 [[wiki/log]]。

---

## 工作流（Karpathy 六步）

```
genesis → 拖素材到 raw/ → ingest → taste → ask → check
```

每张 Aesthetic 卡结构一致：视觉物证 → 核心观察 → 三模态 Prompts（`ui` / `image` / `video`，v1.4 加 `ux_flow` / `painting` / `motion`）→ 学术溯源（Warburg panel · Panofsky layer · Getty AAT · Iconclass · Wikidata · 机构 ID · 经典著作）。

---

## Obsidian 图谱视图（推荐）

`Cmd + G` 打开 Graph。橙色节点是 Aesthetic，红色节点是 Warburg 面板，蓝色节点是 `_refs/` 权威参考，紫色节点是 `my/` 笔记。成员通过 `exemplifies` / `frames` / `derived_from` 关系连接——100 年 Warburg 图像考古学的数字化形态。

---

## 更多

| 文档 | 用途 |
|---|---|
| `PRD-zh.md` / `PRD.md` | 完整产品规格（用户可读） |
| `schema.md` | 本体论 + 学术锚点 prompt（LLM 读，人类编辑） |
| `CLAUDE.md` | Agent session 开场检查单 |
| `.claude/skills/*.md` | 命令定义 |
| `.claude/agents/*.md` | 子代理定义 |
| `docs/MIGRATIONS/1.3-to-1.4.md` | v1.4 迁移说明 |
| `docs/UPSTREAM.md` | OmegaWiki fork 基线 |

---

*长期主义 · 不可变 raw · LLM 拥有的 wiki · 人类握 schema 与判断。*
