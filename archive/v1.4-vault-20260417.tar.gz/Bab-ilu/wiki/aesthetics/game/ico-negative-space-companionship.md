---
id: ico-negative-space-companionship
type: aesthetic
title: ICO《古堡迷踪》· 负空间陪伴美学
aliases: [ICO, Ueda Fumito, 2001]
aat_id: "300312168"
wikidata: "Q213249"
iconclass: null
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: game
moma_id: "163107"
moby_id: "2714"
igdb_id: "1084"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway, kling]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: inspired_by, target: [[friedrich-monk-by-the-sea]]}
---

## Core observation

上田文人 2001 年 PS2 游戏 *ICO* 是电子游戏第一次成为**美术馆级别**的艺术品（MoMA 2012 收藏）。**通过 UI 删减** 达成的叙事——没有 HUD, 没有对话框, 没有道具栏。Boy 牵着 Girl 的手穿越空无的城堡。

美学原则：**负空间**（negative space）取代内容密度。整个游戏没有 NPC, 极少音乐, 大量默片段落。玩家的陪伴本身就是主要信号。

UI 哲学命题：**让游戏机制消失在环境里**。Don Norman 式"invisible design" 用于游戏——玩家不与"menu"交互, 只与"世界"和"同伴"交互。

Warburg 血缘：[[sublime-solitude]] 面板的游戏节点。Friedrich《海边的僧侣》的 200 年后迭代——人类几何小点对抗浩渺空无，但这里多了**一个小手**。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt

```
[pre-iconographic]
  two small figures (boy + girl) holding hands crossing a massive stone courtyard,
  overgrown with vines, warm hazy sunlight from upper left creating long cast shadows,
  faded desaturated palette (warm ochres + cool grey-blue shadows),
  extreme architectural scale contrast (40m walls, 1m figures).
  soft bloom on sunlit areas; no UI elements, no HUD.
[iconographic]
  PS2-era 3D game screenshot from ICO (2001), Fumito Ueda art direction.
  Iconclass: null (no narrative subject from historical iconography)
[iconological]
  UI-as-absence design: the world swallows the menu. Companionship as primary mechanic.
[lineage]
  Warburg panel: [[sublime-solitude]]
  AAT: [video games (300312168)](http://vocab.getty.edu/aat/300312168)
  MoMA: [video games collection entry](https://www.moma.org/collection/works/163107)
  Canonical: Ueda Fumito interview for MoMA AD collection 2012
  Cross-era: Friedrich *Monk by the Sea* (1810) → BR2049 Las Vegas (2017) → ICO 2001
--ar 16:9
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[sublime-solitude]] — 游戏节点，负空间陪伴美学
- **Panofsky 层**: iconological — UI 作为缺席的哲学立场
- **AAT**: [300312168](http://vocab.getty.edu/aat/300312168) video games
- **MoMA**: [163107 ICO](https://www.moma.org/collection/works/163107) (2012 入藏)
- **MobyGames**: [2714](https://www.mobygames.com/game/2714/)
- **IGDB**: [1084](https://www.igdb.com/games/1084)
- **Wikidata**: [Q213249](https://www.wikidata.org/wiki/Q213249)
- **跨传统**: Friedrich → BR2049 → ICO 同 Pathosformel; 与 [[shadow-of-colossus-scale-sublime]] 为 Ueda 系列兄弟条目
- **参考书架**: [[_refs/_domains/game]] — Schell 2008 *Art of Game Design* 讨论 ICO
<!-- llm:section-end academic-lineage -->
