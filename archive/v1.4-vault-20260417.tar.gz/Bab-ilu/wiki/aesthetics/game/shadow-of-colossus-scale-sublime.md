---
id: shadow-of-colossus-scale-sublime
type: aesthetic
title: 《旺达与巨像》· 尺度崇高
aliases: [Shadow of the Colossus, SotC, 2005, Team Ico]
aat_id: "300312168"
wikidata: "Q131138"
iconclass: null
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: game
moby_id: "19597"
igdb_id: "12"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway, kling]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.95
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: inspired_by, target: [[ico-negative-space-companionship]]}
  - {type: inspired_by, target: [[friedrich-monk-by-the-sea]]}
---

## Core observation

上田文人 2005 *旺达与巨像* 把 [[ico-negative-space-companionship]] 的负空间美学推到极致——**主角 vs 16 个巨像**, 整个游戏只有这 16 场对决, 没有其他敌人, 没有 NPC, 一个几近空旷的王国。

核心 Pathosformel：**尺度崇高**（scale sublime）。巨像身高 20-40 米, 玩家只有 1 米多。不是战斗感, 是**攀登 Friedrich 雾海的漫游者**——只是这次漫游者爬到山上（巨像本身即山）才开始对抗。

视觉细节：
- 景深雾气（atmospheric perspective）让远景淡化, 强化空间崇高
- 浅黄绿色 + 蓝灰色的古典风景画调色板
- 巨像**毛发**逐帧模拟（PS2 时代罕见）
- Kow Otani 配乐极简, 大量无声段落

伦理张力（也是美学张力）：**玩家杀的是动物, 不是怪物**。每个巨像死时镜头慢到每秒 10 帧, 音乐停, 玩家感到罪恶。这不是"game fun", 这是**悲剧**——游戏作为 sublime genre 而非 action genre。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt

```
[pre-iconographic]
  a tiny horseback figure approaches a massive 30-meter-tall stone-and-moss colossus
  in an empty plateau, dusty golden-hour light, heavy atmospheric perspective
  fading distant mountains into haze,
  muted palette (dust yellow + olive green + cold blue-grey shadows),
  no HUD, no UI, extreme scale contrast.
[iconographic]
  PS2 2005 Shadow of the Colossus screenshot, Fumito Ueda / Team Ico
  Iconclass: null
[iconological]
  scale as sublime; the colossus is not a monster but a reluctant adversary.
[lineage]
  Warburg panel: [[sublime-solitude]]
  AAT: [video games (300312168)](http://vocab.getty.edu/aat/300312168)
  Art direction: Fumito Ueda
  Cross-era: Friedrich *Monk by the Sea* 1810 → Moby Dick → SotC 2005
--ar 16:9 --style raw
```

### Video prompt (compatible: runway gen-3, kling)

```
[pre-iconographic]
  slow 10-second tracking shot: horseback hero approaching distant colossus silhouette emerging
  from haze, horse gait rhythm matches orchestral build, no dialogue, no UI.
  camera: 50mm equiv, gentle forward push-in, handheld subtle shake.
[iconographic]
  SotC encounter genre
[iconological]
  the quiet dread before sublime confrontation
[lineage]
  Kow Otani score parallel; Terrence Malick cinematography lineage
duration: 10s · transition: fade to combat
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[sublime-solitude]] — 游戏域的尺度崇高节点
- **Panofsky 层**: iconological — 伦理悲剧作为游戏类型的建立
- **AAT**: [300312168](http://vocab.getty.edu/aat/300312168)
- **Wikidata**: [Q131138](https://www.wikidata.org/wiki/Q131138)
- **MobyGames / IGDB**: 19597 / 12
- **跨传统**: Friedrich *Monk by the Sea* → Melville *Moby Dick* → SotC → *Death Stranding* (Kojima 2019 有意继承)
- **参考书架**: [[_refs/_domains/game]] — SotC 在 Schell / Bogost / Juul 三人书中都是反复引用案例
<!-- llm:section-end academic-lineage -->
