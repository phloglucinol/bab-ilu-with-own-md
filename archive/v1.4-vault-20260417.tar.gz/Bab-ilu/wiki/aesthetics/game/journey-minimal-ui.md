---
id: journey-minimal-ui
type: aesthetic
title: Journey 极简游戏界面哲学
aliases: [Journey 2012 HUD minimalism, thatgamecompany aesthetic]
aat_id: null
wikidata: "Q180967"
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: game
prompts:
  ui:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
  image:
    generated: "2026-04-16"
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney-v6, flux-1.1-pro]
  video:
    generated: null
    last_tested: null
    test_score: null
    compatible_models: []
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.9
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[geometric-silence]]}
  - {type: inspired_by, target: [[dieter-rams-principles]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

thatgamecompany 的 *Journey* (2012) 在游戏设计领域做了一次极端的功能主义选择:**把几乎所有 HUD 元素移除**——没有血条、没有小地图、没有数字 UI、没有文字对话。玩家知道的一切都通过画面本身传达——光、风、流沙的反馈、另一玩家的肢体语言。

这是 Rams 功能主义在交互层的**极端实现**:"减到不能再减"不是视觉美学选择,是游戏设计哲学——当可以通过世界本身传达信息时,HUD 就是冗余。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] zero chrome UI, full-bleed game world as interface, diegetic signals only (character robe length indicates ability, scarf glow indicates energy, wind direction indicates goal), single neutral sans-serif only appears at chapter transitions at 14pt, palette inherits from scene not UI layer
[iconographic] post-2012 minimal game interface tradition, thatgamecompany / Flower / Abzu / Sky: Children of the Light family
[iconological] game interface as disappearing act — design succeeds when user forgets design exists
[lineage] Warburg panel: [[geometric-silence]] · direct antecedent: [[dieter-rams-principles]] · signature: thatgamecompany / Jenova Chen

### Image prompt (compatible: midjourney v6+, flux-1.1-pro)
[pre-iconographic] warm amber desert landscape, small robed figure with long crimson scarf, wind-swept sand ripples, soft volumetric light from low sun, matte painting feel with stylized geometric mountains in distance, no UI elements whatsoever on image
[iconographic] Journey 2012 video game screen capture aesthetic, stylized fantasy pilgrimage
[iconological] pilgrimage as visual language — journey both literal and existential
[lineage] Warburg panel: [[geometric-silence]] · signature: thatgamecompany Journey art direction
--ar 16:9 --style raw
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[geometric-silence]] —— 功能主义沉默在交互媒介中的激进实现
- **Panofsky 层**:iconological —— 不是"极简游戏风格",是关于界面本身是否必要的哲学立场
- **Getty AAT**:无稳定 ID
- **Wikidata**:[wikidata:Q180967](https://www.wikidata.org/wiki/Q180967)
- **跨传统笔记**:
  - Dieter Rams 十大原则(1970s)—— "as little design as possible" 在硬件产品层
  - Muji 无印良品(1980–)—— Rams 原则的日本变体,加入温度
  - thatgamecompany *flOw* (2007), *Flower* (2009), *Journey* (2012)—— 把此原则放进交互
  - *Sky: Children of the Light* (2019)—— Chen 本人续作
  - *Abzû* (2016), *Gris* (2018)—— 后续的简约游戏血统
<!-- llm:section-end academic-lineage -->
