---
id: breath-of-the-wild-wind-grass
type: aesthetic
title: 《旷野之息》· 风格化自然感的语言
aliases: [Zelda BotW, 2017, Nintendo EPD]
aat_id: "300312168"
wikidata: "Q21074"
iconclass: "48C11"
warburg_panel: null
panofsky_layer: iconological
domain: game
moby_id: "83880"
igdb_id: "7346"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux, nano-banana]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway, kling]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[chromatic-organism]]}
---

## Core observation

Nintendo EPD 2017 *塞尔达传说：旷野之息* 重新定义了**风格化自然**在游戏中的可能。不是写实（像 Red Dead Redemption），不是卡通（像 Wind Waker），而是介于两者——**水彩动漫混合渲染**让 Hyrule 看起来像宫崎骏分镜的可交互版本。

技术基础：delicate cel-shading + 次表面散射 + 自定义 LUT。每棵草的风动力学单独计算（GPU instancing）。云朵用 2D 喷绘贴图贴到球面。

对 [[chromatic-organism]] 面板意义：色彩作为**生物直接表达**在游戏里的当代证据。Ghibli 色相（浅翠绿 + 奶白天空 + 薄桃色晨光）通过游戏引擎实时生成。

美学哲学：**"nature as the only correct UI"**。探索不需要地图标签——一根烟、一座山、一道光，玩家自发追逐。Don Norman 的"affordance" 原则用于开放世界游戏。

产业影响：开创 open-world "探索信心" 设计—— *Elden Ring* (2022)、*Tears of the Kingdom* (2023)、*Genshin Impact* (2020) 都直接继承 BotW 视觉语法。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt

```
[pre-iconographic]
  stylized vista of a grass plain with distant blue-silhouette mountain,
  watercolor-edged cel-shaded look, soft Ghibli palette (pale emerald grass +
  buttercream sky + dusty rose clouds), individual grass blades visible with wind motion,
  golden-hour rim light on hero figure in foreground (medium shot),
  no UI, minimal detail on background mountain.
[iconographic]
  Nintendo Switch 2017 game screenshot from Breath of the Wild
  Iconclass: [48C11](https://iconclass.org/48C11) landscape
[iconological]
  nature as correct UI; landscape itself signals where to explore without tags.
  Ghibli tradition digitized into real-time rendering.
[lineage]
  AAT: [video games (300312168)](http://vocab.getty.edu/aat/300312168)
  Iconclass: [48C11](https://iconclass.org/48C11) landscape
  Art director: Satoru Takizawa (Nintendo EPD)
  Parallel: Studio Ghibli watercolor tradition (Miyazaki 1984-present)
--ar 16:9
```

### Video prompt (compatible: runway gen-3, kling)

```
[pre-iconographic]
  6-second slow wind-flown orbital shot over grass plain,
  Ghibli color palette, subtle grass wave motion, occasional distant bird silhouette.
  camera: 45mm equiv, steady-cam-drone hybrid motion.
[iconographic]
  BotW vista genre
[iconological]
  quiet exploration as emotional mode
[lineage]
  Nintendo Satoru Takizawa + Miyazaki canonical color palette
duration: 6s · transition: cross-dissolve
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg panel**: [[chromatic-organism]] (色彩作为自然直接载体的当代游戏节点) + 非正式挂靠 [[sublime-solitude]]
- **Panofsky 层**: iconological — "nature as UI" 美学哲学
- **AAT**: [300312168](http://vocab.getty.edu/aat/300312168) video games
- **Iconclass**: [48C11](https://iconclass.org/48C11) landscape
- **Wikidata**: [Q21074](https://www.wikidata.org/wiki/Q21074)
- **MobyGames / IGDB**: 83880 / 7346
- **跨传统**: Miyazaki 宫崎骏动画 → 东方水墨传统 → BotW 2017 → Elden Ring / Genshin Impact 继承
- **参考书架**: [[_refs/_domains/game]]
<!-- llm:section-end academic-lineage -->
