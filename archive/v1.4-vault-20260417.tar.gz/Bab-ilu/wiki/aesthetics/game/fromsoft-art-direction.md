---
id: fromsoft-art-direction
type: aesthetic
title: FromSoftware 美术指导语言
aliases: [Souls series art, Miyazaki Hidetaka aesthetic, Dark Souls visual DNA]
aat_id: null
aat_uncertainty: "AAT 对电子游戏美术分类尚未成熟,候选为 Video game art 下层结构,待 2026 后 AAT 更新"
wikidata: "Q574758"
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: game
prompts:
  ui:
    generated: null
    last_tested: null
    test_score: null
  image:
    generated: "2026-04-16"
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana]
  video:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
    compatible_models: [runway-gen3, sora, kling-1.6]
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.9
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: frames, target: [[tarkovsky-stalker-long-take]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

FromSoftware(Demon's Souls 2009 → Dark Souls 2011 → Bloodborne 2015 → Elden Ring 2022)在宫崎英高主导下建立了**废墟崇高美学**:玩家是浩渺毁灭世界中的孤独主体,环境不作为背景而作为叙事主角——大教堂、古树、深渊、古城——每一处空间的规模都在压迫主体,而这种压迫反而产生一种玩家反复返回的情感快感。

这是 [[sublime-solitude]] Pathosformel 在可交互 3D 媒介中的**近乎完美的当代变体**。玩家不是旁观者,玩家**就是那个小小的背影**。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana)
[pre-iconographic] dark desaturated palette dominated by ash grays and muted earths, single small armored figure in lower corner of frame at 5% height, vast gothic architecture or ruined cathedral dominating upper two-thirds, volumetric fog obscuring middle distance, rim lighting on figure's silhouette only, 35mm perspective compression
[iconographic] dark fantasy ruins, medieval European gothic + Eastern temple hybrid, post-collapse civilization, weathered stone and rust
[iconological] sublime solitude at world's end — the player as finite agent in a dying cosmos
[lineage] Warburg panel: [[sublime-solitude]] · direct antecedent: [[tarkovsky-stalker-long-take]] · signature: Hidetaka Miyazaki / FromSoftware art direction 2009–2022
--ar 16:9 --style raw --v 6

### Video prompt (compatible: runway gen-3, sora, kling 1.6)
[pre-iconographic] slow dolly-in over 8 seconds toward distant vast gothic structure, player character in foreground at 3% frame, volumetric fog with particle density 0.3, ambient orchestral cue implied but no diegetic sound
[iconographic] Souls-like fantasy ruin, player entering a new zone
[iconological] crossing into sublime space — the moment of confronting scale before combat
[lineage] Warburg panel: [[sublime-solitude]] · signature: FromSoftware Demon's/Dark Souls zone-entry cinematography
duration: 8s · transition: hold on establishing
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[sublime-solitude]] —— 孤身人形立于吞没性世界的 Pathosformel,在可交互媒介的实现
- **Panofsky 层**:iconological —— 不是游戏艺术风格标签,是把崇高做成可玩世界观
- **Getty AAT**:尚无稳定 ID;候选 Video game art 层级
- **Wikidata**:[wikidata:Q574758](https://www.wikidata.org/wiki/Q574758) —— FromSoftware 公司
- **跨传统笔记**:
  - Caspar David Friedrich 浪漫主义崇高绘画(1818)—— 公式的原始确立
  - Hieronymus Bosch 末世异景(15–16 世纪)—— 提供 Souls 系列的怪诞元素
  - Gustave Doré, Dante 插画(1861)—— 歌特建筑 + 小人物的版画血统
  - Tarkovsky *Stalker*(1979)—— 东欧形而上学废墟
  - Berserk 漫画(三浦建太郎 1989–2021)—— Miyazaki 公开承认的主要灵感源
  - FromSoftware Souls 系列(2009–2022)—— 在此实现为可玩 Pathosformel
  - 本 Pathosformel 的现代后续包括 *Hollow Knight*、*Blasphemous*、*Lies of P*
<!-- llm:section-end academic-lineage -->
