---
id: bauhaus-typography
type: aesthetic
title: Bauhaus 字体与印刷传统(1919–1933)
aliases: [Bauhaus typography, neue Typografie]
aat_id: "300021512"
wikidata: "Q4692"
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: graphic
prompts:
  ui:    {generated: null, last_tested: null, test_score: null}
  image: {generated: null, last_tested: null, test_score: null, compatible_models: []}
  video: {generated: null, last_tested: null, test_score: null, compatible_models: []}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[swiss-international-style]]}
  - {type: exemplifies, target: [[geometric-silence]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

Bauhaus(1919–1933, Weimar → Dessau → Berlin)在字体与印刷领域建立的**新印刷术**(*Neue Typografie*) 是 20 世纪功能主义平面设计的起点。Herbert Bayer 的"Universal"字体(1925)、Jan Tschichold 的 *Die neue Typographie* (1928)、Laszlo Moholy-Nagy 的排版实验——这些工作把**几何网格 + 非衬线字体 + 非对称布局 + 消除装饰**组织为可教、可复制的设计语言。

当 Bauhaus 在 1933 年被纳粹关闭后,其师生(Gropius、Moholy-Nagy、Albers、Bayer)流亡到美国(黑山学院、IIT)与瑞士,在那里本传统延续为 Swiss International Typographic Style (1950s–70s) 和美国现代主义设计。

## 在 vault 中的角色

本条目作为 [[geometric-silence]] Pathosformel 的**历史起点**存在,供 taste-lineage 追溯平面、产品、建筑、界面等多个领域的功能主义血统。

## 关键人物与作品

- Walter Gropius —— Bauhaus Manifesto (1919)
- Herbert Bayer —— Universal 字体 (1925)
- Jan Tschichold —— *Die neue Typographie* (1928)
- Laszlo Moholy-Nagy —— 多媒介实验 + *Die Bühne im Bauhaus* (1925)
- Josef Albers —— 色彩与感知 + 黑山学院
- Paul Klee / Wassily Kandinsky —— Bauhaus 教师,现代主义视觉理论

## 学术外部锚

- Wikidata: [Q4692](https://www.wikidata.org/wiki/Q4692)
- Getty AAT:[aat:300021512](http://vocab.getty.edu/aat/300021512) —— Bauhaus
- 核心文本:Hans Wingler, *The Bauhaus* (MIT Press, 1969);Frank Whitford, *Bauhaus* (Thames & Hudson, 1984)
