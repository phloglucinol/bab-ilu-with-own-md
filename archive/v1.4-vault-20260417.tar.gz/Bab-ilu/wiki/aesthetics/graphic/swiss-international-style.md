---
id: swiss-international-style
type: aesthetic
title: Swiss International Typographic Style
aliases: [International Style, Swiss Style, 瑞士风格]
aat_id: "300021502"
wikidata: "Q272060"
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: graphic
prompts:
  ui:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
  image:
    generated: "2026-04-16"
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney-v6, flux-1.1-pro]
  video:
    generated: null
    last_tested: null
    test_score: null
    compatible_models: []
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: inspired_by, target: [[josef-muller-brockmann-grid]]}
  - {type: extends, target: [[bauhaus-typography]]}
  - {type: exemplifies, target: [[geometric-silence]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

Swiss International Typographic Style(1950s–1970s 苏黎世/巴塞尔为中心)建立了 20 世纪后半叶**信息可视传达**的标准语法:严格网格、非衬线字体、非对称布局、大量负空间、功能决定形式。Josef Müller-Brockmann 的《Grid Systems in Graphic Design》(1961) 是教科书级奠基作。

本条目捕捉的是"标准瑞士风格"——Akzidenz-Grotesk 或 Helvetica / 严格模数网格 / 图像客观摄影 / 标题悬挂于视觉强调位 / 消色差或单一强调色。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] strictly 12-column modular grid with 16px gutters, Helvetica Neue or Akzidenz-Grotesk typographic pair, weight contrast 400/700 only, consistent baseline rhythm at 24px increments, asymmetric composition with content anchored top-left, single strong accent color (often red #EE1C25 or black #000000), text-as-hero hierarchy with display sizes at 96pt+
[iconographic] Swiss editorial graphic design 1950s–1970s legacy in digital product, modernist information design
[iconological] clarity as ethics — information privileged over decoration, reader served not entertained
[lineage] Warburg panel: [[geometric-silence]] · AAT: International style (aat:300021502) · signature: Müller-Brockmann grid tradition · antecedent: Bauhaus typography

### Image prompt (compatible: midjourney v6+, flux-1.1-pro)
[pre-iconographic] black-and-white or red-and-black poster composition, bold non-serif display type in upper third, photographic image in lower two-thirds with hard crop to grid lines, objective product or portrait photography lit neutrally, flat negative space at 30%+, strict 12-column invisible grid alignment
[iconographic] Swiss poster design 1950s–1970s, Olivetti / Swissair / Basel Theatre commissioned work
[iconological] International Style — design as universal visual language transcending national taste
[lineage] Warburg panel: [[geometric-silence]] · AAT: International style (aat:300021502) · signature: Müller-Brockmann, Max Miedinger, Jan Tschichold lineage
--ar 2:3 --style raw
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[geometric-silence]] —— 功能主义几何沉默 Pathosformel 在平面设计领域的标准语法
- **Panofsky 层**:iconological —— 不是风格选项,是"设计服务信息"的世界观
- **Getty AAT**:[aat:300021502](http://vocab.getty.edu/aat/300021502) —— International style
- **Wikidata**:[wikidata:Q272060](https://www.wikidata.org/wiki/Q272060)
- **跨传统笔记**:
  - Jan Tschichold, *Die neue Typographie* (1928) —— 早期新印刷术
  - Bauhaus(1919–1933)—— 功能主义 graphic 设计学术化
  - Max Miedinger, Helvetica 字体(1957)—— 字体物质化该血统
  - Josef Müller-Brockmann, *Grid Systems* (1961) —— 网格系统教科书化
  - Massimo Vignelli, Unimark International —— 把 Swiss 传到美国
  - 数字时代延续:Apple HIG、Material Design、Bootstrap 栅格都在此谱系中
<!-- llm:section-end academic-lineage -->
