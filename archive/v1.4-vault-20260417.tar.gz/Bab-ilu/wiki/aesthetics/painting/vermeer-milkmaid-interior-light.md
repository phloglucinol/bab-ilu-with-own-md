---
id: vermeer-milkmaid-interior-light
type: aesthetic
title: Vermeer《挤奶女工》· 北欧内光凝固
aliases: [The Milkmaid, De Melkmeid, 1658]

# Controlled-vocabulary trio
aat_id: "300021156"                          # Genre paintings (Dutch)
aat_uncertainty: null
wikidata: "Q167605"                          # The Milkmaid (Vermeer)
wikidata_uncertainty: null
iconclass: "41C32"                           # Pouring liquid from one container into another
iconclass_uncertainty: null

# Warburg / Panofsky
warburg_panel: [[volumetric-light-descent]]
panofsky_layer: iconological
domain: painting
lineage_depth: 3

# Institutional IDs
ulan_id: "500032927"                         # Johannes Vermeer ULAN
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: "SK-A-2344"                        # Rijksmuseum accession · Gallery of Honour
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null

# Multi-modality prompts (painting domain — `painting` modality required)
prompts:
  ui:
    generated: 2026-04-16
    last_tested: null
    test_score: null
  image:
    generated: 2026-04-16
    last_tested: 2026-04-16
    test_score: 1.0
    compatible_models: [midjourney, flux, nano-banana]
  video:
    generated: 2026-04-16
    last_tested: null
    test_score: null
    compatible_models: [runway, kling]
  ux_flow: null
  painting:
    generated: 2026-04-16
    last_tested: null
    test_score: null
    compatible_tools: [oil, digital-procreate]
  motion: null

language: zh
original_terms:
  - term: "De Melkmeid"
    lang: nl
  - term: "The Milkmaid"
    lang: en
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.95
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[volumetric-light-descent]]}
  - {type: derived_from, target: [[vermeer-johannes]]}
  - {type: frames, target: [[dutch-golden-age-genre-painting]]}
---

## 视觉物证

> Johannes Vermeer, *De Melkmeid* (c. 1658), oil on canvas, 45.5 × 41 cm
> Rijksmuseum Amsterdam · Gallery of Honour · SK-A-2344

_(图像见 Rijksmuseum 高分 IIIF URL：https://www.rijksmuseum.nl/en/collection/SK-A-2344)_

## Core observation

这张约 45 厘米的小画是**北欧内光传统的顶峰样本**。一个生活场景——一个女工从陶罐向碗里倒奶——被光的物理学凝固成不朽。光源不是天窗也不是油灯，是**一扇侧开的左上窗**，蓝灰色清冷的北欧晨光穿进，投在女工前臂的羊毛针织袖口、陶罐釉面的反光、面包表皮的粗糙凸起上。

Vermeer 用**极少的色相**（蓝、黄、土红、白）和**极丰富的明暗层级**，把一个日常动作抬升到仪式感。画面的"运动"仅在流出罐口的那道细流——剩余的一切都静止，等待那根奶流触碰碗底的时刻。这是北欧内光画派（Dutch Golden Age genre painting）对**时间与物质性**的核心贡献：不讲故事，讲光如何穿过材质。

它是 [[volumetric-light-descent]] 面板最经典的 17 世纪样本——Caravaggio 的卡拉瓦乔光是戏剧性的斜射，Vermeer 的光是**无事件的侧入**，同一 Pathosformel 的两种极化形态。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt

```
[pre-iconographic] cool interior palette: slate blue oklch(65% 0.08 240), butter yellow oklch(82% 0.15 85), ochre red oklch(55% 0.12 35), warm white oklch(96% 0.02 80). typography pairing: Berlingske Serif for display, Avenir Next for body. generous single-column layout with 1.7 line-height, 8pt grid but IRREGULAR spacing rhythm (24/32/56) — asymmetric weight. material: eggshell paper feel with soft deckle edges, no gloss.
[iconographic] Dutch Golden Age interior: genre-painting visual register applied to a product detail page or editorial essay about craftsmanship. a single object photographed with north-light logic as hero image. no rotating carousel.
[iconological] stillness, patience, the dignity of repetitive labor. the opposite of scroll-optimized engagement. users feel permission to slow down.
[lineage] Warburg panel: [[volumetric-light-descent]] · AAT: Genre paintings (aat:300021156) · ULAN: Vermeer (500032927)
```

### Image prompt (compatible: midjourney v6+, flux, nano-banana)

```
[pre-iconographic] oil painting, 45.5 x 41 cm, linen support, thin ground of chalk-glue primer, lead white highlights with glazes of ultramarine and yellow ochre on reddish-brown underpainting. cool north-facing window light from upper left, single light source, zero bounce light on shadow side. soft shadow gradient on right cheek. matte-sheen of ceramic pitcher, micro-specular of milk stream.
[iconographic] Dutch Golden Age genre painting of a domestic interior: a female servant in blue apron and yellow bodice pours milk from an earthenware pitcher into a brown bowl, bread and utensils on a rough table, rush matting partially visible on window sill.
[iconological] the sacralization of domestic labor; time arrested in the instant before fluid touches fluid; light as quiet moral witness.
[lineage] Warburg panel: [[volumetric-light-descent]] · AAT: Genre paintings (aat:300021156) · Iconclass: [41C32](https://iconclass.org/41C32) · signature: Johannes Vermeer c.1658
--ar 4:5 --style raw --q 2
```

### Video prompt (compatible: runway gen-3, kling 1.6)

```
[pre-iconographic] static camera, no pan no dolly. 4-second hold on milkmaid's forearm and pouring stream. north window light cool 5500K, shadow side warm bounce at 0.15 gain. micro-motion: milk stream gently oscillates; crumb texture on bread crust static; subject's breath unobservable.
[iconographic] Dutch Golden Age interior scene frozen into cinematic duration.
[iconological] meditative still; the viewer learns to wait.
[lineage] Warburg panel: [[volumetric-light-descent]] · Iconclass: 41C32 · director signature: no cinematographer yet carries this — closest match Greig Fraser's *Dune* shaft logic recomposed in interior scale
duration: 4s · transition: slow cross-dissolve to next still
```

### Painting prompt (v1.4 — compatible: oil, digital-procreate)

```
[pre-iconographic]
  Support: linen canvas 45 × 41 cm, fine weave, chalk-and-animal-glue ground
  Priming: warm red-brown imprimatura (burnt sienna thin glaze)
  Palette (7 pigments max, Vermeer's actual):
    - lead white (2 parts)
    - yellow ochre (1 part)
    - natural ultramarine (premium lapis — expensive, Vermeer used for this work)
    - red lake (madder root)
    - umber (burnt / raw)
    - bone black
    - lead-tin yellow for highlights on pitcher rim
  Brushes: hog bristle rounds for blocking; sable softs for glazes; tiny sable #00 for specular highlights on milk stream and crumb
  Technique: oil, multi-layered — chalk ground, imprimatura, grisaille underpainting in umber + lead white (tonal structure), then thin colored glazes for local color, then opaque paint for lights and highlights. Pointillé (raised dots of lead white) for crumb and specular catch-lights.
  Medium: linseed oil with ~10% stand oil + dammar varnish for gloss control. Drying between layers (days to weeks).
  Light: single cool north window at upper-left 60° elevation. No secondary fills.

[iconographic]
  Dutch Golden Age genre painting, c. 1658 Delft
  Subject: Iconclass [41C32](https://iconclass.org/41C32) pouring liquid from one container into another (+25 female figure)
  Compositional device: stable triangular figure anchored left, strong diagonal from window light, still life foreground (bread, utensils), wall texture depth.

[iconological]
  The painting refuses narrative. No story, no event, no allegory. What is iconologically at stake is the Dutch Reformed worldview: domestic labor sanctified through observation, the visible world as the full measure of dignity.

[lineage]
  Warburg panel: [[volumetric-light-descent]] — Pathosformel of quiet light descent
  Iconclass: [41C32 Pouring](https://iconclass.org/41C32)
  ULAN: [Johannes Vermeer (500032927)](http://vocab.getty.edu/ulan/500032927)
  Canonical book: Walter Liedtke, *Vermeer: The Complete Paintings* (2008) pp.99-108
  Canonical book: Arthur Wheelock, *Vermeer and the Art of Painting* (1995)
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**: [[volumetric-light-descent]] —— 体积光作为 Pathosformel：光下降到物质表面的诸种极化形态（Caravaggio 斜射 / Vermeer 侧入 / Fraser 穹窿）
- **Panofsky 层**: iconological —— 不仅描绘倒奶动作（iconographic layer 2），而是通过光的物理精确性构筑"劳动作为秩序"的新教世界观（layer 3）
- **Getty AAT**: [aat:300021156](http://vocab.getty.edu/aat/300021156) —— Genre paintings (Dutch) > Paintings by genre > Visual works
- **Iconclass**: [41C32](https://iconclass.org/41C32) —— Pouring liquid from one container into another, `(+25)` 表示女性人物
- **Wikidata**: [Q167605](https://www.wikidata.org/wiki/Q167605)
- **ULAN**: [Johannes Vermeer 500032927](http://vocab.getty.edu/ulan/500032927)
- **Rijksmuseum**: [SK-A-2344 Gallery of Honour](https://www.rijksmuseum.nl/en/collection/SK-A-2344) —— 永久展示，高清 IIIF 开放
- **跨传统笔记**:
  - 17 世纪荷兰内光传统（Pieter de Hooch, Emanuel de Witte 教堂内景）
  - 19 世纪延伸（Vilhelm Hammershøi 哥本哈根内景）
  - 摄影接续（Saul Leiter 1950s-60s 窗口人物、Wim Wenders 东京屋内）
  - 电影接续（Andrey Tarkovsky *Mirror* 1975 屋内光；Greig Fraser *Dune* 2021 把同一 Pathosformel 转入工业尺度的穹窿空间——详见 [[villeneuve-fraser-dune-shaft]]）
- **参考书架**: [[_refs/_domains/painting]]（Wölfflin · Gombrich · Baxandall · Alpers · T.J. Clark）· [[_refs/_institutions/rijksmuseum]]（全高清 IIIF 图像 + Iconclass 标注）
<!-- llm:section-end academic-lineage -->
