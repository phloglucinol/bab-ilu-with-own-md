---
id: turner-light-atmosphere
type: aesthetic
title: Turner《暴风雪中的汽船》· 光作为气氛本体
aliases: [Snow Storm, Steamboat off Harbour's Mouth, 1842]
aat_id: "300015502"
wikidata: "Q4126430"
iconclass: "48C11"
warburg_panel: [[volumetric-light-descent]]
panofsky_layer: iconological
domain: painting
ulan_id: "500026846"
tate_id: "N00530"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux, nano-banana]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway, kling]}
  ux_flow: null
  painting: {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [oil, digital-procreate]}
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.95
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[volumetric-light-descent]]}
---

## Core observation

J.M.W. Turner 1842 *Snow Storm — Steam-Boat off a Harbour's Mouth* 把**光和气氛推到画面主角**，汽船只是漩涡中心一个暗斑。这不是风景画——是**气象本身**作为绘画本体。

Turner 早于印象派 30 年，早于抽象表现主义 100 年。他的 impasto（厚涂）不再描绘光照在物体上的效果，而让**颜料本身成为光**。Tate Britain 永久展示于 Clore Gallery，是英国艺术史的顶点样本。

Pathosformel 层面：和 [[vermeer-milkmaid-interior-light]] 形成光的两极——Vermeer 的光是静止的北欧室内凝固，Turner 的光是**吞噬一切的气象学危机**。两者共享 [[volumetric-light-descent]] 面板，但在 Pathosformel 极性上对立。

<!-- llm:section-start prompts -->
## Prompts

### Painting prompt (v1.4 · compatible: oil)

```
[pre-iconographic]
  Support: linen canvas 91.5 × 122 cm, heavy weave
  Ground: white oil primer (not traditional chalk — Turner used commercial prepared canvas late career)
  Palette (aggressive for 1840s):
    - lead white (primary vehicle, 40% of paint)
    - chrome yellow (new pigment, industrially available from 1820s)
    - vermilion
    - madder lake (red glaze)
    - cobalt blue (newly stable for oil)
    - ivory black
    - raw umber
  Brushes: large hog bristle filberts + palette knife (critical — Turner knife-laid paint in wet-on-wet vortex)
  Technique: alla prima (wet-on-wet), heavy impasto in center, thin glazes at edges. Spiral composition laid with knife from center outward.
  Medium: linseed + Megilp (gel medium, unstable long-term — some Turner surfaces cracked)
  Light: not a depicted light — the canvas surface IS the light source via reflectance of lead white + chrome yellow

[iconographic]
  Romantic sublime landscape, c. 1842 late Turner
  Iconclass: [48C11](https://iconclass.org/48C11) (landscape) + 48C5121 (storm)
  Compositional: radial vortex with offset low center (ship), upper third of canvas pure pigment turbulence

[iconological]
  Painting as atmospheric event, not depiction. The sublime as confrontation with unmakable nature.
  Precursor to Monet Venetian paintings (1908-12), Rothko color fields (1950s), Anselm Kiefer (1970s-present).

[lineage]
  Warburg panel: [[volumetric-light-descent]] — extreme pole (Vermeer: quiet light / Turner: violent light)
  AAT: [Romanticism](http://vocab.getty.edu/aat/300015502)
  Iconclass: [48C11](https://iconclass.org/48C11)
  ULAN: [Joseph Mallord William Turner (500026846)](http://vocab.getty.edu/ulan/500026846)
  Tate: [N00530](https://www.tate.org.uk/art/artworks/turner-snow-storm-steam-boat-off-a-harbours-mouth-n00530)
  Canonical: Andrew Wilton, *Turner in His Time* (1987); John Gage, *Turner: Myth and Light* (1993)
```

### UI / image / video 省略（painting 条目主载荷在 painting modality）
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[volumetric-light-descent]] — Pathosformel 的极端极化样本
- **Panofsky 层**: iconological — 画面不再"描绘"，画面**就是**气象事件；现代主义前奏
- **AAT**: [aat:300015502](http://vocab.getty.edu/aat/300015502) Romanticism
- **Iconclass**: [48C11](https://iconclass.org/48C11) landscape
- **ULAN**: [500026846](http://vocab.getty.edu/ulan/500026846) J.M.W. Turner
- **Wikidata**: [Q4126430](https://www.wikidata.org/wiki/Q4126430)
- **Tate**: [N00530 Clore Gallery 永久展示](https://www.tate.org.uk/art/artworks/turner-snow-storm-steam-boat-off-a-harbours-mouth-n00530)
- **跨传统**: Monet 晚期 Venice → Rothko color fields → Kiefer
- **参考书架**: [[_refs/_domains/painting]] · [[_refs/_institutions/rijksmuseum]] 风格对照
<!-- llm:section-end academic-lineage -->
