---
id: cezanne-mont-sainte-victoire-structure
type: aesthetic
title: Cézanne 圣维克多山系列 · 结构作为风景
aliases: [Mont Sainte-Victoire series 1882-1906]
aat_id: "300021503"
wikidata: "Q3319763"
iconclass: "48C11"
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: painting
ulan_id: "500004793"
met_id: "435868"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 0.95, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [oil, digital-procreate]}
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.95
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[geometric-silence]]}
  - {type: inspired_by, target: [[turner-light-atmosphere]]}
---

## Core observation

Cézanne 1882-1906 间反复画同一座山。**不是写生——是在画布上把自然解构为几何体**。他的名言："自然按圆柱体、球体、圆锥体处理"，成为立体主义的前奏。

几何化的动机不是装饰而是**认知的诚实**：人眼不是摄影机。看一座山时，我们同时感知多个视角、多个时刻、多个距离。Cézanne 把这种**认知真实**画进画面，因而放弃透视一致性。

对 Bab-ilu 的意义：Pathosformel [[geometric-silence]] 在绘画域的远祖节点。从 Cézanne → Cubism → Bauhaus → Swiss International → Apple HIG → Material Design，是**"几何沉默"在不同媒介的延续**。

<!-- llm:section-start prompts -->
## Prompts

### Painting prompt (v1.4)

```
[pre-iconographic]
  Support: canvas (Cézanne 常用 50 × 61 cm 或更大)
  Ground: 商业白色油画布，他不做 imprimatura
  Palette (post-impressionist 风格限制):
    - lead white
    - yellow ochre + chrome yellow
    - vermilion
    - viridian green (Cézanne 首选)
    - cobalt blue + ultramarine
    - ivory black（少量）
  Brushes: 方头 brights, 中等尺寸；晚期也用 palette knife
  Technique: **constructive brushstroke** — 平行小块颜色（约 2-3cm × 0.5cm），每块一色一方向，拼接而非混合。不画轮廓，用色块边界定义形
  Medium: 纯 linseed，极少用 medium；刻意留干哑光表面
  Light: 普罗旺斯明亮阳光，正午偏冷；从多个时刻/视角 composite，非单一光源

[iconographic]
  Post-Impressionist landscape of Provence, 1880s-1900s series
  Iconclass: [48C11](https://iconclass.org/48C11) landscape + [25G11](https://iconclass.org/25G11) mountain
  Compositional device: 前景松树垂直框定 + 山峰三角 + 中景平行笔触平原 — 传统风景布局的几何重排

[iconological]
  "Painting what the eye knows, not what the eye sees at one instant"
  反对印象派的 optical truth，转向 cognitive truth — 立体主义前奏
  20 世纪艺术的隐秘分水岭：Cézanne 死后 1907 Picasso 看到 Cézanne 回顾展画出《Demoiselles d'Avignon》

[lineage]
  Warburg panel: [[geometric-silence]] — 几何沉默在 19 世纪末的源头节点
  AAT: [Post-Impressionist (aat:300021503)](http://vocab.getty.edu/aat/300021503)
  Iconclass: [48C11](https://iconclass.org/48C11) + [25G11](https://iconclass.org/25G11)
  ULAN: [Paul Cézanne (500004793)](http://vocab.getty.edu/ulan/500004793)
  Met: [Mont Sainte-Victoire (436156)](https://www.metmuseum.org/art/collection/search/436156)
  Canonical: Meyer Schapiro, *Paul Cézanne* (1952); Clement Greenberg "Cézanne" essay (1951); Yve-Alain Bois, *Painting as Model* (1990)
```

### 其余省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[geometric-silence]] — 几何沉默 Pathosformel 在 19 世纪末的源头
- **Panofsky 层**: iconological — 不画眼见之物，画认知真实——艺术史断点
- **AAT**: [300021503](http://vocab.getty.edu/aat/300021503) Post-Impressionist
- **Iconclass**: [48C11](https://iconclass.org/48C11) landscape · [25G11](https://iconclass.org/25G11) mountain
- **ULAN**: [500004793](http://vocab.getty.edu/ulan/500004793) Paul Cézanne
- **Wikidata**: [Q3319763](https://www.wikidata.org/wiki/Q3319763)
- **Met**: [436156 series entry](https://www.metmuseum.org/art/collection/search/436156)
- **跨传统**: Cézanne → Picasso Cubism 1907 → Mondrian → Bauhaus → Swiss International → Apple HIG
- **参考书架**: [[_refs/_domains/painting]] · [[ernst-gombrich]] (*Art and Illusion* schema-correction 模型直接应用)
<!-- llm:section-end academic-lineage -->
