---
id: rothko-color-field-iconoclasm
type: aesthetic
title: Rothko 色域绘画 · 图像学反叛
aliases: [Color Field Painting, Abstract Expressionism, Rothko Chapel]
aat_id: "300021481"
wikidata: "Q6048126"
iconclass: null
warburg_panel: [[chromatic-organism]]
panofsky_layer: iconological
domain: painting
ulan_id: "500009513"
tate_id: "T01031"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [oil]}
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: contradicts, target: [[vermeer-milkmaid-interior-light]]}
  - {type: exemplifies, target: [[chromatic-organism]]}
---

## Core observation

Mark Rothko 1950s-1960s 成熟期作品**拒绝所有 iconclass 分类**——因为画面上什么都不"画"。只有两到三块漂浮的色域，边界模糊如透过雾看。

Rothko 的命题：**图像学已死**。文艺复兴以来的绘画必须"描绘什么"的假设，被扔进 20 世纪中期的历史垃圾桶。Rothko 不画人物、不画风景、不画象征——画**色的情感直接量**。

这对 Bab-ilu 的 Iconclass 体系构成**有意义的对抗**：我们的 schema 要求 painting 域尽量填 iconclass，但 Rothko 类色域绘画的 `iconclass: null` 不是缺失而是**本体陈述**。用 `aat:300021481` (Abstract Expressionism) 作为主要锚点，iconclass null 即是 Rothko 的立场。

Rothko Chapel（Houston 1971）是这个立场的顶点——14 幅近全黑油画环绕八角形礼拜堂，让观众在完全非图像的环境里静坐。世俗的神圣空间。

<!-- llm:section-start prompts -->
## Prompts

### Painting prompt (v1.4)

```
[pre-iconographic]
  Support: very large canvas (Rothko 经典尺寸 2m+ 高，强迫观者近距离沉浸)
  Ground: 有色底料（Rothko 用染色底子 alizarin crimson 或 raw umber, 而非白底）
  Palette (晚期极简):
    - alizarin crimson (主色)
    - cadmium red deep
    - burnt sienna
    - ivory black
    - ultramarine (shadow integration)
    - lead white (极少，仅用于微妙提亮)
  Brushes: 极大的软毛 wash brush (15-20cm 宽)，水粉刷类
  Technique: **thin staining** (颜料大量稀释，几近染色织物), 多层重叠, 每层几乎透明, 让下层 bleed through 上层
  Medium: 大量 turpentine + 少量 linseed，刻意使颜料稀薄到织物渗透
  Light: 画面本身不描绘光源，作品要求展示时**低亮度环境**（Rothko 常坚持 lux 要求极低），让色 "breathe"

[iconographic]
  Abstract Expressionism, Color Field subdivision, 1949-1970
  Iconclass: **null (intentional — Rothko refuses iconographic classification)**
  Compositional: 2-3 soft-edged rectangles floating on ground field, vertical orientation preferred

[iconological]
  "I'm not interested in relationships of color or form... I'm interested only in expressing basic human emotions—tragedy, ecstasy, doom"
  绘画作为情感的纯粹载体——后图像学
  承接 Caspar David Friedrich 的 sublime（但抛弃其图像描绘），预示当代 installation art

[lineage]
  Warburg panel: [[chromatic-organism]] — 作为色彩直接载体的 Pathosformel（但 Rothko 反转此面板的含义：生物被色彩取代 → 画布直接等于色彩）
  AAT: [Abstract Expressionism (300021481)](http://vocab.getty.edu/aat/300021481)
  Iconclass: intentionally null
  ULAN: [Mark Rothko (500009513)](http://vocab.getty.edu/ulan/500009513)
  Tate: [T01031 *Light Red over Black* 1957](https://www.tate.org.uk/art/artworks/rothko-light-red-over-black-t01031)
  Canonical: Rothko, *The Artist's Reality* (posthumous 2004); Annie Cohen-Solal, *Mark Rothko* (2015); Anna Chave, *Mark Rothko: Subjects in Abstraction* (1989)
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[chromatic-organism]] — 色作为直接情感载体的 Pathosformel 的 20 世纪极端形态
- **Panofsky 层**: iconological — **对图像学本身的拒绝**是 iconological 立场
- **AAT**: [300021481](http://vocab.getty.edu/aat/300021481) Abstract Expressionism
- **Iconclass**: `null` — 故意为之，见 core observation
- **ULAN**: [500009513](http://vocab.getty.edu/ulan/500009513) Mark Rothko
- **Wikidata**: [Q6048126](https://www.wikidata.org/wiki/Q6048126)
- **Tate**: [T01031](https://www.tate.org.uk/art/artworks/rothko-light-red-over-black-t01031)
- **跨传统**: Cézanne 结构 → Picasso → Mondrian → New York School → Rothko / Newman / Still → 70 年代 minimalism
- **参考书架**: [[_refs/_domains/painting]] · [[erwin-panofsky]]（Panofsky 晚年承认现代主义超出了他的三层法 —— Rothko 是最典型证据）
<!-- llm:section-end academic-lineage -->
