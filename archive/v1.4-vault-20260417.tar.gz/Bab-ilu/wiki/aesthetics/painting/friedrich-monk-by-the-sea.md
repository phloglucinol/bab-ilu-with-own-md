---
id: friedrich-monk-by-the-sea
type: aesthetic
title: Friedrich《海边的僧侣》· 崇高孤独的空间构图
aliases: [Der Mönch am Meer, Monk by the Sea, 1808-10]
aat_id: "300015502"
wikidata: "Q1477484"
iconclass: "41B3"
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: painting
ulan_id: "500115493"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway, kling]}
  ux_flow: null
  painting: {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [oil]}
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.95
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: inspired_by, target: [[caspar-david-friedrich-wanderer]]}
---

## Core observation

Friedrich 1808-10 《海边的僧侣》是 [[sublime-solitude]] 面板的**经典源头**。比《雾海上的漫游者》（1818）早 8 年，完成更激进。

画面几何学：**画布下部 1/10 是人物 + 岸**，**其余 9/10 是空**——天空 + 大海 + 无物的大气。当时画评震撼："好像眼睑被切去，不得不看"（Kleist 1810）。

构图**刻意违反**古典风景画规则：无前景植被、无侧景大树、无中景焦点。单人几何小点对抗浩渺开阔——这就是 sublime-solitude Pathosformel 的纯粹数学式定义，Friedrich 在这张画上第一次给出。

延续到 200 年后：Villeneuve *BR2049* Las Vegas 孤影、*Dune* 沙丘中的 Paul、奈良美智空间中的小孩——同一 Pathosformel 穿越绘画/电影/当代艺术。

<!-- llm:section-start prompts -->
## Prompts

### Painting prompt (v1.4)

```
[pre-iconographic]
  Support: canvas 110 × 171.5 cm (horizontal, 1:1.56 ratio)
  Ground: 中性灰绿色 imprimatura
  Palette (Friedrich 标志性，冷且少):
    - lead white (画面 60%+)
    - ultramarine + Prussian blue
    - bone black (very restrained)
    - ivory black
    - yellow ochre (极少，仅人物服饰)
    - umber
  Brushes: 超大 flat wash brushes (20cm+) for sky/sea fields; small sable for micro-figure
  Technique: **layered glazes** — 每层单色极稀薄, 8-12 层叠加 (Friedrich 的 Dresden 工坊传统), 表面最终极光滑无笔触
  Medium: linseed + stand oil, long drying, Vermeer 级别耐心
  Light: **diffuse northern grey** —  无定点光源，整个天空均匀漫射，海面微弱反射

[iconographic]
  Romantic landscape, Dresden 1808-10
  Iconclass: [41B3](https://iconclass.org/41B3) solitary male figure
  Compositional: 画面几何 = 1/10 人物+岸 · 3/10 海 · 6/10 天 (数学精确的崇高比例)

[iconological]
  极端的构图反叛: 单个人类几何小点对抗绝对开阔空间
  Pathosformel 纯粹数学定义: "to be solitary at the scale of infinity"
  德国浪漫主义崇高美学的顶点，早于 Caspar Wolf 高山画作和 Turner 后期

[lineage]
  Warburg panel: [[sublime-solitude]] — 此画即该面板的 **原型** (源头样本)
  AAT: [Romanticism (300015502)](http://vocab.getty.edu/aat/300015502)
  Iconclass: [41B3](https://iconclass.org/41B3) solitary figure
  ULAN: [Caspar David Friedrich (500115493)](http://vocab.getty.edu/ulan/500115493)
  Wikidata: [Q1477484](https://www.wikidata.org/wiki/Q1477484)
  Alte Nationalgalerie Berlin 永久展示
  Canonical: Joseph Leo Koerner, *Caspar David Friedrich and the Subject of Landscape* (1990); Helmut Börsch-Supan, *Caspar David Friedrich* (1973)
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[sublime-solitude]] —— 此画是该 Pathosformel 的**发明性源头**
- **Panofsky 层**: iconological —— 不是描绘僧侣，是**发明现代崇高的视觉语法**
- **AAT**: [300015502](http://vocab.getty.edu/aat/300015502) Romanticism
- **Iconclass**: [41B3](https://iconclass.org/41B3) solitary male figure
- **ULAN**: [500115493](http://vocab.getty.edu/ulan/500115493) Caspar David Friedrich
- **Wikidata**: [Q1477484](https://www.wikidata.org/wiki/Q1477484) *Der Mönch am Meer*
- **Berlin Alte Nationalgalerie** 永久藏
- **跨传统 Nachleben**: Whistler *Nocturnes* → Hopper 空旷美国 → Rothko 色域 → Villeneuve *BR2049* Las Vegas → 当代韩国/日本动画的空旷风景
- **参考书架**: [[_refs/_domains/painting]] · [[aby-warburg]]（Warburg 本人 1925 笔记就论证过 Friedrich 是现代孤独 Pathosformel 的源头）
<!-- llm:section-end academic-lineage -->
