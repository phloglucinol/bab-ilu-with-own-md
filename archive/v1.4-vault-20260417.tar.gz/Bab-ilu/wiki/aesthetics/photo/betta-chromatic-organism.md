---
id: betta-chromatic-organism
type: aesthetic
title: 泰国斗鱼 · 红蓝互补饱和
aliases: [Betta Fish Macro, Siamese Fighting Fish Chromatic Study]
aat_id: "300127119"
aat_uncertainty: null
wikidata: "Q189290"
wikidata_uncertainty: null
warburg_panel: [[chromatic-organism]]
panofsky_layer: iconological
domain: photo
prompts:
  ui:    {generated: "2026-04-16", last_tested: null, test_score: null}
  image: {generated: "2026-04-16", last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana]}
  video: {generated: "2026-04-16", last_tested: null, test_score: null, compatible_models: [runway-gen3, sora, kling-1.6]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.93
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[chromatic-organism]]}
  - {type: derived_from, target: "raw/images/demo/betta-chromatic-organism.jpg"}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[betta-chromatic-organism.jpg|泰国斗鱼鱼鳍微距|800]]

> 微距摄影 · 泰国斗鱼(Betta splendens)× 红/青互补色鳍展开 × 纯黑背景

## 核心观察

这张照片的"美学事件"发生在**鱼鳍的色彩结构**,不是鱼本身。摄影者选取了接近宏观抽象画的焦段与裁切——鱼身只以模糊的深蓝鳞片角在左上角入镜,其余全部交给鳍。红与青在 OKLCH 色空间里是极近完美的互补对,这组鳍把两种饱和度推到自然光下所能呈现的极限。

这不是生态摄影(没有栖息地叙事),不是物种科学插图(没有解剖教学目的)——是**把活体生物作为纯色彩绘画来呈现**的当代微距传统,[[chromatic-organism]] 面板内的代表作。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] dual saturated palette in OKLCH-complementary pair (#b22f2f crimson · #2d8fb3 teal · #0a0a0a void-black · #4a1f1f blood-shadow · #0d4254 depth-teal), pure black background for all chromatic focus, horizontal composition 3:2, content overlaid on deep black, color blocks and accent-only typography
[iconographic] nature-photography portfolio UI / color-theory editorial / fine-art print product
[iconological] color as life-force — interface where saturation is the message
[lineage] Warburg panel: [[chromatic-organism]] · AAT: Macro photography (aat:300127119) · Nature photography (aat:300127121) · signature: contemporary high-resolution macro tradition

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana)
[pre-iconographic] extreme macro photograph of Betta splendens fish fin spread, dual-color dominance — saturated crimson red primary hue filling 55% of frame with teal-blue secondary hue at 30% on opposite side, fin rays in hair-like detail spreading radially, single water droplet visible on fin edge, pure black background, deep-blue scaled body fragment in upper-right corner only, shallow macro depth of field with in-focus fin ray detail, studio-grade high-resolution capture, no ambient particles, horizontal 3:2 aspect
[iconographic] aquarium-fish studio macro photography, high-end pet-species portraiture tradition
[iconological] organism-as-pure-color — transcending descriptive photography into chromatic abstraction
[lineage] Warburg panel: [[chromatic-organism]] · AAT: Macro photography (aat:300127119) · Nature photography (aat:300127121) · signature: 2010s+ high-resolution macro-abstraction tradition
--ar 3:2 --style raw --v 6 --s 150

### Video prompt (compatible: runway gen-3, sora, kling 1.6)
[pre-iconographic] 6-second static macro shot 3:2, Betta fin rays undulate gently as fish holds position, water motion causing 2mm lateral sway of longest fin rays at 0.5Hz, single water droplet traverses fin surface slowly, pure black background, no camera motion, studio ring-light illumination steady
[iconographic] aquarium macro videography / nature-photography live-study aesthetic
[iconological] the slow breath of saturated life
[lineage] Warburg panel: [[chromatic-organism]] · AAT: Macro photography (aat:300127119) · signature: underwater-macro live-capture tradition
duration: 6s · transition: hold · subtle ambient underwater tone
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[chromatic-organism]] —— 生物作为纯色彩载体的 Pathosformel
- **Panofsky 层**:iconological —— 鱼在此不再是被描绘对象,是色彩哲学的物化
- **Getty AAT**:[aat:300127119](http://vocab.getty.edu/aat/300127119) Macro photography · [aat:300127121](http://vocab.getty.edu/aat/300127121) Nature photography
- **Wikidata**:[wikidata:Q189290](https://www.wikidata.org/wiki/Q189290) Betta splendens 暹罗斗鱼
- **跨传统笔记**:荷兰花卉静物画 Rachel Ruysch(1700s) → Audubon《美洲鸟类》(1830s) → Karl Blossfeldt《自然艺术形式》(1928) → Imogen Cunningham 花卉摄影(1930s–1940s) → Edward Weston 蔬果与贝壳(1930s–1940s) → David Doubilet 水下摄影(1970s–至今) → 2010s+ 传感器时代高分辨率微距泛滥。本作是这条 300 年血统在消费级 APS-C/全幅微距设备时代的一个典型节点——让"生物即色彩"能在 24MP 分辨率下达到近乎抽象画的细节密度。
<!-- llm:section-end academic-lineage -->
