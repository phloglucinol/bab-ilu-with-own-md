---
id: cooper-persona-method
type: aesthetic
title: Cooper Persona 方法 · 目标导向设计
aliases: [Persona Method, Goal-Directed Design]
aat_id: null
wikidata: "Q2040787"
iconclass: null
warburg_panel: null
panofsky_layer: iconological
domain: ux
nng_url: "https://www.nngroup.com/articles/persona/"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 0.8, compatible_models: [flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow:  {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [figma, miro, whimsical]}
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.85
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: applies, target: [[nng-ten-heuristics]]}
---

## Core observation

Alan Cooper 1998 *The Inmates Are Running the Asylum* / 1995 *About Face* 提出 **persona 方法**：不为"用户"做设计，为**具体命名的虚构角色**做设计。

每个 persona 有：姓名 / 照片 / 职业 / 日常场景 / 目标 / 挫折点。设计决策不答"用户可能怎样"，答"Rebecca 怎样"。

Cooper 的激进命题：程序员天然不适合设计消费产品，因为他们的心理模型与非程序员用户**永不重合**。Persona 是**强制认知切换工具**。

20 年后的修正：Kim Goodwin *Designing for the Digital Age* (2009) 把 persona 升级为**基于访谈数据的 evidence-based persona**（反对拍脑袋编造 persona）。

<!-- llm:section-start prompts -->
## Prompts

### UX flow prompt

```
[pre-iconographic]
  User: product designer starting a new feature
  Task: build 3-5 evidence-based personas before any sketch
  Input: 12-20 customer interviews transcripts
  Output: persona cards + affinity map of goals

[iconographic]
  Persona card structure (Cooper canonical):
    - Name + photo (stock, not colleague face)
    - Demographic (age / role / context — relevant attributes only)
    - Goals (not demographics, not tasks — Cooper's key distinction)
    - Scenarios of use (concrete narratives)
    - Frustrations with current solutions

  Decision rule: for each feature, name which persona benefits; if none, question the feature.

[iconological]
  Goal-directed design: features serve user goals, not task checklists
  NN/g heuristic #2 (match user's real world) — personas operationalize this
  ISO 9241-210 "explicit user understanding" principle — personas are one auditable artifact

[lineage]
  Cooper, *Inmates* (1999) chs 9-10
  Cooper, *About Face* (1995, 4th ed. 2014) chs 5-6
  Goodwin, *Designing for the Digital Age* (2009) ch 3 — evidence-based evolution
  NN/g: https://www.nngroup.com/articles/persona/
```

### 其余模态省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconological — "让程序员不设计消费产品"是文化立场而非技术立场
- **Wikidata**: [Q2040787](https://www.wikidata.org/wiki/Q2040787)
- **Primary source**: Cooper *Inmates* (1999) + *About Face* (1995)
- **NN/g**: [Personas article](https://www.nngroup.com/articles/persona/)
- **参考书架**: [[_refs/_domains/ux]] — Cooper 是 UX canonical #4
<!-- llm:section-end academic-lineage -->
