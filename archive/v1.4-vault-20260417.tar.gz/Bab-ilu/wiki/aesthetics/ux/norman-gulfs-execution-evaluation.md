---
id: norman-gulfs-execution-evaluation
type: aesthetic
title: Norman 执行鸿沟与评估鸿沟 · UX 认知骨架
aliases: [Gulfs of Execution and Evaluation, DOET]
aat_id: null
wikidata: "Q1139117"
iconclass: null
warburg_panel: null
panofsky_layer: iconological
domain: ux
ulan_id: null
iso_standard: "9241-210:2019"
nng_url: "https://www.nngroup.com/articles/two-ux-gulfs-evaluation-execution/"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow:  {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [figma, whimsical]}
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[nng-ten-heuristics]]}
  - {type: derived_from, target: [[don-norman]]}
---

## Core observation

Don Norman 1988 *The Design of Everyday Things* 提出的**两道鸿沟**是 UX 最基本的分析框架：

- **执行鸿沟（Gulf of Execution）**：用户想做什么 vs 系统提供什么操作
- **评估鸿沟（Gulf of Evaluation）**：系统当前状态 vs 用户能否感知到这个状态

好的 UX = **让这两道鸿沟都尽量窄**。坏的 UX 通常在这两道鸿沟的一侧或双侧溢出。

这不是品味问题，是**认知科学事实**——来自 Norman 在 UCSD 的 HCI 实验室研究。

<!-- llm:section-start prompts -->
## Prompts

### UX flow prompt (compatible: figma, whimsical)

```
[pre-iconographic]
  User: designer analyzing an existing feature for cognitive friction
  Task: identify where each gulf exists on a given flow
  Output: annotated flow diagram with gulf markers

[iconographic]
  State machine (mermaid):
  ```mermaid
  stateDiagram-v2
    UserIntent --> SystemInput : [execution gulf: affordance clear?]
    SystemInput --> SystemState
    SystemState --> UserPerception : [evaluation gulf: status visible?]
    UserPerception --> UserIntent : compare perceived to intended
  ```
  Overlay two gulfs on any existing flow.

[iconological]
  NN/g heuristic #1 (system status visible) addresses evaluation gulf
  NN/g heuristic #6 (recognition > recall) addresses execution gulf
  ISO 9241-110 self-descriptiveness principle = both gulfs

[lineage]
  Norman, *Design of Everyday Things* (1988, rev 2013) ch. 2
  NN/g: https://www.nngroup.com/articles/two-ux-gulfs-evaluation-execution/
  ISO 9241-210:2019
```

### UI / image / video 省略（UX 条目主载荷在 ux_flow）
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconological — 两道鸿沟是对"人机交互"世界观的根本阐释，不是视觉描述
- **Wikidata**: [Q1139117](https://www.wikidata.org/wiki/Q1139117)
- **ISO**: [9241-210:2019](https://www.iso.org/standard/77520.html)
- **NN/g**: [Two UX Gulfs](https://www.nngroup.com/articles/two-ux-gulfs-evaluation-execution/)
- **Primary source**: Norman, *Design of Everyday Things* (1988, 修订版 2013) 第 2 章
- **参考书架**: [[_refs/_domains/ux]]（Norman 著作是 UX canonical #1）
<!-- llm:section-end academic-lineage -->
