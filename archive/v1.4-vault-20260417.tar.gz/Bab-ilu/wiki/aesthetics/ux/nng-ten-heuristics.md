---
id: nng-ten-heuristics
type: aesthetic
title: Nielsen 十大可用性启发式 · UX 评价骨架
aliases: [Ten Usability Heuristics, Nielsen Molich 1990]

# Controlled-vocabulary trio
aat_id: null
aat_uncertainty: "candidate: aat:300265627 (usability) — too broad, NN/g corpus is primary"
wikidata: "Q17014339"                        # Usability heuristics
wikidata_uncertainty: null
iconclass: null                              # N/A — no depicted subject matter

# Warburg / Panofsky
warburg_panel: [[geometric-silence]]          # formal-minimum lineage — UX and Swiss-International share Occam's razor
panofsky_layer: iconological
domain: ux
lineage_depth: 2

# Institutional IDs
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: "9241-110:2020"                 # ISO 9241-110 Interaction Principles — NN/g heuristics align closely
nng_url: "https://www.nngroup.com/articles/ten-usability-heuristics/"

# Multi-modality prompts (ux domain — ux_flow required)
prompts:
  ui:
    generated: 2026-04-16
    last_tested: null
    test_score: null
  image:
    generated: 2026-04-16
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney, flux]
  video:
    generated: 2026-04-16
    last_tested: null
    test_score: null
    compatible_models: [runway]
  ux_flow:
    generated: 2026-04-16
    last_tested: null
    test_score: null
    compatible_tools: [figma, framer, whimsical, miro]
  painting: null
  motion: null

language: zh
original_terms:
  - term: "10 Usability Heuristics for User Interface Design"
    lang: en
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[geometric-silence]]}
  - {type: derived_from, target: [[jakob-nielsen]]}
  - {type: applies, target: [[iso-9241-210-hcd-cycle]]}
---

## 视觉物证

> Jakob Nielsen & Rolf Molich, original 1990；Nielsen NN/g 1994 revised to 10
> Canonical URL: https://www.nngroup.com/articles/ten-usability-heuristics/

_(UX 启发式无视觉物证；骨架本身即视觉——10 条规则就是这张卡的视觉证据)_

## Core observation

**NN/g 十大启发式是 UX 评价的事实标准**。不是产品需求，不是设计规范——是**评价现有界面是否"合格"的底线检查表**。

1. Visibility of system status —— 系统当前状态可见
2. Match between system and real world —— 用户的心理模型匹配
3. User control and freedom —— 撤销与逃生
4. Consistency and standards —— 跨界面一致
5. Error prevention —— 防错优于纠错
6. Recognition rather than recall —— 识别优于回忆
7. Flexibility and efficiency of use —— 新手可用，老手可快
8. Aesthetic and minimalist design —— 美学与最小化
9. Help users recognize, diagnose, and recover from errors —— 错误可理解
10. Help and documentation —— 文档可达

Bab-ilu 把这 10 条作为所有 **`ux` 域 Aesthetic 条目**的 `[iconological]` 段引用骨架——任何 UX 产出若不能援引至少一条启发式作为评价基础，属于未完成的工作。

这张卡的"iconological 层"：**NN/g 十条与 Swiss-International Typography 精神同源**——都来自"让复杂性退到幕后、让关键信号浮到前台"的 20 世纪后期设计理性主义。`[[geometric-silence]]` 面板的 Pathosformel 跨到了 UX 域。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt

```
[pre-iconographic] evaluation dashboard UI. palette: oklch(98% 0.005 240) background, oklch(20% 0.02 240) text, oklch(55% 0.18 140) success, oklch(58% 0.22 30) error. typography: IBM Plex Sans for UI, JetBrains Mono for heuristic IDs. grid: 12-col with large gutters. each heuristic as card with: number + name + 1-line definition + "current score" slider.
[iconographic] usability audit tool aesthetic; minimal, accessible, WCAG 2.2 AA compliant contrast ratios.
[iconological] rigor without decoration. every pixel accountable.
[lineage] Warburg panel: [[geometric-silence]] · NN/g 10 Heuristics · ISO 9241-110:2020 interaction principles
```

### Image prompt (compatible: midjourney v6+, flux)

```
[pre-iconographic] clean flat illustration, single color palette (white background + oklch(60% 0.2 240) blue), 10 icons arranged in 2×5 grid, each icon representing one heuristic by literal metaphor (e.g. #1 Visibility: open eye; #5 Error prevention: shield), IBM Plex labels below each, thin 1.5px stroke weight.
[iconographic] editorial illustration style, late-2020s Nielsen Norman Group article hero image.
[iconological] clarity as design virtue.
[lineage] Warburg panel: [[geometric-silence]] · NN/g · ISO 9241 lineage
--ar 16:9 --style raw
```

### Video prompt (compatible: runway gen-3)

```
[pre-iconographic] 10-second animated sequence. each heuristic icon appears for 1 second with number + name label. no scene changes, pure kinetic typography over white. easing: Material Expressive standard-emphasized 400ms stagger between items.
[iconographic] explainer video micro-genre for digital design education.
[iconological] pedagogy as pacing.
[lineage] NN/g 10 Heuristics
duration: 10s · transition: 1s per heuristic crossfade
```

### UX flow prompt (v1.4 — compatible: figma, framer, whimsical, miro)

```
[pre-iconographic]
  User: product designer evaluating an existing mobile app
  Task: identify which Nielsen heuristic violations exist on a given screen
  Context: design review session, 45 minutes allotted
  Device: desktop (Figma + browser)
  Constraints: no access to analytics; purely heuristic walkthrough

[iconographic]
  Information architecture:
    Input: screenshot upload or Figma file embed
    Analysis: 10-heuristic checklist with scoring (1-5 per heuristic)
    Output: violation report with screenshot annotations + prioritized fix list

  State machine (mermaid):
  ```mermaid
  stateDiagram-v2
    [*] --> Upload
    Upload --> Scoring : screens loaded
    Scoring --> Review : all 10 scored
    Review --> Report : reviewer confirms
    Review --> Scoring : edit scores
    Report --> [*]
  ```

  Navigation: linear walk-through, but support quick-jump between heuristics via sidebar.
  Persona: mid-level UX designer with 2-5 years heuristic-evaluation experience.

[iconological]
  Heuristic compliance the UI itself must meet:
    - H1 Visibility of system status — progress indicator visible at all times
    - H4 Consistency and standards — use Figma canonical evaluation patterns
    - H6 Recognition over recall — checklist visible, not from memory
    - H8 Aesthetic and minimalist design — no decorative graphics
  ISO 9241-110:2020 alignment: suitability for the task · self-descriptiveness · error tolerance

[lineage]
  NN/g: [10 Usability Heuristics for UI Design](https://www.nngroup.com/articles/ten-usability-heuristics/)
  Nielsen, *Usability Engineering* (1993) ch. 5
  ISO 9241-110:2020 Interaction Principles
  ISO 9241-210:2019 Human-centred design
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**: [[geometric-silence]] —— 功能主义几何沉默 Pathosformel 从 Bauhaus / Swiss-International 延续到 1990 Nielsen 十条的理性主义脉络
- **Panofsky 层**: iconological —— 十条启发式不是视觉对象，是**评价原则**；其"图像学"意义在于代表了 20 世纪末数字界面从"拟物"到"功能可见"的世界观转向
- **Getty AAT**: _(N/A — AAT 没有 NN/g 启发式对应条目；NN/g 自身是词表权威)_
- **Iconclass**: _(N/A — 无描绘主题)_
- **Wikidata**: [Q17014339](https://www.wikidata.org/wiki/Q17014339)
- **NN/g canonical**: [10 Usability Heuristics for UI Design](https://www.nngroup.com/articles/ten-usability-heuristics/)
- **ISO standard**: [ISO 9241-110:2020](https://www.iso.org/standard/75258.html) Interaction principles
- **跨传统笔记**:
  - 设计理论源头：Don Norman *The Design of Everyday Things* (1988) "gulfs of execution and evaluation"
  - 认知心理学根基：Allen Newell & Herbert Simon *Human Problem Solving* (1972)
  - 同代平行：Bruce Tognazzini *Tog on Interface* (1992)
  - 跨领域映射：Swiss-International Typography 的"功能第一"立场 → Apple HIG → Material Design → 各家设计系统
- **参考书架**: [[_refs/_domains/ux]]（Norman · Nielsen · Krug · Cooper · Young）· [[_refs/_institutions/nng]]（研究库权威）
<!-- llm:section-end academic-lineage -->
