---
id: iso-9241-210-hcd-cycle
type: aesthetic
title: ISO 9241-210 以人为本设计迭代循环
aliases: [Human-centred Design, HCD Cycle]
aat_id: null
wikidata: "Q30588751"
iconclass: null
warburg_panel: null
panofsky_layer: iconological
domain: ux
iso_standard: "9241-210:2019"
nng_url: "https://www.nngroup.com/articles/iso-9241/"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow:  {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [figma, miro]}
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: applies, target: [[nng-ten-heuristics]]}
---

## Core observation

ISO 9241-210:2019 是**以人为本设计**的国际标准化流程规范。5 阶段循环：

1. Plan the human-centred design process
2. Understand and specify the context of use
3. Specify the user requirements
4. Produce design solutions to meet these requirements
5. Evaluate the designs against requirements → back to 2

迭代直到满足要求。这不是推荐，是**可 audit 的标准**——企业 ISO 9001 合规时会查。

ISO 9241-210 定义的 4 条 HCD 原则：explicit user understanding · user involvement · iteration · multidisciplinary teams。任何 UX 流程条目的 `[iconological]` 段应能映射到这 4 条。

<!-- llm:section-start prompts -->
## Prompts

### UX flow prompt

```
[pre-iconographic]
  User: UX lead in a regulated industry (medical / finance / public sector)
  Task: structure the team's design process to be ISO 9241-210 auditable
  Context: multi-sprint project, mixed-discipline team

[iconographic]
  HCD cycle (mermaid):
  ```mermaid
  stateDiagram-v2
    [*] --> Plan
    Plan --> Context : initial
    Context --> Requirements
    Requirements --> Design
    Design --> Evaluate
    Evaluate --> Context : re-iterate
    Evaluate --> [*] : requirements met
  ```
  Each state = audit gate with artifact (context document, requirements spec, design deliverable, eval report).

[iconological]
  Heuristic alignment: NN/g #2 (match user's world) + #9 (help recover from errors) both require Phase 2 (Context of use) as prerequisite.
  ISO 9241-11:2018 usability = effectiveness + efficiency + satisfaction — the Evaluate phase's 3 metrics.

[lineage]
  ISO 9241-210:2019
  ISO 9241-11:2018
  NN/g: https://www.nngroup.com/articles/iso-9241/
  Kim Goodwin, *Designing for the Digital Age* (2009) chs 4-7 operationalize these phases
```

### 其余模态省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconological — 以人为本的世界观声明（不是方法论trick）
- **Wikidata**: [Q30588751](https://www.wikidata.org/wiki/Q30588751)
- **ISO**: [9241-210:2019](https://www.iso.org/standard/77520.html) + [9241-11:2018](https://www.iso.org/standard/63500.html)
- **NN/g**: [ISO 9241](https://www.nngroup.com/articles/iso-9241/)
- **参考书架**: [[_refs/_domains/ux]] · [[nng]]
<!-- llm:section-end academic-lineage -->
