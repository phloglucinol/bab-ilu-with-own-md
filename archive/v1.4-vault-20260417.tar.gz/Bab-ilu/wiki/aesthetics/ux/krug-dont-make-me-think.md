---
id: krug-dont-make-me-think
type: aesthetic
title: Krug "别让我思考" · 显然性原则
aliases: [Don't Make Me Think, Obvious]
aat_id: null
wikidata: "Q5292540"
iconclass: null
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: ux
nng_url: "https://www.nngroup.com/articles/scrolling-and-attention/"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow:  {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [figma, whimsical]}
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.85
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: applies, target: [[nng-ten-heuristics]]}
  - {type: frames, target: [[geometric-silence]]}
---

## Core observation

Steve Krug 2000 *Don't Make Me Think* 的核心命题：**用户不"使用"网页，用户扫描网页**（scan, not read）。显然性（obvious）>>可用性（usable）>>可理解性（understandable）。

三条 Krug's Laws:
1. Don't make me think — page should be obvious, self-evident
2. Doesn't matter how many times I have to click, as long as each click is a mindless choice
3. Get rid of half the words on each page, then get rid of half of what's left

Krug 的方法论：**5-second test**（一个陌生用户看页面 5 秒后能说出这是什么吗？）和 **Guerrilla Usability**（咖啡馆做 3 人快速测试）。

这和 [[geometric-silence]] 面板的 Pathosformel 同源——让**复杂性退居幕后**的 20 世纪现代主义立场延续到数字界面。

<!-- llm:section-start prompts -->
## Prompts

### UX flow prompt

```
[pre-iconographic]
  User: evaluator running a 5-second test on a landing page
  Task: verify the page passes Krug's obvious-ness threshold
  Scenario: show 5 users the page for 5 seconds each, ask "what is this for?"
  Pass threshold: 4 of 5 answer correctly

[iconographic]
  5-second test flow (mermaid):
  ```mermaid
  stateDiagram-v2
    [*] --> ShowPage : 5s exposure
    ShowPage --> AskPurpose : "What does this product do?"
    AskPurpose --> Record
    Record --> Threshold : ≥4/5 correct?
    Threshold --> Ship : yes
    Threshold --> Revise : no — find what's missing from viewport
    Revise --> ShowPage
  ```
  Decision criteria: tagline visible? hero image communicates domain? CTA text starts with verb?

[iconological]
  NN/g heuristic #1 (system status) + #8 (aesthetic minimalism) converge here
  Krug's rule aligns with Bauhaus / Swiss-International principle of reducing until clarity emerges
  Warburg panel [[geometric-silence]] Pathosformel: "less is revealed by what's taken away"

[lineage]
  Krug, *Don't Make Me Think* (2000, rev 2014)
  Krug, *Rocket Surgery Made Easy* (2010) — 测试方法论详展
  NN/g: https://www.nngroup.com/articles/scrolling-and-attention/
```

### 其余模态省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[geometric-silence]] — "减到清晰"的 Pathosformel 跨越 Bauhaus / Swiss International / Krug
- **Panofsky 层**: iconological — scan-not-read 是对注意力的时代诊断，不只是方法
- **Wikidata**: [Q5292540](https://www.wikidata.org/wiki/Q5292540)
- **Primary source**: Krug, *Don't Make Me Think* (2000, 第 3 版 2014)
- **NN/g**: [Scrolling and Attention](https://www.nngroup.com/articles/scrolling-and-attention/)
- **参考书架**: [[_refs/_domains/ux]]
<!-- llm:section-end academic-lineage -->
