---
id: apple-hig-visionos-depth
type: aesthetic
title: Apple visionOS · 空间深度作为 UI 维度
aliases: [visionOS HIG, Spatial Computing UI]
aat_id: "300047450"
wikidata: "Q117519330"
iconclass: null
warburg_panel: null
panofsky_layer: iconological
domain: ui
iso_standard: "9241-110:2020"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: null
  motion: {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [swiftui, reality-composer-pro]}
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: volatile
confidence: 0.85
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: extends, target: [[jony-ive-apple-hig]]}
---

## Core observation

Apple visionOS (Vision Pro 2024 起) 把 UI 的 **深度** 从视觉隐喻提升为**真实物理维度**。窗口不再是平面上的卡片，而是在空间里的实体——有真实阴影投到墙上、有真实遮挡、有真实反射。

UI 材质 **"Glass"** 是整个系统的核心设计决定：半透明、带模糊、带环境光反射——让 UI 元素**与物理环境融合**而非覆盖。这是 iOS "frosted glass"（iOS 7 2013 起）的物理延伸。

设计哲学延续：Jony Ive 时代 "truth to materials" 原则的**空间计算版本**——在 XR 里"材料"不是 skeuomorphic 伪造木纹，而是实际的光学行为（glass 的折射真实由 Metal GPU 计算）。

对 UI 传统的冲击：**z-axis 成为一等布局维度**。SwiftUI Layout Protocol 增加了 Depth axis。以前 design-system 的"elevation"是阴影骗术，现在是真实物理距离。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt

```
[pre-iconographic]
  Material: `.thin` / `.regular` / `.thick` glass background (SwiftUI Material)
  typography: San Francisco SF Pro (dynamic size based on viewing distance)
  layout: 3-axis (x, y, z-depth)
  -- window at 1.5m distance default
  -- ornaments (toolbar palette) attached to window at +0.1m depth
  -- volumes (3D objects) anchored to world space
  color: enhanced for pass-through display (higher luminance headroom, avoid pure black)
  interaction: eye + pinch (not touch, not mouse), gaze-targeted with 150ms dwell

[iconographic]
  Apple visionOS 2024+, Vision Pro spatial computing

[iconological]
  "truth to materials" 哲学的空间延伸 — UI 不是覆盖在环境之上, 而是环境的一部分
  对 iOS/macOS 传统的深度重构, 但严格守住 Ive 时代 material honesty 原则

[lineage]
  Apple visionOS HIG: https://developer.apple.com/design/human-interface-guidelines/designing-for-visionos
  iOS 7 frosted glass (2013) → iOS 26 expanded glass (2024) → visionOS spatial glass (2024)
  Jony Ive "truth to materials" doctrine
  Dieter Rams 原则 #3 "Good design is aesthetic" — 扩展到空间材质的美学诚实性
```

### Motion prompt (v1.4)

```
[pre-iconographic]
  Window summon: from 0 → visible, 0.8s total
  -- 0-0.2s: material loading (transparent → glass)
  -- 0.2-0.6s: depth interpolation (from 0.5m to final distance)
  -- 0.6-0.8s: settle with subtle spring overshoot

[iconographic]
  Apple Spring: response 0.55, damping 0.825 (SwiftUI `.interactiveSpring`)
  Reality Composer Pro animation preset

[iconological]
  Motion conveys window 作为物理对象而非图层
  节奏 = 像真实物体从后面浮出, 而不是 popup 突然出现

[lineage]
  SwiftUI + RealityKit animation doctrine
  Apple HIG Motion: https://developer.apple.com/design/human-interface-guidelines/motion
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconological —— 空间计算 UI 的世界观（UI 即环境，不是其上的图层）
- **AAT**: [300047450](http://vocab.getty.edu/aat/300047450) UI design
- **Wikidata**: [Q117519330](https://www.wikidata.org/wiki/Q117519330) visionOS
- **ISO**: [9241-110:2020](https://www.iso.org/standard/75258.html)
- **官方文档**: https://developer.apple.com/design/human-interface-guidelines/designing-for-visionos
- **跨传统**: Ivan Sutherland 1968 Sword of Damocles → Xerox PARC 3D → Oculus CV1 → visionOS 2024
- **参考书架**: [[_refs/_domains/ui]] · [[jony-ive-apple-hig]]（Ive 血统直接上游）
<!-- llm:section-end academic-lineage -->
