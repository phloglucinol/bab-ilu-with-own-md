---
id: material-expressive-2025
type: aesthetic
title: Material 3 Expressive · 表达性几何
aliases: [Material You Expressive, Material 3 2025]
aat_id: "300047450"
wikidata: "Q22330367"
iconclass: null
warburg_panel: [[geometric-silence]]
panofsky_layer: iconographic
domain: ui
iso_standard: "9241-161:2016"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: null
  motion: {generated: 2026-04-16, last_tested: null, test_score: null, compatible_tools: [jetpack-compose, rive, framer-motion]}
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: volatile
confidence: 0.85
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[geometric-silence]]}
  - {type: supersedes, target: [[material-design-3]]}
---

## Core observation

Google Material Design 2025 "Expressive" 版本是 Material 的**情感化转折**。从 2014 年诞生以来一贯的"理性几何"加入了**情绪表达**——不是装饰，而是通过 motion 曲线和 color role 的更强对比承载**情感权重**。

核心变化：
- **motion** 从 emphasized 分成 `standard-emphasized` 和 `expressive-emphasized`，后者有更大 overshoot 和 settle
- **shape 系统** 从 round-corner-only 扩展到 17 种 named shape（corner, scoop, square, pentagon...）
- **color role** 从 13 扩展到 `source-color-driven` dynamic tokens（基于用户壁纸或品牌色自动生成 palette）

对 [[geometric-silence]] Pathosformel 的**张力**：Material 历来是该面板的当代成员（"让复杂性退居幕后"），Expressive 版本是第一次**让 UI 几何本身成为表达载体**——但仍守住几何基础，不退回拟物。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt

```
[pre-iconographic]
  palette: source-color-driven tokens (示例基色 oklch(62% 0.18 145))
  -- primary / on-primary / primary-container / on-primary-container
  -- secondary / tertiary (auto-generated 30° offset hue)
  -- surface / surface-variant / surface-container (3 tiers of tonal surface)
  typography: Google Sans + Roboto Flex (variable font, weight 100-1000)
  shape: 17-token system (none / extra-small / small / medium / large / extra-large + corner/scoop/square/pentagon/etc.)
  elevation: 6 levels (0-5), each with specific shadow + surface-tint

[iconographic]
  Android 16 / Wear OS 5 / Chrome OS 2025 official design language
  当代 system UI，消费级产品默认

[iconological]
  从纸张隐喻 (2014) → 动态色 (2021) → 表达性几何 (2025)
  Pathosformel [[geometric-silence]] 的当代节点，但承认几何本身可以有情感重量

[lineage]
  Warburg panel: [[geometric-silence]]
  Google Material 3 Expressive: https://m3.material.io/blog/material-3-expressive
  ISO 9241-161:2016 (Visual UI elements)
```

### Motion prompt (v1.4)

```
[pre-iconographic]
  Button press: scale from 1.0 → 0.96 → 1.02 → 1.0
  Duration: 350ms total (150ms down / 200ms return with overshoot)
[iconographic]
  Material 3 expressive-emphasized easing curve
  Jetpack Compose: `MaterialMotion.expressive().emphasizedIn()`
  Framer Motion equivalent: `transition: { type: "spring", stiffness: 280, damping: 16 }`
[iconological]
  Press communicates material responsiveness + subtle playfulness (overshoot 通知 user input 被接收)
[lineage]
  Material 3 Motion https://m3.material.io/styles/motion/expressive
  Apple Human Interface Guidelines Motion chapter (parallel doctrine)
```

### image / video / ux_flow / painting 省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Warburg 面板**: [[geometric-silence]] — 当代 UI 节点
- **Panofsky 层**: iconographic —— 具体 design system 而非哲学抽象
- **AAT**: [300047450](http://vocab.getty.edu/aat/300047450) UI design
- **Wikidata**: [Q22330367](https://www.wikidata.org/wiki/Q22330367)
- **ISO**: [9241-161:2016](https://www.iso.org/standard/60476.html)
- **官方文档**: https://m3.material.io + https://m3.material.io/styles/motion/expressive
- **跨传统**: Bauhaus → Swiss International → Apple HIG → Material 1 2014 → Material You 2021 → Material 3 Expressive 2025
- **参考书架**: [[_refs/_domains/ui]] · [[_refs/_domains/graphic]]
<!-- llm:section-end academic-lineage -->
