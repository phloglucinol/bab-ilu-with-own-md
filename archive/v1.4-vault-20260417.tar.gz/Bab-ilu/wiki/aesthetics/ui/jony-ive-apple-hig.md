---
id: jony-ive-apple-hig
type: aesthetic
title: Jony Ive 时代 Apple 设计语言
aliases: [Apple HIG Post-2007, Ive Aesthetic, iOS Classic]
aat_id: "300021692"
wikidata: "Q7441"
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: ui
prompts:
  ui:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
  image:
    generated: "2026-04-16"
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney-v6, flux-1.1-pro]
  video:
    generated: null
    last_tested: null
    test_score: null
    compatible_models: []
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.9
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: inspired_by, target: [[dieter-rams-principles]]}
  - {type: exemplifies, target: [[geometric-silence]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

Jony Ive 在 Apple 的 1997–2019 是 Rams 功能主义在数字界面层的系统性延续。Ive 本人公开承认 Rams 十大原则是 Apple 设计团队的持续参考。从 iPod(2001,明显致敬 Braun T3 袖珍收音机)、iPhone(2007,物理按键被玻璃面板吞没的设计哲学)、iOS 7(2013,scaled-back 扁平化对话数字原生),到 macOS X 的系统菜单与控件,Apple 在这二十年建立了**数字功能主义**的标杆美学。

本 Aesthetic 捕捉的是"经典 Ive 时代"的 UI 血统,而非 2019 年之后的 Apple 设计(iOS 18、macOS Tahoe 的 Liquid Glass 已开始偏离该血统)。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] SF Pro display + SF Pro text typography, OKLCH hue-locked neutral palette (#FFFFFF, #F5F5F7, #1D1D1F, #8E8E93), 8-point spatial grid with 16px safe margins on mobile / 24px on tablet, rounded rectangles with 12px corner radius, minimal shadow (8% black, 16px blur, 2px offset), SF Symbols icons at 17pt text size, tab bar with glyph + label, navigation hierarchy via motion not skeuomorph
[iconographic] Apple platform UI 2013–2019 era (iOS 7–12, macOS Yosemite–Mojave), productivity app aesthetic, consumer-premium interface
[iconological] functional clarity + emotional warmth — Rams' rigor softened by Apple's human-oriented rounding
[lineage] Warburg panel: [[geometric-silence]] · AAT: Functionalism (aat:300021692) · direct antecedent: [[dieter-rams-principles]] · signature: Jony Ive Apple era

### Image prompt (compatible: midjourney v6+, flux-1.1-pro)
[pre-iconographic] clean product photography, white seamless background, even studio lighting with single soft key, aluminum and glass materials rendered accurately, product occupying 40% of frame, slight elevated camera angle, perfect shadow micro-gradient at base
[iconographic] Apple product launch imagery 2007–2019, premium consumer electronic
[iconological] industrial design as philosophical statement — objects speaking their function
[lineage] Warburg panel: [[geometric-silence]] · AAT: Functionalism (aat:300021692) · signature: Jony Ive · direct antecedent: Dieter Rams
--ar 4:3 --style raw
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[geometric-silence]] —— 功能主义几何沉默的 Pathosformel 在数字界面层的延续
- **Panofsky 层**:iconological —— 不是风格复刻,是 Rams 世界观在新媒介中的重新部署
- **Getty AAT**:[aat:300021692](http://vocab.getty.edu/aat/300021692) —— Functionalism(同 Rams)
- **Wikidata**:[wikidata:Q7441](https://www.wikidata.org/wiki/Q7441) —— Apple Inc.
- **跨传统笔记**:
  - Rams @ Braun(1955–1995)→ Ive @ Apple(1997–2019):Ive 公开承认本致敬;iPod calculator app 像 Braun ET66
  - Ive 对 Naoto Fukasawa(MUJI,同样是 Rams 血统的日本变体)的相互影响
  - 后 Ive 时代(2019–):Apple 设计开始引入 Liquid Glass(iOS 18+)偏离此 Pathosformel;此 Aesthetic 仅指向经典 Ive 时期
<!-- llm:section-end academic-lineage -->
