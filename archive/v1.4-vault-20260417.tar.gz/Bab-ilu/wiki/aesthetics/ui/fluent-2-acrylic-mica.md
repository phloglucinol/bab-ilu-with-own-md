---
id: fluent-2-acrylic-mica
type: aesthetic
title: Microsoft Fluent 2 · Acrylic 与 Mica 材质系统
aliases: [Fluent Design 2, Acrylic Material, Mica Material]
aat_id: "300047450"
wikidata: "Q30320844"
iconclass: null
warburg_panel: null
panofsky_layer: iconographic
domain: ui
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.8
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: inspired_by, target: [[jony-ive-apple-hig]]}
---

## Core observation

Microsoft Fluent 2 (2022 起, Windows 11 默认) 是在 Apple/Google 之外的第三条 UI 线。对 Bab-ilu 意义：**多元化参考**——Fluent 的 Acrylic（半透明）和 Mica（固态渲染）材质系统是 Apple visionOS Glass 的 *平行独立发明*。

- **Acrylic** — 半透明，带 noise texture 和 blur，背景内容可透视。用于 flyout / 对话框 / 面板
- **Mica** — 从桌面壁纸采样 RGB 均值 + noise，生成**一次性染色**，然后固定。省 GPU（不做实时 blur），同时保留"系统个性"表达。用于窗口背景
- **Mica Alt** — 更强的壁纸采样对比，用于需要识别度的应用窗口

Fluent 2 vs Apple visionOS Glass 的对比分析：
- Apple Glass = 实时物理光学模拟（昂贵）
- MS Mica = 一次采样 + 静态渲染（廉价）
- 都服务同一目标：UI 与环境融合而非对抗

MS 有 Windows XP / Vista / Metro / Fluent 1 / Fluent 2 五个 UI 代，每代都是对 Apple 同代的**公开异议**——对 Bab-ilu 的 [[geometric-silence]] 面板来说是重要的非-Apple 参考点。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt

```
[pre-iconographic]
  palette: system-adaptive (Windows Accent Color driven, 18 preset hues + custom)
  typography: Segoe UI Variable (variable font, 8-72pt dynamic weight + spacing)
  material:
    -- Acrylic(thin): transparent, backdrop blur 80px, 20% black overlay, 1px noise
    -- Mica: sampled once from wallpaper, noise overlay, static (no live update)
    -- Mica Alt: higher wallpaper contrast for branding
  spacing: 4px base grid; component sizes 32/40/48px touch targets
  elevation: 4 levels with specific shadow specs

[iconographic]
  Microsoft Windows 11 / Office 365 / Teams 2022+ default
  非 Apple 血统的主流 UI 参考

[iconological]
  "UI 与 OS 环境融合" Pathosformel 的**非 Apple 实现**
  Mica 体现 Microsoft 传统的"资源克制"哲学 —— 不为材质真实性牺牲性能

[lineage]
  Microsoft Fluent 2: https://fluent2.microsoft.design
  Fluent 1 (2017) → Windows 11 Mica/Acrylic (2022) → Fluent 2 web/Office (2023)
  Platform parallel: Apple visionOS Glass (2024) — 相同目标不同实现
```

### 其余省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconographic —— 具体 design system
- **AAT**: [300047450](http://vocab.getty.edu/aat/300047450) UI design
- **Wikidata**: [Q30320844](https://www.wikidata.org/wiki/Q30320844) Fluent Design
- **官方文档**: https://fluent2.microsoft.design · https://learn.microsoft.com/en-us/windows/apps/design/style/mica
- **跨传统**: Metro (2012) → Fluent 1 (2017) → Mica (2022) → Fluent 2 (2023)
- **跨平台对照**: [[apple-hig-visionos-depth]] · [[material-expressive-2025]]
- **参考书架**: [[_refs/_domains/ui]]
<!-- llm:section-end academic-lineage -->
