---
id: dieter-rams-principles
type: aesthetic
title: Dieter Rams 十大设计原则与其 UI 后世
aliases: [Rams Ten Principles, Braun Aesthetic]
aat_id: "300021692"
aat_uncertainty: "aat 映射:Industrial design (aat:300054152) 更泛;Functionalism (aat:300021692) 更贴合本条目"
wikidata: "Q61624"
warburg_panel: [[geometric-silence]]
panofsky_layer: iconological
domain: ui
prompts:
  ui:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
  image:
    generated: "2026-04-16"
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney-v6, flux-1.1-pro]
  video:
    generated: null
    last_tested: null
    test_score: null
    compatible_models: []
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.9
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[jony-ive-apple-hig]]}
  - {type: extends, target: [[swiss-international-style]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

Rams 在 Braun(1955–1995)建立的十大设计原则——"less, but better" — 不是美学口号,是**构造一组可复用的设计判断规则**。Good design is innovative · useful · aesthetic · makes a product understandable · unobtrusive · honest · long-lasting · thorough · environmentally friendly · as little design as possible.

这十条是 20 世纪后半 功能主义美学在产品设计领域的晶体化;其视觉效果——**无装饰、严格网格、功能元素作为唯一视觉元素、中性灰白黑作为基调**——在 1990s–2010s 被 Apple(Jony Ive 明确致敬)、Braun 自身延续、MUJI、早期 iOS/OS X 继承,形成当代 UI 美学的核心血统之一。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] strictly 8-point grid system, OKLCH luminance palette from #000000 to #FFFFFF with one warm neutral accent (#D4C9B8 or equivalent), SF Pro or Helvetica Neue, generous negative space at 40%+ page coverage, functional icons at 24×24 with 1.5px strokes only, no decorative elements, zero shadow or minimal 2px blur at 8% opacity
[iconographic] Braun / early Apple product design language, late-capitalist minimalist product UI
[iconological] "less but better" — UI as transparent conduit to function, no self-assertion
[lineage] Warburg panel: [[geometric-silence]] · AAT: Functionalism (aat:300021692) · signature: Dieter Rams Ten Principles · successors: Jony Ive Apple HIG lineage

### Image prompt (compatible: midjourney v6+, flux-1.1-pro)
[pre-iconographic] pure white background, single product object at frame center, even diffuse studio light no shadow, color palette restricted to neutral gray #D4C9B8 with single black element, geometric composition with 1/3 rule, zero visual noise
[iconographic] Braun 1960s industrial object aesthetic, product photography in the Functionalist tradition
[iconological] Rams Ten Principles materialized — the object confesses its function without ornament
[lineage] Warburg panel: [[geometric-silence]] · AAT: Functionalism (aat:300021692) · signature: Dieter Rams at Braun
--ar 1:1 --style raw
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[geometric-silence]] —— 功能主义几何作为一种沉默的 Pathosformel,从 Bauhaus 到 Swiss International 到 Rams 到 Jony Ive 的连续谱系
- **Panofsky 层**:iconological —— 这不是"极简风格",是一种关于"设计作为诚实"的世界观
- **Getty AAT**:[aat:300021692](http://vocab.getty.edu/aat/300021692) —— Styles and Periods > Modern > Functionalism
- **Wikidata**:[wikidata:Q61624](https://www.wikidata.org/wiki/Q61624) —— Dieter Rams 本人
- **跨传统笔记**:
  - Walter Gropius, Bauhaus (1919) —— "form follows function" 的早期组织化
  - Max Bill, Swiss Design School Ulm (1950s) —— 把 Bauhaus 传到战后德国
  - Dieter Rams @ Braun (1955–1995) —— 把此原则在消费电子产品中连续应用 40 年
  - Jony Ive @ Apple (1997–2019) —— 在数字界面层重做 Rams:iPod 像 T3 袖珍收音机,macOS X 菜单像 Braun 控制面板
  - Naoto Fukasawa @ MUJI (1990s–) —— 日本战后变体,加入温度与材料触感
<!-- llm:section-end academic-lineage -->
