---
id: blade-runner-2049-orange-sublime
type: aesthetic
title: 银翼杀手 2049 橙色崇高
aliases: [Blade Runner 2049 Orange Sublime, BR2049 Las Vegas Wasteland]
aat_id: "300021045"
aat_uncertainty: "primary candidate: Neo-noir (aat:300021045); secondary Romantic Sublime has no direct AAT entry — recorded via cross-tradition notes"
wikidata: "Q21500755"
wikidata_uncertainty: null
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: cinema
prompts:
  ui:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
  image:
    generated: "2026-04-16"
    last_tested: 2026-04-17
    test_score: 1.0
    compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana, sdxl]
  video:
    generated: "2026-04-16"
    last_tested: null
    test_score: null
    compatible_models: [runway-gen3, sora, kling-1.6, pika]
  ux_flow: null
  painting: null
  motion: null
language: zh
original_terms:
  - term: "Pathosformel"
    lang: de
    note: "Warburg 术语:情感程式,无准确中译"
  - term: "Nachleben"
    lang: de
    note: "Warburg 术语:图像后世"
  - term: "Sublime"
    lang: en
    note: "美学哲学概念,康德《判断力批判》出处"
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.9
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: derived_from, target: "raw/images/demo/blade-runner-2049-las-vegas.jpg"}
  - {type: frames, target: [[caspar-david-friedrich-wanderer]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[blade-runner-2049-las-vegas.jpg|原帧|600]]

> Blade Runner 2049 (2017) · 导演 Denis Villeneuve · 摄影 Roger Deakins · K 走入拉斯维加斯沙尘废墟一镜

## 核心观察

这一帧把一个在艺术史上走了两百年的 Pathosformel 投射到后末日废墟里:一个孤身人形立在浩渺的橙黄色尘雾中,地平线被大气溶解,人物占画面不到百分之五,仰视角度让天幕吞没一切。这不是"废墟景观",而是**崇高**(Sublime)的一次当代转世——康德意义上的崇高,即有限理性存在者在无限自然面前同时被压迫与被提升的双重感。

这种 Pathosformel 不属于 Villeneuve,也不属于 Deakins。他们继承的是 1818 年 Caspar David Friedrich 的《雾海上的漫游者》所建立的视觉公式:**孤身人形以背影姿态立于吞没他的自然之中**。200 年间,这个公式穿过美国西部片(John Ford 的 Monument Valley)、东欧形而上学电影(Tarkovsky《潜行者》)、意大利现代主义(Antonioni《奇遇》),在 2049 年的 K 身上重新现形。

Deakins 的单色橙是母题的**重新物质化**——用 2017 年才有的大气粒子模拟、广色域投影、IMAX 后期曲线,重做一个与 1818 年同构的视觉任务。这就是 Warburg Nachleben:形式迁徙而不丢失本质。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] monochromatic warm amber (primary #c66a1f · deep #8a4315 · glow #f4a261 · silhouette #2b1a0c), OKLCH hue-locked palette with luminance stepping, single heavy-weight serif display pair Cormorant Garamond + Inter body, extreme negative-space ratio 85:15, horizon-as-divider layout anchoring content to lower third, dust-particle texture overlay 4% opacity
[iconographic] post-apocalyptic narrative product UI, environmental storytelling dashboard, climate-crisis editorial
[iconological] sublime solitude — interface as vast horizon the user inhabits briefly
[lineage] Warburg panel: [[sublime-solitude]] · AAT: Neo-noir (aat:300021045) · Romantic Sublime tradition · signature: Deakins cinematography applied to UI

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana, sdxl)
[pre-iconographic] monochromatic warm amber atmosphere, dense orange-brown dust haze obscuring horizon, single small human silhouette in long coat facing away, figure at center occupying 3% of frame, horizon line at 40% height, flat diffuse ambient light no directional shadow, atmospheric perspective dissolving distance, 70mm anamorphic wide shot compression, shallow cinematic depth with grain
[iconographic] post-apocalyptic desert wasteland, ruins invisible in haze, solitary wanderer in heavy coat, wide desolate terrain
[iconological] sublime solitude — finite figure before indifferent infinite, Kantian sublime re-enacted
[lineage] Warburg panel: [[sublime-solitude]] · AAT: Neo-noir (aat:300021045) · direct antecedents: Caspar David Friedrich 1818 · John Ford Monument Valley · Tarkovsky Stalker · signature: Denis Villeneuve / Roger Deakins Blade Runner 2049
--ar 2.39:1 --style raw --v 6

### Video prompt (compatible: runway gen-3, sora, kling 1.6, pika)
[pre-iconographic] 70mm anamorphic wide, static shot then imperceptible slow push-in over 6 seconds, figure walking away from camera at 2% frame height, dense amber dust haze obscuring 80% depth, flat diffuse light no shadow, no camera shake, suspended ambient particulate motion only
[iconographic] post-apocalyptic Las Vegas wasteland, figure in heavy winter coat, remnants of civilization implied but invisible
[iconological] sublime solitude arc — stillness across 6 seconds in which nothing changes and meaning deepens
[lineage] Warburg panel: [[sublime-solitude]] · AAT: Neo-noir (aat:300021045) · director signature: Denis Villeneuve · cinematographer signature: Roger Deakins · antecedent: Tarkovsky long-take meditation
duration: 6s · transition: hold — no cut
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[sublime-solitude]] —— 孤身立于浩渺中的 Pathosformel;跨越浪漫主义绘画、美国西部片、东欧形而上学电影、当代科幻
- **Panofsky 层**:iconological —— 这张图在图像志层(废墟+人物)之上,参与的是浪漫主义崇高的世界观结构,非某具体风格或时代标签
- **Getty AAT**:[aat:300021045](http://vocab.getty.edu/aat/300021045) —— Styles and Periods > Modern > Neo-noir(此为电影类型锚;Romantic Sublime 无直接 AAT 条目,通过跨传统笔记补充)
- **Wikidata**:[wikidata:Q21500755](https://www.wikidata.org/wiki/Q21500755) —— Blade Runner 2049 作品条目
- **跨传统笔记**:
  - 1818:Caspar David Friedrich《雾海上的漫游者》——德国浪漫主义确立"背影人形立于吞没性自然"这一视觉公式
  - 1939–1956:John Ford 在 Monument Valley 拍摄系列西部片,把此 Pathosformel 移植到美国神话叙事
  - 1960:Antonioni《奇遇》L'Avventura,空岛场景把同一公式带入现代主义疏离
  - 1979:Tarkovsky《潜行者》Stalker,在东欧形而上学语境中重构公式
  - 2017:Villeneuve & Deakins《银翼杀手 2049》——用数字大气、广色域投影、IMAX 曲线物质化同一公式
  - 2021:Villeneuve《沙丘》——延续这条谱系
<!-- llm:section-end academic-lineage -->

## 关联工作

本 Aesthetic 条目可与以下 vault 条目交叉阅读:

- [[roger-deakins]] — 摄影指导,提供 Pathosformel 的光学物质化方案
- [[denis-villeneuve]] — 导演,在当代科幻中反复调用此公式(2049 + Dune)
- [[caspar-david-friedrich-wanderer]] — 公式的视觉原型(1818)
- [[tarkovsky-stalker-long-take]] — 东欧形而上学的时间化变体
