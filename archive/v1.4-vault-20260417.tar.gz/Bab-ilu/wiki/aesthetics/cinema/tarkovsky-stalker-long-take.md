---
id: tarkovsky-stalker-long-take
type: aesthetic
title: Tarkovsky《潜行者》长镜头 Pathosformel
aliases: [Stalker 1979 long take, Zone aesthetic]
aat_id: null
aat_uncertainty: "AAT 对东欧艺术电影分类不深;候选 Soviet cinema 层级"
wikidata: "Q319920"
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: cinema
prompts:
  ui:    {generated: null, last_tested: null, test_score: null}
  image: {generated: null, last_tested: null, test_score: null, compatible_models: []}
  video: {generated: null, last_tested: null, test_score: null, compatible_models: []}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.9
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: inspired_by, target: [[caspar-david-friedrich-wanderer]]}
  - {type: frames, target: [[fromsoft-art-direction]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

Andrei Tarkovsky 《潜行者》(*Сталкер*, 1979)——142 分钟,改编自 Strugatsky 兄弟小说《路边野餐》。Zone 禁区是现实被某种不可知事件扭曲的空间,潜行者带领两位知识分子(作家与教授)进入以寻求实现愿望的"房间"。

本条目捕捉的是 Tarkovsky 在此片中的**长镜头-崇高**技术:

- 镜头常在 3–10 分钟之间,几乎无剪接
- 人物在画面中缓慢移动,占画面比例极小
- 水、雾、锈、植被的物质性被光学微距摄取
- 时间本身成为被观看的对象,而不是叙事载体

这是 [[sublime-solitude]] Pathosformel 的**时间化实现**——Friedrich 的静态崇高被拉伸到 21 秒、42 秒、5 分钟的连续体验。

## 在 vault 中的角色

作为 Pathosformel 的**东欧形而上学分支**关键节点。`taste-lineage` 识别具有类似时间感 + 废墟/自然 + 小人物的视觉时,应回溯到本条目。

Stalker 直接影响 FromSoftware 的 Souls 系列空间设计、Alex Garland 的 *Annihilation* (2018)、Villeneuve 的 *Arrival* (2016) 与《沙丘》系列的时间处理。

## 学术外部锚

- Wikidata: [Q319920](https://www.wikidata.org/wiki/Q319920)
- 核心研究:Geoff Dyer, *Zona* (2012) —— 镜头接镜头评注
- 导演自述:Tarkovsky, *Sculpting in Time* (1986) 第六章
