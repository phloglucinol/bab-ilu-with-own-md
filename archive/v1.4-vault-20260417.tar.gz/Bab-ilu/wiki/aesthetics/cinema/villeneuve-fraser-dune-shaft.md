---
id: villeneuve-fraser-dune-shaft
type: aesthetic
title: 沙丘体积光 · Fraser × Villeneuve
aliases: [Dune Volumetric Shaft, Villeneuve-Fraser Tenebrism]
aat_id: "300056145"
aat_uncertainty: null
wikidata: "Q22003218"
wikidata_uncertainty: "Q22003218 Dune 2021; if image is from Part Two (2024), correct QID is Q98058477"
warburg_panel: [[volumetric-light-descent]]
panofsky_layer: iconological
domain: cinema
prompts:
  ui:    {generated: "2026-04-16", last_tested: null, test_score: null}
  image: {generated: "2026-04-16", last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana, sdxl]}
  video: {generated: "2026-04-16", last_tested: null, test_score: null, compatible_models: [runway-gen3, sora, kling-1.6]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[volumetric-light-descent]]}
  - {type: inspired_by, target: [[caravaggio-calling-st-matthew]]}
  - {type: derived_from, target: "raw/images/demo/villeneuve-fraser-dune-shaft.jpg"}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[villeneuve-fraser-dune-shaft.jpg|Villeneuve 《沙丘》 · DP Greig Fraser|900]]

> Dune(Villeneuve,2021/2024) · DP Greig Fraser · 黑场 × 一束倾斜体积光 × 布团 / 人群局部被照亮

## 核心观察

这一帧把 Caravaggio 1600 年确立的 *tenebroso*(黑暗主义)语言,在 400 多年后、用 ARRI Alexa 传感器 + 实拍香料粉末 + 大型 LED 矩阵光源,**物质化**到了一个外星沙漠世界的黑夜里。画面的主角不是那堆匍匐的布衣人形,不是远处的机械体——**是光柱本身**。光在此是角色,是叙事,是审判者。

**重要纠错**:这一帧不是 Roger Deakins 拍的(他的合作代表作是《银翼杀手 2049》[[blade-runner-2049-orange-sublime]]),是 **Greig Fraser** 的手法。两人都与 Villeneuve 合作过,但视觉基因不同:
- Deakins:水平 + 橙色大气 + 人物小于空间(sublime 母题)
- Fraser:垂直光柱 + 黑场 + 光作为独立角色(tenebrism 母题)

把两人混淆是常见错误,Bab-ilu 作为知识系统必须对摄影署名保持精确。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] near-black canvas (#050608 background · #1a1f24 soft-black) with single diagonal warm-white light corridor (#fff4d6 → #2b1f14 gradient) occupying 25% of upper-right composition, OKLCH luminance-only focal strategy, content anchored inside the light corridor, extreme dark-field outside
[iconographic] cinema-adjacent premiere / film-heritage editorial / immersive-narrative product UI
[iconological] tenebrism as interaction register — light as meaning, darkness as quiet
[lineage] Warburg panel: [[volumetric-light-descent]] · AAT: Tenebrism (aat:300056145) · Chiaroscuro (aat:300056144) · signature: Fraser × Villeneuve 2020s-cinema translation

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana, sdxl)
[pre-iconographic] nearly-black frame with single diagonal volumetric light shaft descending from upper-right, visible through dust / spice-particulate / fine haze, illuminating small cluster of cloth-wrapped prone figures at lower-right, rest of frame in deep tenebrous black, subtle architectural / mechanical mass silhouetted in upper-right as light source, ARRI Alexa-style log exposure curve preserving highlight texture, no lens flare, cinemascope aspect, ambient dust particles drifting
[iconographic] Villeneuve-Fraser Dune visual idiom (2021-2024 film duology), post-Arrakis mood, Harkonnen / Fremen ritual context inferred
[iconological] tenebrism — the Caravaggio / Rembrandt tradition of light as divine / fated agent, reworked for 21st-century science fiction
[lineage] Warburg panel: [[volumetric-light-descent]] · AAT: Tenebrism (aat:300056145) · Cinematography (aat:300139140) · DP signature: Greig Fraser · director signature: Denis Villeneuve
--ar 2.39:1 --style raw --v 6 --s 80

### Video prompt (compatible: runway gen-3, sora, kling 1.6)
[pre-iconographic] 6-second locked-off wide shot 2.39:1, frame is 90% black, single volumetric light beam descending diagonally from upper-right visible through drifting fine particulate, light intensity modulates subtly (±5%) as if source is wind-affected, prone figures at lower-right unmoving except very slight cloth ripple, no camera motion, 24fps
[iconographic] Dune-film ritual or post-battle aftermath shot
[iconological] tenebrism arc — held silence, the weight of descent of meaning via light
[lineage] Warburg panel: [[volumetric-light-descent]] · AAT: Tenebrism (aat:300056145) · DP signature: Greig Fraser · director signature: Denis Villeneuve
duration: 6s · transition: hold · single sub-bass drone
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[volumetric-light-descent]] —— 体积光柱作为独立叙事角色的 Pathosformel,从 Caravaggio 1600 年到 Fraser 2024 年
- **Panofsky 层**:iconological —— 光在此不是视觉属性,是审判 / 命运的物化
- **Getty AAT**:[aat:300056145](http://vocab.getty.edu/aat/300056145) Tenebrism · [aat:300056144](http://vocab.getty.edu/aat/300056144) Chiaroscuro · [aat:300139140](http://vocab.getty.edu/aat/300139140) Cinematography
- **Wikidata**:[wikidata:Q22003218](https://www.wikidata.org/wiki/Q22003218) Dune 2021 · [wikidata:Q98058477](https://www.wikidata.org/wiki/Q98058477) Dune Part Two · [wikidata:Q5604108](https://www.wikidata.org/wiki/Q5604108) Greig Fraser
- **跨传统笔记**:Caravaggio《圣马太蒙召》(1600) → Rembrandt《夜巡》(1642) → Vermeer《画家的工作室》(1668) → Joseph Wright of Derby《气泵里的鸟实验》(1768) → Storaro《现代启示录》(1979) → Fraser《沙丘》(2021) · 《沙丘 · Part Two》(2024)。四百年视觉血统,载体从颜料 → 胶片 → 数字传感器,但光 - 暗结构恒定。
<!-- llm:section-end academic-lineage -->
