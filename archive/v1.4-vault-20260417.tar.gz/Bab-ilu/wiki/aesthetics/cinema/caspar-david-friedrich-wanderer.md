---
id: caspar-david-friedrich-wanderer
type: aesthetic
title: Caspar David Friedrich《雾海上的漫游者》(1818)
aliases: [Der Wanderer über dem Nebelmeer, Wanderer above the Sea of Fog]
aat_id: "300021263"
aat_uncertainty: "primary: Romanticism (aat:300021263); 本作为德国浪漫主义核心作品"
wikidata: "Q12293262"
warburg_panel: [[sublime-solitude]]
panofsky_layer: iconological
domain: cinema
prompts:
  ui:    {generated: null, last_tested: null, test_score: null}
  image: {generated: null, last_tested: null, test_score: null, compatible_models: []}
  video: {generated: null, last_tested: null, test_score: null, compatible_models: []}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[sublime-solitude]]}
  - {type: frames, target: [[blade-runner-2049-orange-sublime]]}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 核心观察

Caspar David Friedrich《雾海上的漫游者》(*Der Wanderer über dem Nebelmeer*, 1818)——油画,94.8 × 74.8 cm,汉堡艺术馆。

一位穿深色风衣的男性,背影,立于突出山岩之上,面对雾海中若隐若现的群山。这张画是 [[sublime-solitude]] Pathosformel 的**原始视觉确立**——19 世纪初德国浪漫主义把崇高从文字(Kant、Schiller)转为可识别的视觉公式。

所有后续 200 年沿此公式的作品——John Ford 西部片、Tarkovsky 长镜头、Deakins 《2049》——都可回溯到这张油画的构图:

- **人物背影**(观看者借其视角看)
- **人物占画面极小比例**(< 10%)
- **自然吞没性延展**(雾遮蔽中景)
- **大气感压过细节**(软化轮廓)

## 在 vault 中的角色

本条目作为 reference 供 `taste-lineage` subagent 在识别相关 Pathosformel 时反向追溯使用。用户可在未来 `/ingest` 更深入的版本(Friedrich 完整作品系列、浪漫主义理论、Werner Hofmann / Robert Rosenblum 的相关研究)以升级此条目。

## 学术外部锚

- Wikidata: [Q12293262](https://www.wikidata.org/wiki/Q12293262)
- Getty AAT:Romanticism [aat:300021263](http://vocab.getty.edu/aat/300021263)
- 藏地:Hamburger Kunsthalle
