---
id: tactical-anime-combat
type: aesthetic
title: 战术面罩红刃 · 近战半身像
aliases: [Tactical Anime Combat Portrait, Masked Red-Blade Operator]
aat_id: "300263552"
aat_uncertainty: "primary: Conceptual art, no single AAT for tactical-anime close-up portrait"
wikidata: null
wikidata_uncertainty: "Pixiv-origin work, artist lookup pending"
warburg_panel: [[tactical-feminine]]
panofsky_layer: iconographic
domain: illustration
prompts:
  ui:    {generated: "2026-04-16", last_tested: null, test_score: null}
  image: {generated: "2026-04-16", last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana]}
  video: {generated: "2026-04-16", last_tested: null, test_score: null, compatible_models: [runway-gen3, kling-1.6]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.82
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[tactical-feminine]]}
  - {type: derived_from, target: "raw/images/demo/tactical-anime-combat.jpg"}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[tactical-anime-combat.jpg|战术面罩红刃操作员|500]]

> 数字插画 · Pixiv · 粉发 × 战术面罩 × 红刃锯齿齐眉刀

## 核心观察

[[tactical-feminine]] 面板内以**近战 + 特写 + 色彩强对比**为主语汇的一支。与 [[falslander-infantry]] 的"远景冷峻 + 军官"不同,这张是**半身近景**——面罩覆盖下半脸、粉发红发圈作为唯一暖色、红刃锯齿从右下斜入、腰间绑带与护具堆叠的细节密度高。这是 2010s 后手游概念画的"操作员型"标准像:压缩景深、高细节、冷调主场 × 单一警示色。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] near-monochrome dark base (#1a1a1c · #2d2d30 · #4a4a4e gunmetal) with single warning accent (#d32b2b saturated red), OKLCH lightness steps, half-body close-up portrait framing 4:5, heavy grid-based info density, small caps labels
[iconographic] operator-profile dossier UI / tactical-game character-info card
[iconological] lethality at close range — UI as the moment before contact
[lineage] Warburg panel: [[tactical-feminine]] · AAT: Conceptual art (aat:300263552) · signature: Chinese-Japanese tactical-anime character-art tradition

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana)
[pre-iconographic] half-body close portrait of female operator, shoulder-length pink-blonde hair with red hair-band, black tactical face mask with red inner seal pattern covering mouth and nose, almond eyes visible above mask, black latex-like combat bodysuit with shoulder armor plates and waist utility belt, clenched right hand at chest level, left hand gripping serrated red-colored straight blade angled diagonally across frame, additional blade silhouette in lower-right frame, gray gradient background minimal, subtle red stitch details, studio-grade cel shading with soft gradient, focal compression like 85mm portrait
[iconographic] Chinese-Japanese tactical-anime concept-art, post-Girls-Frontline / Arknights / Punishing Gray Raven lineage, close-combat operator archetype
[iconological] weaponized intimacy — close-range lethality framed as portrait
[lineage] Warburg panel: [[tactical-feminine]] · AAT: Conceptual art (aat:300263552) · Military uniforms (aat:300209277) · signature: Chinese-Japanese tactical-anime close-up tradition
--ar 4:5 --style raw --v 6

### Video prompt (compatible: runway gen-3, kling 1.6)
[pre-iconographic] medium close-up half-body, subtle head turn over 4 seconds from looking-at-viewer to 15-degree off-axis, hair sways, blade remains locked in position, eyes narrow slightly, no camera motion, no zoom, 24fps
[iconographic] character-intro cutscene framing
[iconological] contact moment delayed — the portrait of readiness
[lineage] Warburg panel: [[tactical-feminine]] · AAT: Conceptual art (aat:300263552) · signature: operator-intro-cutscene tradition
duration: 4s · transition: hold · sub-bass and single metallic chime
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[tactical-feminine]] —— 武装女性 Pathosformel 的近战特写分支
- **Panofsky 层**:iconographic —— 战术面罩 + 红刃 + 粉发是 2020s 手游概念画的**文化约定**(每个元素都可识别),尚未完全进入 iconological 层的符号抽象
- **Getty AAT**:[aat:300263552](http://vocab.getty.edu/aat/300263552) Conceptual art · [aat:300209277](http://vocab.getty.edu/aat/300209277) Military uniforms
- **Wikidata**:相关概念 [wikidata:Q11488430](https://www.wikidata.org/wiki/Q11488430) 美少女
- **跨传统笔记**:与 [[falslander-infantry]] 为同一面板内的"远景/近景"两极;共同血统:Fate Saber 2004 → 少女前线 2016 → 明日方舟 2019 → 战双帕弥什 2019 → 蔚蓝档案 2021。本作体现近战特写子类型的当代节点。
<!-- llm:section-end academic-lineage -->
