---
id: ronin-solitary-blade
type: aesthetic
title: 浪人孤刃 · 斗笠双刀
aliases: [Ronin Solitary Blade, Japanese Wandering Warrior]
aat_id: "300021489"
aat_uncertainty: "primary: Ukiyo-e tradition via character-design lineage; no single AAT entry for digital concept art"
wikidata: "Q207408"
wikidata_uncertainty: null
warburg_panel: [[wandering-blade]]
panofsky_layer: iconological
domain: illustration
prompts:
  ui:    {generated: "2026-04-16", last_tested: null, test_score: null}
  image: {generated: "2026-04-16", last_tested: 2026-04-17, test_score: 0.9, compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana, sdxl]}
  video: {generated: "2026-04-16", last_tested: null, test_score: null, compatible_models: [runway-gen3, sora, kling-1.6]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.88
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[wandering-blade]]}
  - {type: derived_from, target: "raw/images/demo/ronin-solitary-blade.jpg"}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[ronin-solitary-blade.jpg|原图 · Pixiv 签名 "RONIN"|500]]

> 数字概念插画 · Pixiv 作者署名栏刻"RONIN" · 浪人女性 × 斗笠 × 紫黑双刀

## 核心观察

一条自浮世绘到当代 Pixiv 的 Pathosformel 的当代节点。画面通过极简背景(近乎纯白灰)、人物侧身 3/4 视角、斗笠压住视线使观者无法与角色对视、腰间双刀与身后枯枝的平衡构图,把**孤刃即身份**这一武者美学命题物化。

这不是战斗前的紧张,也不是战斗后的疲惫——是**介于二者之间的恒久停顿**。日本武者绘自葛饰北斋《武士绘》起就擅长这种"非情节时刻",2010 年代后被 Pixiv 数字插画生态重新激活。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] monochromatic warm-gray palette (#1a1a1a charcoal · #4a2c3d plum · #d4c5b5 parchment · #2b2b2b ink), vertical portrait composition 3:4, single serif display pair (Noto Serif JP + Inter), heavy negative space right-side, left-anchored content, brushed-paper texture overlay 4%
[iconographic] editorial fighting-game or narrative-RPG character showcase UI
[iconological] 孤刃即身份 — 界面让角色孤立感成为交互中的美学事件
[lineage] Warburg panel: [[wandering-blade]] · AAT: Ukiyo-e (aat:300021489) · signature: Pixiv digital concept-art tradition

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana, sdxl)
[pre-iconographic] single female figure, 3/4 side profile standing, wide-brim Japanese straw hat (ajirogasa / 斗笠) angled to conceal upper face, short dark hair visible beneath, black leather-and-silk modern hakama with purple interior reveal, dual katana strapped diagonally at back, left hand resting on wrapped hilt, knee-high heeled tabi boots on bare stone, single leafless branch in background right, minimal gradient paper background warm neutral to cool gray, watermark text "RONIN" small left-margin
[iconographic] contemporary concept-art reinterpretation of Edo-period ronin archetype, post-Nobushi, blend of traditional wafuku silhouette and modern tailoring
[iconological] armed solitude — the blade as identity rather than weapon, non-narrative pause
[lineage] Warburg panel: [[wandering-blade]] · AAT: Ukiyo-e (aat:300021489) · Japanese (aat:300018519) · signature: Pixiv character-design lineage
--ar 3:4 --style raw --v 6 --s 150

### Video prompt (compatible: runway gen-3, sora, kling 1.6)
[pre-iconographic] locked-off medium-wide shot, subject barely shifts weight from front foot to back foot over 5 seconds, kimono folds and purple silk inner reveal sway once, head remains at same angle, background branch motionless, no camera motion, ambient dust particles drift lateral
[iconographic] ronin concept-art in motion — idle animation aesthetics from high-end character action games (Sekiro, Ghost of Tsushima)
[iconological] 孤刃即身份 — the pause before or after the duel, not the duel itself
[lineage] Warburg panel: [[wandering-blade]] · AAT: Ukiyo-e (aat:300021489) · signature: Pixiv + game character-idle tradition
duration: 5s · transition: hold · ambient wind only
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[wandering-blade]] —— 孤身持刃者的 Pathosformel;从浮世绘武者绘经黑泽明浪人电影到当代 Pixiv 概念画
- **Panofsky 层**:iconological —— 画面不讲故事、不讲战斗,只讲"人与刃合一"的身份状态
- **Getty AAT**:[aat:300021489](http://vocab.getty.edu/aat/300021489) —— Styles and Periods > Asian > Japanese > Ukiyo-e(作为继承血统标注);具体媒介 [aat:300263552](http://vocab.getty.edu/aat/300263552) Conceptual art
- **Wikidata**:[wikidata:Q207408](https://www.wikidata.org/wiki/Q207408) —— 浪人 Ronin 概念实体
- **跨传统笔记**:葛饰北斋《武者绘》(1820s)→ 歌川国芳(1850s)→ 黑泽明《用心棒》(1961)→ 小岛刚夕《子连れ狼》(1970s)→ Pixiv 数字插画(2010s-)→ From Software《只狼》游戏概念艺术(2019)。本画作是这条 200 年链上 2020s 节点的一个典型样本。
<!-- llm:section-end academic-lineage -->
