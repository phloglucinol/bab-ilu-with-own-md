---
id: ribbon-verticality
type: aesthetic
title: 绑带纵构图 · 单人束缚即姿势
aliases: [Ribbon Verticality, Bound Posture as Composition]
aat_id: "300189621"
aat_uncertainty: "Illustration (aat:300189621) as container; specific 'ribbon-bound vertical illustration' has no AAT"
wikidata: null
wikidata_uncertainty: "source unidentified; likely Japanese digital illustrator"
warburg_panel: null
panofsky_layer: iconographic
domain: illustration
prompts:
  ui:    {generated: "2026-04-16", last_tested: null, test_score: null}
  image: {generated: "2026-04-16", last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana]}
  video: {generated: "2026-04-16", last_tested: null, test_score: null, compatible_models: [runway-gen3, kling-1.6]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: volatile
confidence: 0.7
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: derived_from, target: "raw/images/demo/ribbon-verticality.png"}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[ribbon-verticality.png|绑带纵向插画|400]]

> 数字插画 · 纵向构图 × 黑色绑带 × 纯白底 × 人物悬垂姿态

## 核心观察

本画的"美学事件"不是人物本身,而是**绑带构成的构图语法**——多条黑色绑带从画面顶部垂下,环绕人物身体形成垂直走廊,最长的一条一直延伸到画面底部外。人物位于绑带内部,姿态被绑带而非重力决定。这是日本绳师美学(Kinbaku/Shibari)在数字插画中的抽象化变体,与 Araki Nobuyoshi 的摄影传统和 2000 年代同人志插画亚文化有血缘关系,但本作**去情色化**,只保留"绑带作为构图法"的纯形式。

为何不归入面板:单张不足以稳定归属。若未来再收录 2–3 张同类(如 Araki 绳摄影、《少女终末旅行》部分分镜、池田学《心象风景》系列),可能建立 "Bound Line" Pathosformel 面板。当前暂不面板化。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] pure-white canvas (#ffffff) with sparse black graphic strokes (#0a0a0a), vertical composition 9:16, extreme verticality emphasis via left-anchored text column with long vertical rule, ample breathing room, single heavy-weight display + thin body
[iconographic] minimalist book-cover or editorial-long-form UI, manga-adjacent graphic direction
[iconological] constraint as composition — interface structure as the subject
[lineage] AAT: Illustration (aat:300189621) · signature: Japanese minimal-illustration tradition

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana)
[pre-iconographic] vertical composition 9:16, pure white background, single female figure suspended mid-frame with arms raised above head bound by thick black ribbons extending from top edge of frame, ribbons forming parallel vertical corridor around figure, one ribbon trails from figure's leg to bottom edge of frame extending beyond, character rendered in flat-shaded black-and-white anime style with minimal detail, hair and ribbons flowing with subtle motion, no ground plane, no background features
[iconographic] Japanese minimalist illustration, shibari-influenced graphic composition, book-cover or album-art aesthetic
[iconological] posture determined by constraint rather than gravity — form as line rather than mass
[lineage] AAT: Illustration (aat:300189621) · signature: Japanese minimal-vertical-illustration tradition
--ar 9:16 --style raw --v 6

### Video prompt (compatible: runway gen-3, kling 1.6)
[pre-iconographic] static 9:16 vertical frame, ribbons sway laterally with 2-second period, figure barely moves except hair swaying with ribbon motion, pure white background remains, no camera motion
[iconographic] vertical-illustration-in-motion for mobile portrait display
[iconological] sustained suspension — time as held breath
[lineage] AAT: Illustration (aat:300189621) · signature: Japanese-minimal vertical-anime tradition
duration: 5s · transition: hold · silence or single held note
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:_未归属_(单卡,待更多同类作品入库后评估)
- **Panofsky 层**:iconographic —— 绑带作为可识别文化符号(日本绳艺 / shibari 传统)构成画面的约定性语义
- **Getty AAT**:[aat:300189621](http://vocab.getty.edu/aat/300189621) Illustrations (documents)
- **Wikidata**:相关概念 [wikidata:Q1116027](https://www.wikidata.org/wiki/Q1116027) 緊縛 Kinbaku / Shibari
- **跨传统笔记**:Araki Nobuyoshi 1970s 绳摄影 → 1990s 同人志插画 → 2000s 小畑健等商业漫画分镜中的纵向压缩 → 2010s-2020s Pixiv 垂直构图风格。本作去情色化,保留纯形式语法,接近 2020s 独立插画师对该传统的**形式主义提纯**。
<!-- llm:section-end academic-lineage -->
