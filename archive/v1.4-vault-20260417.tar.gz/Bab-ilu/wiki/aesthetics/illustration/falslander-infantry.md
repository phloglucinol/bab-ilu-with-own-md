---
id: falslander-infantry
type: aesthetic
title: Falslander 步兵 · 军官剑姿
aliases: [Falslander Infantry, Military-Chic Anime Swordswoman]
aat_id: "300209277"
aat_uncertainty: "primary: Military uniforms; cross-cultural digital concept-art fusion, no single AAT for this hybrid genre"
wikidata: null
wikidata_uncertainty: "no Wikidata entity for Falslander artist yet; work documented on Pixiv and ArtStation"
warburg_panel: [[tactical-feminine]]
panofsky_layer: iconological
domain: illustration
prompts:
  ui:    {generated: "2026-04-16", last_tested: null, test_score: null}
  image: {generated: "2026-04-16", last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney-v6, flux-1.1-pro, nano-banana, sdxl]}
  video: {generated: "2026-04-16", last_tested: null, test_score: null, compatible_models: [runway-gen3, kling-1.6]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.85
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[tactical-feminine]]}
  - {type: derived_from, target: "raw/images/demo/falslander-infantry.jpg"}
iconclass: null
iconclass_uncertainty: null
ulan_id: null
met_id: null
moma_id: null
cooperhewitt_id: null
rijks_id: null
tate_id: null
nga_id: null
bfi_id: null
magnum_id: null
archnet_id: null
riba_id: null
loc_cai: null
gcd_id: null
moby_id: null
igdb_id: null
iso_standard: null
nng_url: null
---

## 视觉物证

![[falslander-infantry.jpg|Falslander 签名 · INFANTRY|600]]

> 数字概念插画 · Pixiv 作者署名栏 "FALSLANDER" · "INFANTRY"军官型白发双马尾 × 巨剑

## 核心观察

[[tactical-feminine]] 面板内以**军官化 + 冷峻单色**为主语汇的一支。与 [[tactical-anime-combat]] 的"近战面罩红刀"不同,这张是**远景剑姿**——巨剑低垂、军官帽压住眉眼、白发作为冷峻对比、脚下地砖作为唯一的"下方"锚点,其余背景抽象为白色纯场。这是 2010s 后中日手游产业(《少女前线》《明日方舟》《战双帕弥什》)高度模块化的"军官 OC(Original Character)"视觉语汇,但 Falslander 在保留这一语汇的同时注入更多**后极简画风**的留白与淡化光影。

<!-- llm:section-start prompts -->
## Prompts

### UI prompt
[pre-iconographic] cool-gray palette (#0f0f11 near-black · #4a4a4d gunmetal · #e8e8ea silver · #f5f5f7 white) · near-monochrome with single cold accent, portrait composition 9:16 or 3:4, geometric sans-serif pair (Söhne + IBM Plex Mono), center-heavy content with ample top negative space, thin 1px divider lines
[iconographic] military-chic strategy-game character profile UI / cold-war aesthetic dashboard
[iconological] quiet lethality — interface that commands without raising its voice
[lineage] Warburg panel: [[tactical-feminine]] · AAT: Military uniforms (aat:300209277) · signature: Falslander + modern tactical-anime concept-art tradition

### Image prompt (compatible: midjourney v6+, flux-1.1-pro, nano-banana, sdxl)
[pre-iconographic] single female figure in rear 3/4 view, peaked military officer's cap, long platinum-blonde hair in side-ponytail flowing lateral, black high-collar tunic with silver trim, tall black boots, prosthetic / gauntlet-armored right hand gripping enormous blade-weapon that extends 1.8x figure height, blade tip touching ground, subject stands on stone tile floor, everything else dissolves into pure off-white gradient background, minimal directional light from upper-right, watermark small "FALSLANDER" upper-left, text "INFANTRY" as thin horizontal rule mid-frame
[iconographic] military-chic anime concept-art, post-Girls-Frontline / Arknights lineage, officer-archetype character design
[iconological] weaponized femininity — the pose between orders, not during action
[lineage] Warburg panel: [[tactical-feminine]] · AAT: Military uniforms (aat:300209277) · Character design (aat:300263552) · signature: Falslander Pixiv tactical-anime tradition
--ar 3:4 --style raw --v 6

### Video prompt (compatible: runway gen-3, kling 1.6)
[pre-iconographic] locked-off medium-wide 3:4, subject's hair sways laterally as if wind from right, posture unmoving, blade unmoving, background pure off-white gradient, 24fps, no camera motion, no particles
[iconographic] character-select idle animation aesthetics, strategy-game intro cutscene
[iconological] held authority — the moment of waiting that precedes a command
[lineage] Warburg panel: [[tactical-feminine]] · AAT: Military uniforms (aat:300209277) · signature: Falslander / tactical-anime idle-animation tradition
duration: 5s · transition: hold · sub-bass drone
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源 (Academic Lineage)

- **Warburg 面板**:[[tactical-feminine]] —— 武装女性 + 工业武器 + 冷硬材质的 Pathosformel
- **Panofsky 层**:iconological —— 军官帽 + 巨剑不讲具体战斗,讲"权威与致死能力的合一"
- **Getty AAT**:[aat:300209277](http://vocab.getty.edu/aat/300209277) Military uniforms · [aat:300263552](http://vocab.getty.edu/aat/300263552) Conceptual art
- **Wikidata**:Falslander 作为独立画师尚无 Wikidata 条目;相关概念 [wikidata:Q11488430](https://www.wikidata.org/wiki/Q11488430) 美少女
- **跨传统笔记**:本支谱系较短但清晰——草薙素子《攻壳机动队》(1989/1995) → Fate Saber(2004) → 少女前线 HK416(2016) → 明日方舟 W(2019) → Falslander 个人作品(2020s)。30 年从"实验性成人向视觉文化"到"工业化手游角色谱系"再到"独立艺术家回归个人表达"的三阶段。
<!-- llm:section-end academic-lineage -->
