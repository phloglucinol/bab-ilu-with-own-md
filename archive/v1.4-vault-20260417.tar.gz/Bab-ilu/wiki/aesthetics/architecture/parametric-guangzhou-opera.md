---
id: parametric-guangzhou-opera
type: aesthetic
title: Zaha Hadid《广州大剧院》· 参数主义流动
aliases: [Guangzhou Opera House, Zaha Hadid Parametricism, 2010]
aat_id: "300264929"
wikidata: "Q1128094"
iconclass: "48C722"
warburg_panel: null
panofsky_layer: iconographic
domain: architecture
ulan_id: "500108087"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway, kling]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: stable
confidence: 0.85
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: inspired_by, target: [[brutalism-unite-dhabitation]]}
---

## Core observation

Zaha Hadid 2010 广州大剧院是**参数主义**（Parametricism）的代表作。Patrik Schumacher 2008 宣言之后第一批大体量建成作品。

设计命题：**用算法生成的连续曲面取代古典几何的柱/梁/墙**。整栋建筑是**双鹅卵石**（two pebbles）形态，外立面由 4000+ 块铸造花岗岩板拼成，每块几何都是独一无二的——**参数化生成**确保形式连续性，**数控加工**使独一无二成本可控。

对 Bab-ilu 建筑域的意义：提供 **非 [[geometric-silence]]** 的当代节点。Brutalism 是沉默的直角，Parametricism 是喧哗的流动曲线。Schumacher 宣称 "我们进入了曲面时代"。

技术基础：CATIA / Maya / Rhinoceros + Grasshopper 参数化工作流。**计算几何学**（differential geometry, NURBS 曲面）成为建筑基础课程。中国的广州 / 北京 Galaxy Soho 是该运动主要实验场。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt

```
[pre-iconographic]
  two organic pebble-shaped volumes clad in folded granite and glass panels,
  no straight lines, NURBS curvature continuous throughout,
  reflecting pool surrounding base, Guangzhou skyline in background,
  blue hour (early dusk) with interior warm LED light glowing through glass facets.
[iconographic]
  Parametricist architecture, 2010 Guangzhou, Zaha Hadid Architects
  Iconclass: [48C722](https://iconclass.org/48C722)
[iconological]
  algorithmic fluid form replacing classical orthogonal geometry;
  the machine-aided turn of early 21st century architecture.
[lineage]
  AAT: [Parametric (300264929)](http://vocab.getty.edu/aat/300264929)
  Patrik Schumacher, "Parametricism – A New Global Style" (2008 Venice Biennale)
  Greg Lynn, *Animate Form* (1999) — theoretical precedent
  ULAN: [Zaha Hadid (500108087)](http://vocab.getty.edu/ulan/500108087)
--ar 16:9
```

### Video prompt (compatible: runway gen-3, kling)

```
[pre-iconographic]
  slow orbital drone shot around the twin pebbles, 12 seconds, blue hour light.
  camera motion: steadily arcing orbit, elevation 30°, subject always centered.
  lens: 35mm equiv, f/4, slight depth of field.
[iconographic]
  Parametricist architecture showcase.
[iconological]
  the continuous fluid surface revealed through continuous motion — form and camera method aligned.
[lineage]
  director signature: Bas Princen / Iwan Baan 静态建筑摄影 + contemporary time-based render
duration: 12s · transition: dissolve to night interior
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconographic — 特定风格的标志作品
- **AAT**: [300264929](http://vocab.getty.edu/aat/300264929) Parametric architecture
- **Iconclass**: [48C722](https://iconclass.org/48C722)
- **ULAN**: [500108087](http://vocab.getty.edu/ulan/500108087) Zaha Hadid
- **Wikidata**: [Q1128094](https://www.wikidata.org/wiki/Q1128094)
- **跨传统**: Gaudí 有机曲线 → Greg Lynn animate form 1999 → Schumacher 参数主义宣言 2008 → Hadid 广州 2010
- **参考书架**: [[_refs/_domains/architecture]] — 补充 Schumacher《Autopoiesis of Architecture》(2011, 2012)
<!-- llm:section-end academic-lineage -->
