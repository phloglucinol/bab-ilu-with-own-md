---
id: brutalism-unite-dhabitation
type: aesthetic
title: Le Corbusier《马赛公寓》· 原始混凝土的诚实性
aliases: [Unité d'Habitation, Brutalism, Béton Brut, 1952]
aat_id: "300021011"
wikidata: "Q203375"
iconclass: "48C721"
warburg_panel: null
panofsky_layer: iconological
domain: architecture
ulan_id: "500009181"
riba_id: null
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.95
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[geometric-silence]]}
---

## Core observation

Le Corbusier 1947-52 的马赛公寓 *Unité d'Habitation* 是**野兽主义**（Brutalism，源自"béton brut"原始混凝土）的奠基作品。337 户住宅 + 商店街 + 屋顶幼儿园与泳池——自给自足的**垂直村庄**。

外表**刻意保留木模板痕迹**的裸露混凝土。这是 Corbusier 激进命题：材料**不掩饰** = 道德诚实。

Brutalism 后续演化：英国 Smithsons 的 Park Hill 公寓、Denys Lasdun 的 Royal National Theatre、波士顿 City Hall、印度 Chandigarh。至 1980s 反 PoMo 浪潮下被丑化，2010s 起被重新视为 Pathosformel [[geometric-silence]] 建筑代表。

Unité 第一次完整实现 Corbusier "5 points of architecture"（pilotis / roof garden / free plan / horizontal window / free facade）—— 1926 年宣言的终极兑现。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt (compatible: midjourney v6+, flux)

```
[pre-iconographic]
  exposed raw concrete 18 stories high, horizontal loggias every 3 floors,
  saturated primary-color ventilation panels (blue / red / yellow / green, Corbusier's Modulor-derived palette),
  pilotis (massive tapered concrete columns) lifting entire building off ground, bright Marseille sunlight
  cast deep shadows between loggia fins.
  Wooden formwork texture visible on concrete (not smoothed).
[iconographic]
  Brutalist architecture, 1952 Marseille, Corbusier's Unité d'Habitation
  Iconclass: [48C721](https://iconclass.org/48C721) architecture
[iconological]
  Material honesty as moral stance. Massive form softened by primary-color balconies
  (Corbusier's refusal of monochrome monumentality).
[lineage]
  AAT: [Brutalist (300132842)](http://vocab.getty.edu/aat/300132842)
  Le Corbusier, *Vers une architecture* (1923) 五原则
  Reyner Banham, *The New Brutalism* (1966)
  ULAN: [Le Corbusier (500009181)](http://vocab.getty.edu/ulan/500009181)
--ar 3:4 --style raw
```

### UI / video 省略
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconological — 材料道德哲学的建筑化
- **AAT**: [300132842](http://vocab.getty.edu/aat/300132842) Brutalist · [300021011](http://vocab.getty.edu/aat/300021011) International Style
- **Iconclass**: [48C721](https://iconclass.org/48C721) architecture
- **ULAN**: [500009181](http://vocab.getty.edu/ulan/500009181) Le Corbusier
- **Wikidata**: [Q203375](https://www.wikidata.org/wiki/Q203375)
- **跨传统**: Corbusier 5 points (1926) → Unité (1952) → Smithsons → Denys Lasdun → Tadao Ando 的反响
- **参考书架**: [[_refs/_domains/architecture]]
<!-- llm:section-end academic-lineage -->
