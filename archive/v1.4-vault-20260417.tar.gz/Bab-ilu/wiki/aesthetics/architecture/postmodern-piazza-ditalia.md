---
id: postmodern-piazza-ditalia
type: aesthetic
title: Moore《意大利广场》· 后现代的符号戏谑
aliases: [Piazza d'Italia New Orleans, 1978, Charles Moore]
aat_id: "300021488"
wikidata: "Q7193989"
iconclass: "48C722"
warburg_panel: null
panofsky_layer: iconological
domain: architecture
ulan_id: "500116478"
prompts:
  ui:       {generated: 2026-04-16, last_tested: null, test_score: null}
  image:    {generated: 2026-04-16, last_tested: 2026-04-17, test_score: 1.0, compatible_models: [midjourney, flux]}
  video:    {generated: 2026-04-16, last_tested: null, test_score: null, compatible_models: [runway]}
  ux_flow: null
  painting: null
  motion: null
language: zh
created: 2026-04-16
updated: 2026-04-16
freshness_class: evergreen
confidence: 0.9
last_validated: 2026-04-16
schema_version: "1.4.0"
relations:
  - {type: contradicts, target: [[brutalism-unite-dhabitation]]}
---

## Core observation

Charles Moore 1978 新奥尔良 *Piazza d'Italia* 是**后现代建筑**的视觉宣言。Venturi *Complexity and Contradiction* (1966) 理论的终极实现。

设计命题：**拼贴古典符号来庆祝意大利移民身份**。爱奥尼柱 + 霓虹灯 + 靴形意大利半岛平面图 + 暴力色彩（红/黄/蓝）+ 不对称层叠——一切现代主义禁忌全部犯。

这是 Brutalism [[brutalism-unite-dhabitation]] 的**反方**样本。同样关心"真诚性"（authenticity），但结论相反：
- Brutalism：材料必须诚实 → 素混凝土
- Postmodern：意义必须诚实 → 符号拼贴，拒绝"纯几何"的虚假中立

Jencks《后现代建筑的语言》(1977) 把 Piazza d'Italia 列为后现代古典主义（Post-Modern Classicism）代表。1980s 后现代被 Frank Gehry 扭曲金属主义取代，Piazza d'Italia 衰败至 2004 年重修。

**时代意义**：Pathosformel 的反向——不组织"几何沉默"，组织"语义狂欢"。

<!-- llm:section-start prompts -->
## Prompts

### Image prompt

```
[pre-iconographic]
  circular fountain plaza surrounded by fragmented classical colonnades —
  ionic and corinthian columns rendered in stainless steel and neon,
  saturated primary colors (tomato red, cadmium yellow, cobalt blue),
  boot-shaped Italian peninsula floor pattern in terrazzo,
  neon lights outlining entablatures at night. golden hour or dusk lighting.
[iconographic]
  Postmodern architecture, 1978 New Orleans
  Iconclass: [48C722](https://iconclass.org/48C722) public architecture (piazza)
[iconological]
  symbol collage as anti-modernist statement; celebration of immigrant
  identity over "neutral" international style.
[lineage]
  Venturi, *Complexity and Contradiction* (1966) — theory precedent
  Jencks, *The Language of Post-Modern Architecture* (1977) — canonical classification
  Moore's *Body, Memory, and Architecture* (1977)
  ULAN: [Charles Moore (500116478)](http://vocab.getty.edu/ulan/500116478)
--ar 16:9
```
<!-- llm:section-end prompts -->

<!-- llm:section-start academic-lineage -->
## 学术溯源

- **Panofsky 层**: iconological — 符号即意义，后现代对现代主义"纯形式"的挑战
- **AAT**: [300021488](http://vocab.getty.edu/aat/300021488) Postmodernist
- **Iconclass**: [48C722](https://iconclass.org/48C722) piazza
- **ULAN**: [500116478](http://vocab.getty.edu/ulan/500116478) Charles Moore
- **Wikidata**: [Q7193989](https://www.wikidata.org/wiki/Q7193989)
- **跨传统**: 反对 International Style · 继承自 Mannerism / Baroque 的戏谑传统
- **参考书架**: [[_refs/_domains/architecture]] — Venturi / Jencks
<!-- llm:section-end academic-lineage -->
