# Glossary

> Bilingual term anchors governing vault-wide term/translation consistency.
> Managed by `/glossary`. Written to by `/distill`.
> Follows Getty AAT multilingual convention: equivalent terms share a canonical ID.

## zh ↔ en

| 中文 | English | Note |
|------|---------|------|

