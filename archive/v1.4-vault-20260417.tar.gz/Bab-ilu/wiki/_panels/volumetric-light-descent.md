---
id: volumetric-light-descent
type: panel
title: "Volumetric Light Descent · 体积光下降"
curator: llm
panofsky_anchor: iconological
members:
  - [[villeneuve-fraser-dune-shaft]]
cross_era: true
cross_medium: true
generator_ready: false
incomplete: true
created: 2026-04-16
schema_version: "1.4.0"
wikidata: "Q7153691"
aat_id: "300056036"
---

## Pathosformel statement

**一束可见的光从高处斜射而下,穿过烟尘、雨、粉末或薄雾,在黑暗空间中物质化为可感知的体积**,照亮局部的人或物,其余陷入黑。这是自巴洛克以来最稳定的视觉程式之一:不是照明,是**神圣 / 命运 / 审判的物化**。光在此不是光学现象,是叙事本身。

## Nachleben commentary

这一 Pathosformel 的血统链尤其清晰:

- **1600–1610**:Caravaggio 的 *tenebroso* 画法——《圣马太蒙召》《圣彼得被钉十字架》——首次把"从画面外斜射的硬光 + 大面积黑"制度化为叙事工具
- **1632**:Rembrandt《解剖课》延续 Caravaggio 的光学语汇,加入更多粉尘散射
- **1650–1670**:Vermeer 的室内光——更柔和,更日常,但结构同源
- **1760**:Joseph Wright of Derby《气泵里的鸟实验》——启蒙时代把神学光变成科学光,视觉结构不变
- **1960–1970**:Gordon Willis(《教父》)、Vittorio Storaro(《现代启示录》)把这一程式引入彩色电影
- **2010s**:Roger Deakins(《1917》《007 幽灵党》)、Hoyte van Hoytema(《敦刻尔克》《信条》)、**Greig Fraser**(《沙丘》《罗刹国》《蝙蝠侠》)三位 DP 在数字摄影时代各自以不同方式重新物质化该程式
- **2021–2024**:Villeneuve × Fraser 合作的《沙丘》两部曲,是本面板当前成员的来源——Fraser 的手法强调 ARRI Alexa 的宽容度 + 实拍烟雾 / 香料粉末 + 大尺度光源(LED 矩阵 / 实体火炬),让光束的物质性远超 CGI 体积光的惯常呈现

**重要区分**:与 [[blade-runner-2049-orange-sublime]]([[sublime-solitude]] 面板)的区别——那张是 **Deakins × Villeneuve** 的橙色水平大气,关注"人 vs 空间"的尺度;本面板是 **Fraser × Villeneuve**(以及 Caravaggio/Rembrandt 等先驱)的**垂直光柱 + 暗场**,关注"光作为独立角色"。两位 DP 都曾与 Villeneuve 合作,但视觉血统不同源。

## Visual evidence

- [[villeneuve-fraser-dune-shaft]] — 沙丘 Dune(Villeneuve,2021/2024) · DP Greig Fraser · 黑场体积光 + 布团 / 人群局部
- _[未来扩展:caravaggio-calling-st-matthew · rembrandt-anatomy-lesson · storaro-apocalypse-now · fraser-batman-rain-light]_

## Scholarly cross-references

- Getty AAT:Chiaroscuro (aat:300056144) · Tenebrism (aat:300056145) · Cinematography (aat:300139140)
- Wikidata:Chiaroscuro Q46851 · Tenebrism Q373394 · Greig Fraser Q5604108
- 学术参考:Michael Fried《Caravaggio's Inspirations》; Patti Bellantoni《If It's Purple, Someone's Gonna Die》电影色彩理论
