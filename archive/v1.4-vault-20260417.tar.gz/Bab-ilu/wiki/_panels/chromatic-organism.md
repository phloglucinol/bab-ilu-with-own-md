---
id: chromatic-organism
type: panel
title: "Chromatic Organism · 色彩生物"
curator: llm
panofsky_anchor: iconological
members:
  - [[betta-chromatic-organism]]
cross_era: true
cross_medium: true
generator_ready: false
incomplete: true
created: 2026-04-16
schema_version: "1.4.0"
wikidata: "Q12005"
aat_id: "300127121"
---

## Pathosformel statement

**将活体生物作为色彩结构的独立载体来呈现**。画面不讲生态环境,不讲叙事,不讲尺度——只把某一生物的颜色形态(鱼鳍、花瓣、羽毛、皮毛、鳞甲)作为**纯粹的色彩绘画**来呈现。生物在此不再是"被描绘对象",而是**自身成为抽象画**。

这条母题既不同于古典科学插图(关心解剖精确),也不同于自然风光摄影(关心栖息地叙事)——它关心的是"**生命本身作为颜色**"这一哲学命题。

## Nachleben commentary

- **1630-1650**:荷兰"tronie"画法与花卉静物画——Rachel Ruysch、Ambrosius Bosschaert——开始把自然物从场景中抽离,作为颜色与形式的独立研究
- **1770-1820**:John James Audubon《美洲鸟类》系列——科学插图但已带明显的色彩主体化倾向
- **1870-1900**:Maria Sibylla Merian 的昆虫绘画进一步细分
- **1920-1950**:Karl Blossfeldt 摄影集《Urformen der Kunst》把植物以显微近摄变成抽象形式
- **1930-1970**:Imogen Cunningham 的花卉近摄摄影、Edward Weston 的贝壳与辣椒研究把这一程式带入摄影史
- **2000-今**:高分辨率生物微距摄影、深海生物摄影、David Doubilet 水下摄影——数字传感器让"生物作为色彩"的程式能达到前所未有的细节与饱和度

## Visual evidence

- [[betta-chromatic-organism]] — 泰国斗鱼鱼鳍微距 × 红/青互补饱和
- _[未来扩展:blossfeldt-plant-forms · cunningham-calla-lily · doubilet-reef]_

## Scholarly cross-references

- Getty AAT:Nature photography (aat:300127121) · Close-up photography (aat:300127120) · Macro photography (aat:300127119)
- Wikidata:色彩摄影 Q12005
- 相关学术方向:Philip Ball《Bright Earth: Art and the Invention of Color》; Giorgio Agamben《The Open: Man and Animal》对"作为颜色的动物"的哲学讨论
