---
id: tactical-feminine
type: panel
title: "Tactical Feminine · 武装女性"
curator: llm
panofsky_anchor: iconological
members:
  - [[falslander-infantry]]
  - [[tactical-anime-combat]]
cross_era: false
cross_medium: true
generator_ready: false
created: 2026-04-16
schema_version: "1.4.0"
wikidata: "Q467715"
aat_id: "300025943"
---

## Pathosformel statement

**女性身体 + 工业武器 + 冷硬材质**的复合形象——以二次元视觉语言将军事美学性别化/去性别化的当代情感程式。画面强调:黑色/铁灰主调、皮革与金属的反光、大尺度武器相对小巧身形、军官帽/战术装具/呼吸面罩等装备化细节、人物姿态呈"即将战斗或刚战斗完"的临界态。与经典欧陆军装画(Velázquez、Ingres)不同,这里的武装女性不承担"代表国家"的象征职能,而是承担**个人战斗身份**的表达。

## Nachleben commentary

这一 Pathosformel 是 21 世纪头二十年的产物,但其血统可追溯:
- 1960-70 年代:法国新浪潮《狂野的少女》系列 + 意大利 giallo 电影中的女杀手形象
- 1990 年代:《攻壳机动队》草薙素子定义了"女性 + 军事义肢 + 哲学凝视"的二次元母体
- 2000 年代:Type-Moon 系 Saber / Fate 系列扩展"女性 × 剑 × 严肃装束"的视觉语法
- 2010 年代:《少女前线》《明日方舟》《碧蓝档案》等中日手游产业把这一语法工业化、模块化
- 2020 年代:Pixiv / ArtStation 上如 Falslander、Ask(askzy)等签名画师把概念设定稿作为独立作品

与 [[wandering-blade]] 面板的差别:wandering-blade 是**单体 + 冷兵器 + 传统**;tactical-feminine 是**单体 + 工业/科幻武装 + 当代**。

## Visual evidence

- [[falslander-infantry]] — Falslander 签名 · "INFANTRY"军官白发 × 巨剑
- [[tactical-anime-combat]] — 战术面罩 × 红刃 × 特写
- _[未来扩展:ghost-in-the-shell-kusanagi · girls-frontline-char-art · arknights-operator]_

## Scholarly cross-references

- Getty AAT:Character Design (无直接条目,近似 aat:300263552 conceptual art) · Military uniforms (aat:300209277)
- Wikidata:美少女 Q11488430 · 军事美学 Q6137856
- 相关学术方向:Visual Studies / Game Studies 对"military chic"与"weaponized femininity"的批评传统(Anna Anthropy、Soraya Murray 等学者)
