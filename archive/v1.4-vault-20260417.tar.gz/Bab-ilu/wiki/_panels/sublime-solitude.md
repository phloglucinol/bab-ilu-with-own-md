---
id: sublime-solitude
type: panel
title: "Sublime Solitude: 孤身立于浩渺中"
curator: llm
panofsky_anchor: iconological
members:
  - [[blade-runner-2049-orange-sublime]]
cross_era: true
cross_medium: true
generator_ready: false
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
schema_version: "1.4.0"
wikidata: "Q210481"
aat_id: "300055836"
relations:
  - {type: frames, target: [[blade-runner-2049-orange-sublime]]}
---

## Pathosformel statement

孤身人形以背影或轮廓姿态立于吞没性的浩渺(山雾、沙漠、废墟、星空、海)之前——这一视觉公式把有限的主体与不可及的自然并置,让观看者在同一张画面里同时体验**渺小感**与**扩张感**。这是德语美学传统中的崇高(*das Erhabene*),康德在《判断力批判》(1790) 中以数学崇高与力学崇高加以分析;视觉上由 Caspar David Friedrich 在 19 世纪初确立为可识别的公式,并自此持续作为 Nachleben 在不同媒介与时代的作品中重现。

公式不是"画一个人站在风景里"——那是肖像或风景画。公式的必要条件:
1. **人形占画面极小比例**(通常 < 5%)
2. **背影或轮廓化**,人物不与观看者对视,观看者借由人物的视角去看风景
3. **自然(或废墟)呈现为吞没性的、无限延展的**,不是被人类尺度框定的风景
4. **大气感压过细节感**,距离通过雾、尘、光的物质化而感知,非几何透视

## Visual evidence

### 核心成员(v0 阶段仅 1 条,待扩展)

- [[blade-runner-2049-orange-sublime]] — 2017, Villeneuve + Deakins, 后末日 Las Vegas 橙尘废墟

### 待扩展成员(v1 目标:5+)

以下已识别为本 Pathosformel 的确定实例,但尚未作为独立 Aesthetic MD 纳入 vault。用户可以通过 `/ingest` 相应图像逐一补全:

- Caspar David Friedrich, *Wanderer above the Sea of Fog* (1818) — 公式的确立
- Caspar David Friedrich, *Monk by the Sea* (1808–1810) — 海岸变体,人物更小
- John Ford, *The Searchers* (1956) — 西部神话变体,Monument Valley 地貌
- Andrei Tarkovsky, *Stalker* (1979) — 东欧形而上学,Zone 废墟
- Michelangelo Antonioni, *L'Avventura* (1960) — 现代主义疏离,空岛
- Stanley Kubrick, *2001: A Space Odyssey* (1968) — 宇宙变体,星际尺度
- Denis Villeneuve, *Dune* (2021) — 沙漠变体,阿拉基斯
- Werner Herzog, *Aguirre, der Zorn Gottes* (1972) — 丛林变体

## Nachleben commentary

这个 Pathosformel 跨越 200 年、至少六种媒介(绘画→照片→黑白电影→彩色电影→数字电影→生成视频),每次移植都在**材料层面**被重新发明,而**结构层面**保持稳定。这是 Warburg 所说的"Nachleben der Antike(古代的后世)"——形式的存活不依赖于意识传承,而依赖于公式本身的深层可再生性。

值得注意的几次**材料层面的重发明**:
- Friedrich 用油画颜料 + 精细空气透视达成"吞没感"
- Ford 用 Technicolor + Monument Valley 天然地貌 + 远景长镜头达成
- Tarkovsky 用柯达 5247 胶片 + 长镜头 + 慢速步行节奏 + 形而上学诗性对白达成
- Deakins 用数字大气粒子模拟 + ACES 广色域 + IMAX 后期曲线 + 单色橙饱和压过细节达成
- 当代 AI 生成模型(Sora/Runway)正在尝试用扩散过程 + 3D 点云先验 + 时长控制达成

每一次都是对同一任务的重新求解——这正是本 panel 作为**生成器提示词源**的核心价值。

## 跨面板提示词(待 generator_ready: true 后生成)

当本 panel 满足以下条件时,`/prompt --panel sublime-solitude image` 将生成跨面板提示词——综合所有成员的 Pathosformel 而非模仿单一参考:

- [ ] 成员 ≥ 5
- [ ] 至少一位成员的 prompts.image.test_score ≥ 0.7(来自 generative_regression 评估)

**跨面板提示词的价值**:当用户想"在这个传统中创作,而不是复制 Deakins"时,panel 提示词取出所有成员的共通 Pathosformel,产出的生成物**沿着 200 年的 Nachleben 谱系发生**,而不是单一作品的二手模仿。这是 Warburg 机制的创作化操作——Bab-ilu 最核心的产品价值之一。

## 学术交叉引用

- Warburg Institute 数字档案:Mnemosyne Atlas 面板 C、D 序列对"人物-自然"构图的整理
- Kant, *Kritik der Urteilskraft* (1790) §23–29 论崇高分析
- Edmund Burke, *A Philosophical Enquiry into the Origin of our Ideas of the Sublime and Beautiful* (1757) 前浪漫主义崇高论
- Robert Rosenblum, *Modern Painting and the Northern Romantic Tradition* (1975) 论 Friedrich 到 Rothko 的连续性
- Getty AAT 相关父概念:
  - Romanticism (aat:300021263)
  - Landscape painting (aat:300117001)
  - 本 panel 的"崇高"概念本身在 AAT 中无直接 ID,属于 panel-level 概念,不强制单一 ID 映射

## 使用此 panel 的 Aesthetic

- [[blade-runner-2049-orange-sublime]]

## 版本与演进

本 panel 在 v1 seed 阶段作为**核心示范 panel** 手工创作 + LLM 增强。随着 vault 中更多 Aesthetic 被 `/taste` 识别为本 Pathosformel 的成员,LLM 将自动更新 `members` 列表与 Nachleben 评述。

用户对 panel 的任何手工编辑(重命名 / 合并 / 拆分 / 修改 Pathosformel 陈述)优先于 LLM 判断。编辑记录在该文件的 git diff 中追溯。
