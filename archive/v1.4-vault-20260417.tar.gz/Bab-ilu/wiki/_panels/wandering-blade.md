---
id: wandering-blade
type: panel
title: "Wandering Blade · 孤刃行者"
curator: llm
panofsky_anchor: iconological
members:
  - [[ronin-solitary-blade]]
  - [[kneeling-samurai-petal]]
cross_era: true
cross_medium: true
generator_ready: false
created: 2026-04-16
schema_version: "1.4.0"
wikidata: "Q11253"
aat_id: "300236026"
---

## Pathosformel statement

**孤身一人持刃立于世界之中的情感程式**。不是战斗画面——是战斗**之前**或**之后**的停顿。人与刃的关系在这一刻不是"使用关系",而是**身份关系**:刃是此人存在的延伸与证据。画面往往给出大面积留白或无主空间,让孤立感作为画面本身的语义结构。

## Nachleben commentary

这一 Pathosformel 的血统从日本安土桃山时代的陈旧狩野派武士画开始,经过 19 世纪浮世绘(葛饰北斋、歌川国芳的武者绘),1950-60 年代黑泽明《用心棒》《椿三十郎》与冈本喜八《大菩萨岭》的浪人(Ronin)电影美学,到 1970 年代小岛刚夕《子连れ狼》的漫画定格,再进入 2000 年代后的电子游戏概念艺术(《只狼》《对马岛之魂》)与 Pixiv 数字插画圈。

在浪漫主义的视觉公式里,"孤身立于浩渺"的主体是自然([[sublime-solitude]] 面板);在武者修行公式里,主体换成**刃**——人物与武器共同构成画面的中心,背景常常消失为纯色或抽象。

## Visual evidence

- [[ronin-solitary-blade]] — Pixiv 数字插画,浪人女性 × 斗笠 × 黑紫色和服双刀
- [[kneeling-samurai-petal]] — 樱花雪落 × 跪立武士 × 太刀静置
- _[未来扩展:hokusai-musha-e · kurosawa-yojimbo-still · kojima-lone-wolf-cub · sekiro-concept-art]_

## Scholarly cross-references

- Getty AAT:Ukiyo-e (aat:300021489) · Japanese (aat:300018519)
- Wikidata:武士 Q192472 · 浪人 Q207408
- 与 [[sublime-solitude]] 面板的关系:同为"孤独人物"Pathosformel,但方向不同——sublime 面向自然,wandering-blade 面向自身(刃即自我)
