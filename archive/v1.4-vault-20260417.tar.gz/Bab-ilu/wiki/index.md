---
id: wiki-index
type: concept
role: foundation
title: Bab-ilu Wiki Index
description: Human-readable content catalog. LLM reads this first when answering queries. Kept in sync by every write skill; full rebuild via `/check --rebuild-index`.
llm_owned: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Wiki Index

> 本目录由 LLM 维护。每次 `/ingest` / `/taste` / `/distill` / `/compile` 成功写入后增量更新。人类阅读友好。对应机器格式：`_index/entry-index.yaml` + `_index/edges.jsonl`。

v1.4 规模：**35 aesthetic 卡** + **6 Warburg 面板** + **8 person 条目** + **22 权威参考（3 spine + 10 institutions + 9 domains）**，schema v1.4.0。

---

## Aesthetics

按 schema §4 domain 枚举分组。每条一行 wikilink + hook 句。

### Cinema · 影视（4）

- [[blade-runner-2049-orange-sublime]] — Deakins × Villeneuve 橙色崇高，[[sublime-solitude]] 面板当代节点
- [[villeneuve-fraser-dune-shaft]] — Greig Fraser 沙丘体积光，[[volumetric-light-descent]] 当代节点
- [[tarkovsky-stalker-long-take]] — 潜行者 Zone 长镜头作为 Pathosformel
- [[caspar-david-friedrich-wanderer]] — 《雾海上的漫游者》1818，sublime-solitude 源头

### Graphic · 平面（2）

- [[bauhaus-typography]] — Bauhaus 1919–1933 字体与印刷传统
- [[swiss-international-style]] — 瑞士国际主义排版风格

### UI（5 · v1.4 +3）

- [[dieter-rams-principles]] — Rams 十原则及其 UI 后世
- [[jony-ive-apple-hig]] — Jony Ive 时期 Apple 设计语言
- [[material-expressive-2025]] — **v1.4** Material 3 表达性几何，含 `motion` 模态
- [[apple-hig-visionos-depth]] — **v1.4** visionOS 空间深度 + Glass 材质，含 `motion` 模态
- [[fluent-2-acrylic-mica]] — **v1.4** Microsoft Fluent 2 Acrylic/Mica 材质系统

### UX · 用户体验（5 · **v1.4 全新域**）

- [[nng-ten-heuristics]] — Nielsen 十大可用性启发式，UX 评价骨架，含 `ux_flow` 模态
- [[norman-gulfs-execution-evaluation]] — 执行鸿沟与评估鸿沟的认知骨架
- [[iso-9241-210-hcd-cycle]] — ISO 9241-210 以人为本设计循环
- [[cooper-persona-method]] — Cooper persona 方法 · 目标导向设计
- [[krug-dont-make-me-think]] — Krug 显然性原则（挂靠 [[geometric-silence]]）

### Painting · 绘画（5 · **v1.4 全新域**）

- [[vermeer-milkmaid-interior-light]] — Vermeer 1658 北欧内光凝固，Rijks SK-A-2344，Iconclass 41C32，含 `painting` 模态
- [[turner-light-atmosphere]] — Turner 1842《暴风雪中的汽船》光作为气氛本体，Tate N00530
- [[cezanne-mont-sainte-victoire-structure]] — Cézanne 圣维克多山系列，结构作为风景
- [[rothko-color-field-iconoclasm]] — Rothko 色域绘画 · 图像学反叛（有意 `iconclass: null`）
- [[friedrich-monk-by-the-sea]] — Friedrich 1810 海边的僧侣 · sublime-solitude 源头

### Photo · 摄影（1）

- [[betta-chromatic-organism]] — 泰国斗鱼红蓝互补饱和，[[chromatic-organism]] 节点

### Architecture · 建筑（3 · v1.4 +3）

- [[brutalism-unite-dhabitation]] — **v1.4** Le Corbusier 马赛公寓 · 野兽主义源头
- [[postmodern-piazza-ditalia]] — **v1.4** Moore 1978 意大利广场 · 后现代戏谑
- [[parametric-guangzhou-opera]] — **v1.4** Hadid 广州大剧院 · 参数主义流动

### Illustration · 插画 / 原画（5）

- [[ronin-solitary-blade]] — 浪人斗笠双刀
- [[kneeling-samurai-petal]] — 樱落跪武士 · 物哀 × 太刀
- [[falslander-infantry]] — Falslander 步兵军官剑姿
- [[tactical-anime-combat]] — 战术面罩红刃近战半身
- [[ribbon-verticality]] — 绑带纵构图（无面板归属）

### Game · 游戏艺术（5 · v1.4 +3）

- [[fromsoft-art-direction]] — FromSoftware 美术指导语言
- [[journey-minimal-ui]] — Journey 极简游戏界面哲学
- [[ico-negative-space-companionship]] — **v1.4** ICO 负空间陪伴美学（MoMA 2012 藏）
- [[breath-of-the-wild-wind-grass]] — **v1.4** 旷野之息风格化自然
- [[shadow-of-colossus-scale-sublime]] — **v1.4** 旺达与巨像 · 尺度崇高

---

## Warburg Panels · 图像学面板

跨时代、跨媒介的视觉 Pathosformel。

- [[sublime-solitude]] — 孤身立于浩渺中 · Friedrich 1810-1818 → Villeneuve 2017 → SotC 2005 → ICO 2001（members 增至 4+）
- [[volumetric-light-descent]] — 体积光下降 · Vermeer 1658 → Caravaggio → Turner 1842 → Fraser 2024
- [[geometric-silence]] — 功能主义几何沉默 · Cézanne → Bauhaus → Swiss Intl → Material → Krug（5 members，最接近 `generator_ready`）
- [[wandering-blade]] — 孤刃行者 · 北斋武者绘 1820 → Pixiv 2020s（2 members）
- [[tactical-feminine]] — 武装女性 · 攻壳 1989 → 明日方舟 2019（2 members）
- [[chromatic-organism]] — 色彩生物 · 荷兰花卉画 → Doubilet 水下微距 → BotW（+Rothko 反转）

Generator-ready 面板（≥5 members + ≥1 tested score ≥0.7）：**0/6**（pending: 跑 Nano Banana/Midjourney 测试解锁 geometric-silence）。

---

## People · 人物（`wiki/people/{domain}/`）

v1.4 从 `wiki/aesthetics/` 迁移到 `wiki/people/{domain}/`，旧路径保留 30 天符号链接以避免引用断裂。

- **Cinema**: [[andrei-tarkovsky]] · [[denis-villeneuve]] · [[roger-deakins]]
- **Photo**: [[henri-cartier-bresson]] · [[andreas-gursky]]
- **Graphic**: [[josef-muller-brockmann-grid]]
- **Architecture**: [[peter-zumthor]] · [[tadao-ando]]

---

## References · 权威参考（`wiki/_refs/`）

### `_spine/` — 理论脊椎（**3 条 canonical**）

- [[aby-warburg]] — Mnemosyne Atlas · Nachleben · Pathosformel 源头
- [[erwin-panofsky]] — 三层图像学（Bab-ilu `panofsky_layer` 字段的直接父文本）
- [[ernst-gombrich]] — Art and Illusion · Warburg 传记 · 向当代创作者翻译

### `_institutions/` — 权威数据库（**10 条 canonical**）

- [[getty-aat]] — 风格/材料/时期受控词表
- [[wikidata]] — 链接开放数据中枢
- [[iconclass]] — 图像主题分类（Warburg-Panofsky 嫡系）
- [[metmuseum]] — 大都会艺术博物馆 API
- [[moma]] — 现代艺术博物馆（含 UI / 游戏藏品）
- [[cooperhewitt]] — 设计博物馆（平面/工业设计权威）
- [[rijksmuseum]] — 荷兰黄金时代绘画（含 Iconclass 自动标注）
- [[bfi]] — 英国电影协会电影档案
- [[warburg-photographic-collection]] — Warburg Institute 图像档案
- [[nng]] — Nielsen Norman Group UX 研究库

### `_domains/` — 9 域经典文献（**9 文件 · 每文件 5 部经典**）

- [[_refs/_domains/cinema]] · [[_refs/_domains/graphic]] · [[_refs/_domains/ui]] · [[_refs/_domains/ux]] · [[_refs/_domains/painting]] · [[_refs/_domains/photo]] · [[_refs/_domains/architecture]] · [[_refs/_domains/illustration]] · [[_refs/_domains/game]]

---

## Prompts · 独立提示词条目（`_prompts/`）

_(empty — 当用户对某 Aesthetic 的自动生成 prompt 测试 ≥0.7 满意时，可 `/prompt --promote <slug>` 升为 `type: prompt` 独立条目。)_

---

## My · 用户命名空间（`wiki/my/`）

LLM 只读。用户的观影笔记、决策日志、mood board、未成熟想法写在这里。参见 [[my/README]]。

---

## System Primitives

- `schema.md` · 本 vault 的契约（agent 读，人类编辑）· **v1.4.0**
- `CLAUDE.md` · agent session 开场检查单
- `wiki/_glossary.md` · 双语术语对照
- `wiki/log.md` · 写入动作时间轴（append-only，人类可读）
- `wiki/_index/entry-index.yaml` · 机器可读全量索引
- `wiki/_index/edges.jsonl` · 关系图边（LLM 按需重建）
- `wiki/_log/usage.jsonl` · 机器可读完整动作日志
- `docs/MIGRATIONS/1.3-to-1.4.md` · v1.4 迁移说明

---

## Empty-state Guide

```
1. 把一张参考图粘到 Claude Code 聊天窗口
2. 说: /taste
3. 等 3 分钟，刷新 Obsidian Graph View 看新节点接入
```

详细欢迎路径见 `README.md`。

---

## Maintenance

- 每个写入 skill（`/ingest` / `/taste` / `/distill` / `/compile`）在写入成功时负责追加/修改本文件对应段落
- `/check` 扫描 `wiki/` 与本索引的 drift：有文件不在索引 / 索引有死链 → 上报
- `/check --rebuild-index` 触发全扫描重建
