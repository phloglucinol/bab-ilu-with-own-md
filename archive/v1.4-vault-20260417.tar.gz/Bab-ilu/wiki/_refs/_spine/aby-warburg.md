---
id: spine-aby-warburg
type: source
role: foundation
title: Aby Warburg — 理论脊椎
format: archive
domain: spine
language: de/en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q151509
ulan_id: "500089766"
aliases: [Aby Warburg, Abraham Moritz Warburg]
---

# Aby Warburg (1866–1929)

Hamburg 出身的艺术史家，创立**图像学**（Kulturwissenschaftliche Bibliothek Warburg, 后为 Warburg Institute, London）。Bab-ilu 的 **Nachleben**（图像来世）原则、**Pathosformel**（情感公式）概念、以及 `wiki/_panels/` 的跨时代跨媒介组织方式，全部继承自 Warburg。

## 五部核心文献（`_refs/_spine/` canonical）

### 1. *The Renewal of Pagan Antiquity* (essays 1893–1925; Getty Research Institute English ed. 1999, trans. David Britt)

- Warburg 生前所有英文可读论文的权威合集
- 关键条目："The Influence of Ancient Image Designs on the Style of the Early Renaissance" (1905)；"Italian Art and International Astrology in the Palazzo Schifanoia, Ferrara" (1912)
- Getty 出版社页：https://shop.getty.edu/products/the-renewal-of-pagan-antiquity-contributions-to-the-cultural-history-of-the-european-renaissance-978-0892365371
- **Bab-ilu 用途**：`taste-lineage` 子代理的基础 prompt；Pathosformel 识别的源文本

### 2. *Bilderatlas Mnemosyne: The Original* (Berlin: HKW / Hatje Cantz, 2020)

- 63 重建面板的高精度复制版，Roberto Ohrt & Axel Heil 导读
- 原版 atlas 1924–1929 未完成
- Warburg Institute 数字化存档：https://warburg.sas.ac.uk/collections/bilderatlas-mnemosyne
- **Bab-ilu 用途**：`wiki/_panels/` 的直接祖先，每个 Bab-ilu panel 都是 Mnemosyne panel 的结构孪生

### 3. "Einleitung" / "Introduction to the *Mnemosyne Atlas*" (1929, 未完成)

- Warburg 理论立场最凝练的陈述
- 英译收录于 *Common Knowledge* 18.1 (2012)；也见 Gombrich 1970 传记附录
- 约 20 页，定义 Nachleben、Pathosformel、emotional polarity、"afterlife of antiquity"
- **Bab-ilu 用途**：`taste-lineage` 的 Nachleben 识别逻辑直接来自本文

### 4. "Italian Art and International Astrology in the Palazzo Schifanoia, Ferrara" (1912)

- Warburg 图像学方法的**奠基讲座**（1912 在罗马第十届国际艺术史大会发表）
- 奠定"把单幅画作为跨时代占星星座回路的节点"方法论
- 见 *Renewal of Pagan Antiquity* 合集第 12 章
- **Bab-ilu 用途**：跨媒介/跨时代证据链的方法论原型

### 5. "Dürer and Italian Antiquity" (1905) / "Pagan-Antique Prophecy in Words and Images in the Age of Luther" (1920)

- 成对的经典论文，展示 Warburg 如何用单一 Pathosformel（死去的恋人 / 愤怒的巫师）追溯五世纪古代到北欧文艺复兴
- **Bab-ilu 用途**：每张 Warburg panel 的"Nachleben commentary"段落结构模仿此二文

---

## 非核心但相关

- Philippe-Alain Michaud, *Aby Warburg and the Image in Motion* (Zone Books, 2004) — 把 Warburg 与早期电影理论联系
- Georges Didi-Huberman, *The Surviving Image: Phantoms of Time and Time of Phantoms* (2017) — 当代法国语境下对 Nachleben 的重新阐释
- Carlo Ginzburg, "From Aby Warburg to E. H. Gombrich: A Problem of Method" (1966) — 方法论谱系

## 引用规则

任何 `wiki/_panels/` 或 `wiki/aesthetics/` 条目引用 Warburg 时：
- 首选引 Getty 合集（Renewal）的具体论文名 + 年份
- 二级可引 Mnemosyne Atlas 具体 panel 编号（如 *Mnemosyne* Panel 39, Warburg Institute catalog）
- 不可引"Warburg 说过"这种无页码的浮泛引用

## 相关

- [[erwin-panofsky]] — Warburg 的学生、图像学三层法的创立者
- [[ernst-gombrich]] — 第二代 Warburg Institute 主任、Warburg 传记作者
- [[warburg-photographic-collection]] — 学院摄影档案（`_refs/_institutions/`）
