---
id: spine-ernst-gombrich
type: source
role: foundation
title: Ernst Gombrich — 图像学的心理学延续与大众化
format: archive
domain: spine
language: de/en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q76405
ulan_id: "500018923"
aliases: [Ernst H. Gombrich, E. H. Gombrich, Sir Ernst Gombrich]
---

# Ernst Gombrich (1909–2001)

维也纳出生、1936 移居伦敦、1959–1976 任 Warburg Institute 主任。把 Warburg 的图像学和 Panofsky 的图像学法与**感知心理学、艺术生产心理学**打通。对 Bab-ilu 意义：提供从 Warburg 百年传统走向**当代创作者**的翻译桥梁——Gombrich 的文本既严肃又大众，这就是 Bab-ilu 想输出的那种密度。

## 五部核心文献（`_refs/_spine/` canonical）

### 1. *Art and Illusion: A Study in the Psychology of Pictorial Representation* (Phaidon / Pantheon Books, 1960; Mellon Lectures 1956)

- Gombrich 最重要的理论著作
- 提出"schema and correction"模型：艺术家不模仿眼见，而是修正承袭的图式
- Princeton 2000 周年版：https://press.princeton.edu/books/paperback/9780691070001/art-and-illusion
- **Bab-ilu 用途**：解释为何 Pathosformel 跨时代延续——不是风格抄袭，是图式继承与修正

### 2. *The Story of Art* (Phaidon, 1950, 16th ed. 1995)

- 世界上最畅销的艺术史通史（6M+ 册）
- 单人写作的整部西方艺术史，从洞穴画到战后
- 每章约 10 页，陈述密度极高
- **Bab-ilu 用途**：Aesthetic 条目的"如果学者要快速定位此作品在艺术史坐标"时的首选引用

### 3. *Aby Warburg: An Intellectual Biography* (Warburg Institute, 1970, 2nd ed. Phaidon 1986)

- Gombrich 亲自写的 Warburg 传记，也是 Warburg 思想的系统阐释
- 附录含部分未出版的 Warburg 手稿翻译
- **Bab-ilu 用途**：理解 Nachleben 和 Pathosformel 概念的首选二手文献——一手文本（Warburg 自己的德文手稿）对多数读者不可读

### 4. *The Sense of Order: A Study in the Psychology of Decorative Art* (Cornell University Press, 1979)

- 装饰艺术的心理学研究——对 UI / 平面 / 建筑装饰的 Bab-ilu 条目尤其关键
- 提出"visual perception has a built-in expectation of order"——解释了 Bauhaus、Swiss International Style、Material Design 为何"感觉对"
- **Bab-ilu 用途**：`[[geometric-silence]]` 面板的心理学基础引用

### 5. *Symbolic Images: Studies in the Art of the Renaissance II* (Phaidon, 1972)

- Gombrich 的 Panofskian iconographic 论文集
- 示范如何把三层图像学法应用到具体作品
- **Bab-ilu 用途**：`panofsky_layer` 填充时的方法论范本

---

## Gombrich 对 Bab-ilu 的三个具体贡献

1. **"schema and correction"** → 解释 Bab-ilu 为何按 Pathosformel（情感公式图式）而非风格标签组织知识。风格是末端，图式是根。
2. **Warburg 传记** → 把 Warburg 的德文学术语言翻译成当代可读的英文陈述。Bab-ilu 的 `taste-lineage` 子代理提示词在语调上模仿 Gombrich 的密度。
3. **《秩序感》** → 为 Bab-ilu 的 UI / 平面 / 装饰类 aesthetic 条目提供一套**心理学验证的**评价标准，不依赖主观品味。

## 引用规则

- 引 *Art and Illusion* 用具体章节（"Meditations on a Hobby Horse"、"Truth and the Stereotype"、"Pygmalion's Power"）
- 引 *Story of Art* 使用章节编号（最新版有 28 章）
- 不要引用《秩序感》的"Gombrich 说"而不给具体命题——Gombrich 一生有数千段可引用观点，必须精确

## 相关

- [[aby-warburg]] — 思想源头，Gombrich 一生的课题
- [[erwin-panofsky]] — 同代人与方法论对话对象
- [[sense-of-order-applied-to-geometric-silence]] — Bab-ilu 将 Gombrich 秩序心理学应用到 geometric-silence 面板的分析（pending）
