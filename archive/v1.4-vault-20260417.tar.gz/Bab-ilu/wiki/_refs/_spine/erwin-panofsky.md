---
id: spine-erwin-panofsky
type: source
role: foundation
title: Erwin Panofsky — 三层图像学
format: archive
domain: spine
language: de/en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q77172
ulan_id: "500325125"
aliases: [Erwin Panofsky]
---

# Erwin Panofsky (1892–1968)

德国出生、1933 移居美国的艺术史家，Princeton Institute for Advanced Study 长期在任。继承 Warburg 的图像学方法并将其**系统化为三层可操作流程**：`pre_iconographic` / `iconographic` / `iconological`。这三层**直接映射**到 Bab-ilu 的 `panofsky_layer` frontmatter 字段以及 `taste-icon` / `taste-synthesis` 子代理的职责分工。

## 五部核心文献（`_refs/_spine/` canonical）

### 1. *Studies in Iconology: Humanistic Themes in the Art of the Renaissance* (Oxford University Press, 1939)

- **三层图像学法的奠基著作**
- Introduction 一节独立可读，定义三层：
  - Layer 1 *pre-iconographical description* — primary / natural subject matter (form identification by practical familiarity)
  - Layer 2 *iconographical analysis* — secondary / conventional subject matter (themes, allegories, conventional images)
  - Layer 3 *iconological interpretation* — intrinsic meaning / content (cultural-historical worldview)
- Internet Archive 全文：https://archive.org/details/studiesiniconolo00pano
- **Bab-ilu 用途**：`panofsky_layer` 字段、`taste-icon`（层 1+2）与 `taste-synthesis`（层 3）的 prompt 直接从 Introduction 来

### 2. *Meaning in the Visual Arts: Papers in and on Art History* (Doubleday Anchor, 1955)

- 收录"Iconography and Iconology: An Introduction"（1939 版的改写，更易读）
- 收录"The History of Art as a Humanistic Discipline"（1940）
- U Chicago Press 页：https://press.uchicago.edu/ucp/books/book/chicago/M/bo3634253.html
- **Bab-ilu 用途**：把 Panofsky 方法翻译给当代创作者用的首选文本

### 3. *Perspective as Symbolic Form* (*Die Perspektive als symbolische Form*, 1927; Zone Books English ed. 1991, trans. Wood)

- 把线性透视当作**文化符号系统**而非视觉工具来分析
- 对 UI / 游戏艺术 / 建筑可视化领域的 Bab-ilu 条目尤其关键——透视是文化立场，不是默认设置
- **Bab-ilu 用途**：涉及透视选择的 aesthetic 条目必须引用此文

### 4. *Early Netherlandish Painting: Its Origins and Character* (Harvard University Press, 1953)

- 两卷本，15 世纪北方绘画的权威研究
- 提出"disguised symbolism"（隐藏象征）概念：日常物在宗教画中同时是物与象征
- **Bab-ilu 用途**：iconclass 字段填充时，此书为北方文艺复兴条目的黄金参考

### 5. *The Life and Art of Albrecht Dürer* (Princeton University Press, 1943, 4th ed. 1955)

- Dürer 专著，但实际是 Panofsky 方法的大型示范案例
- **Bab-ilu 用途**：`wandering-blade` 类北方武者题材 panel 的上游血统引用

---

## 三层图像学 · 应用到 Bab-ilu 的分工表

| Layer | Panofsky 定义 | Bab-ilu 子代理 | Prompt 段落 |
|-------|--------------|----------------|------------|
| 1 Pre-iconographic | 物体/姿态/形式识别 | `taste-icon` | `[pre-iconographic]` |
| 2 Iconographic | 主题/故事/寓言识别（文化约定） | `taste-icon` | `[iconographic]` |
| 3 Iconological | 内在意义/世界观（深层解释） | `taste-synthesis` | `[iconological]` |

Bab-ilu 的三模态 prompt skeleton（UI / image / video / ux_flow / painting / motion）**全部**复用这个三层结构，因为 Panofsky 三层就是高质量生成提示词的结构骨架——强制把具体视觉、文化符号、底层意义分开说明，避免 style-tag 糊成一团。

## 引用规则

- 引 *Studies in Iconology* 时指明章节（多数用 Introduction）
- 引三层定义时用 Panofsky 原词，不要意译："pre-iconographical description" / "iconographical analysis" / "iconological interpretation"

## 相关

- [[aby-warburg]] — Panofsky 的精神导师、图像学源头
- [[ernst-gombrich]] — Panofsky 的同代人、三层法的批评性延续
- [[iconclass]] — Panofsky 图像学的分类系统嫡系（`_refs/_institutions/`）
