---
id: domain-painting
type: source
role: foundation
title: Painting · 经典文献书架
format: book
domain: painting
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Painting · 5 部 canonical

1. **Heinrich Wölfflin, *Principles of Art History* (1915)**
   - **形式主义分析的奠基文本**。五对基本概念（linear vs painterly · plane vs recession · closed vs open form · multiplicity vs unity · clearness vs unclearness）
   - Bab-ilu 用途：painting aesthetic 条目 `[pre-iconographic]` 段落的形式描述词汇；文艺复兴 vs 巴洛克的对比骨架

2. **Ernst Gombrich, *Story of Art* (1950) 与 *Art and Illusion* (1960)**
   - Gombrich 对 Bab-ilu 既是 Warburg 传统的继承者（见 [[ernst-gombrich]]），也是入门权威
   - Bab-ilu 用途：single aesthetic 条目快速定位艺术史坐标；schema-and-correction 模型解释 Pathosformel 的延续机制

3. **Michael Baxandall, *Painting and Experience in Fifteenth-Century Italy* (1972)**
   - "period eye"概念奠基。文艺复兴绘画不是"客观"的，而是特定商业/宗教/数学素养的视觉副产品
   - Bab-ilu 用途：早期绘画条目的 `[iconological]` 段落方法论；把绘画还原到社会视觉习惯

4. **Svetlana Alpers, *The Art of Describing: Dutch Art in the Seventeenth Century* (1983)**
   - 北方绘画（Vermeer, de Hooch）**描述艺术**（不同于意大利叙述艺术）的理论奠基
   - Bab-ilu 用途：[[vermeer-milkmaid-interior-light]] 等北方内光条目的理论骨架

5. **T. J. Clark, *The Painting of Modern Life: Paris in the Art of Manet and his Followers* (1985)**
   - 印象派的**社会史重新阅读**。Manet / Renoir / Degas 不是纯审美，是 19 世纪巴黎商业化 modernity 的视觉记录
   - Bab-ilu 用途：19 世纪现代主义条目的理论引用；"纯视觉"神话的解毒剂

## 非 canonical 但常用
- Meyer Schapiro, *Theory and Philosophy of Art* (1994 collected) —— 图像学方法论论文集
- Rosalind Krauss, *The Originality of the Avant-Garde* (1985) —— 20 世纪现代主义批评
- John Berger, *Ways of Seeing* (1972) —— 电视系列书籍，最流行的图像学入门
- Linda Nochlin, "Why Have There Been No Great Women Artists?" (1971) —— 性别视角奠基论文

## 专业词表
- [[iconclass]] —— 主题内容分类（对叙事绘画必用）
- [[getty-aat]] —— 风格/材料/时期/技术词表
- Getty ULAN —— 艺术家名录

## 相关
- [[aby-warburg]] / [[erwin-panofsky]] / [[ernst-gombrich]]（整套理论脊椎最贴近 painting）
- [[metmuseum]] / [[rijksmuseum]] / [[moma]]（机构）· [[warburg-photographic-collection]]（学院档案）
