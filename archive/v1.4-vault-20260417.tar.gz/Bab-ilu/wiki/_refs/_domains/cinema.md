---
id: domain-cinema
type: source
role: foundation
title: Cinema · 经典文献书架
format: book
domain: cinema
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Cinema · 5 部 canonical

1. **David Bordwell & Kristin Thompson, *Film Art: An Introduction* (1979, 多版本至 2020)**
   - 形式主义电影分析的**教科书权威**。镜头/剪辑/声音/叙事四大系统
   - Bab-ilu 用途：cinema aesthetic 条目的 `[pre-iconographic]` 段落词汇源

2. **André Bazin, *What Is Cinema?* Vols I–II (Fr. 1958–62; En. 1967/71)**
   - 现实主义电影理论奠基。深焦镜头、长镜头、场面调度的理论化
   - Bab-ilu 用途：长镜头 / 景深 Pathosformel 条目（如 [[tarkovsky-stalker-long-take]]）的理论引用

3. **Sergei Eisenstein, *Film Form* / *The Film Sense* (1949/1942)**
   - 蒙太奇理论原典。视觉冲突、吸引力蒙太奇、音画对位
   - Bab-ilu 用途：剪辑节奏的 [[volumetric-light-descent]] 类电影面板的反向对照（Eisenstein 站在 Bazin 对面）

4. **Gilles Deleuze, *Cinema 1: The Movement-Image* / *Cinema 2: The Time-Image* (1983/1985)**
   - 电影作为思想形式。运动影像 vs 时间影像两种电影本体论
   - Bab-ilu 用途：高阶电影分析条目的 `[iconological]` 段落；Tarkovsky / Antonioni / Resnais 类作品必引

5. **BFI Film Classics / Modern Classics 系列丛书 (150+ 卷)**
   - 每部一本，单作品权威专论，约 80 页
   - 例：Redmond *Blade Runner 2049* (2023) · Wood *Stalker* (2000)
   - Bab-ilu 用途：具体电影 aesthetic 条目的首选引用 —— 比书多作的合集权威，比论文体量实用

## 非 canonical 但常用
- David Bordwell, *On the History of Film Style* (1997) —— 风格史方法论
- Film Quarterly / Sight and Sound 期刊 —— FIAF index 可查
- Margaret Herrick Library (AMPAS) —— 电影史第一手档案

## 相关
- [[bfi]]（机构） · [[erwin-panofsky]]（Panofsky 1947 "Style and Medium in the Motion Pictures" 是电影图像学原点）
