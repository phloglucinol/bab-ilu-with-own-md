---
id: domain-photo
type: source
role: foundation
title: Photography · 经典文献书架
format: book
domain: photo
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Photography · 5 部 canonical

1. **Susan Sontag, *On Photography* (1977)**
   - **摄影哲学的现代奠基**。摄影作为权力 / 焦虑 / 证据的论文集
   - Bab-ilu 用途：photo aesthetic 条目的 `[iconological]` 段；任何涉及摄影伦理的条目

2. **Roland Barthes, *Camera Lucida* (Fr. 1980)**
   - studium / punctum 二元法。摄影本体论从指示（index）而非再现（representation）出发
   - Bab-ilu 用途：单幅摄影作品的深度分析条目（Barthes 自己的 method 是盯住一张图写 3000 字）

3. **John Szarkowski, *The Photographer's Eye* (1966) 与 *Looking at Photographs* (1973)**
   - MoMA 摄影部长 1962–1991。**将摄影博物馆化**的理论家
   - Bab-ilu 用途：photo 形式分析的权威词汇源（thing itself / detail / frame / time / vantage point 五要素）

4. **Beaumont Newhall, *The History of Photography* (1937, 5th ed. 1982)**
   - **摄影通史教科书**。MoMA 1937 同名展览的延伸
   - Bab-ilu 用途：摄影史坐标定位；时期/工艺的权威参考

5. **Geoffrey Batchen, *Burning with Desire: The Conception of Photography* (1997)**
   - 摄影发明的**思想史考古**。不是 Niépce/Daguerre 哪年发明了什么，而是 18 世纪末欧洲思想氛围为何必然产出摄影
   - Bab-ilu 用途：早期摄影 / 摄影本体论条目的学术根基

## 非 canonical 但常用
- Vilém Flusser, *Towards a Philosophy of Photography* (Ger. 1983)
- Allan Sekula, *Photography Against the Grain* (1984) —— 马克思主义摄影理论
- Geoff Dyer, *The Ongoing Moment* (2005) —— 跨摄影师的母题追踪（最接近 Warburg 方法）
- *Aperture* 杂志 archive
- Magnum Photos 摄影师口述档案

## 专业词表
- [[getty-aat]] —— 摄影工艺词表极全（daguerreotype / cyanotype / platinum print 等）

## 相关
- [[moma]] / [[metmuseum]] / [[magnum_id]] 候选 institution · Harry Ransom Center (Magnum 实体档案)
- [[aby-warburg]]（*Ongoing Moment* 是 Warburg 方法的摄影版）
