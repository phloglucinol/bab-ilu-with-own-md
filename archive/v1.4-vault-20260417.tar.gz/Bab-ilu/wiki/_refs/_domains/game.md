---
id: domain-game
type: source
role: foundation
title: Game Art · 经典文献书架
format: book
domain: game
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Game Art · 5 部 canonical

1. **Johan Huizinga, *Homo Ludens: A Study of the Play-Element in Culture* (1938)**
   - 游戏学**前数字奠基**。"magic circle" 概念——游戏作为文化自治空间
   - Bab-ilu 用途：游戏本体论条目；[[journey-minimal-ui]] 等反叙事极简游戏的哲学根基

2. **Katie Salen & Eric Zimmerman, *Rules of Play: Game Design Fundamentals* (2003)**
   - 游戏设计学术**教科书**。规则系统、游戏体验、文化
   - Bab-ilu 用途：游戏设计方法论条目；系统美学条目

3. **Jesper Juul, *Half-Real: Video Games Between Real Rules and Fictional Worlds* (2005)**
   - 规则与虚构的紧张关系。**数字游戏特有性**的理论化
   - Bab-ilu 用途：虚构世界美学条目（FromSoft / Souls 系列专属题材）

4. **Ian Bogost, *Persuasive Games: The Expressive Power of Videogames* (2007) 与 *Unit Operations* (2006)**
   - "procedural rhetoric" 概念。游戏作为**修辞媒介**
   - Bab-ilu 用途：独立游戏 / 叙事实验条目（Papers Please 类）

5. **Jesse Schell, *The Art of Game Design: A Book of Lenses* (2008, 3rd ed. 2019)**
   - 游戏设计**实务圣经**。100+ "lenses" 分析框架
   - Bab-ilu 用途：游戏美学条目的实务分析骨架

## 非 canonical 但常用
- *The Art of [Studio]* 系列（Blizzard / Naughty Dog / FromSoftware / Bethesda / Nintendo）—— **美术指导权威**
- Ian Bogost, *Play Anything* (2016)
- Raph Koster, *A Theory of Fun for Game Design* (2004)
- GDC Vault 讲演档案 —— 当代实务
- Game Studies 期刊（gamestudies.org）—— 学术前沿

## 档案
- MoMA video games collection（2012 起 40+ 游戏作为设计对象入藏）—— 见 [[moma]]
- Strong Museum of Play (Rochester) —— World Video Game Hall of Fame
- Video Game History Foundation 研究库
- MobyGames / IGDB / Giant Bomb —— 见 [[moby_id]] / [[igdb_id]] 字段

## 相关
- [[domain-illustration]]（游戏美术与插画源流相通）· [[fromsoft-art-direction]] / [[journey-minimal-ui]]（现存 Bab-ilu 条目）
