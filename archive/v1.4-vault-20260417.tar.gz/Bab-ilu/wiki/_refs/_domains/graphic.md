---
id: domain-graphic
type: source
role: foundation
title: Graphic Design · 经典文献书架
format: book
domain: graphic
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Graphic Design · 5 部 canonical

1. **Philip B. Meggs & Alston Purvis, *Meggs' History of Graphic Design* (1983, 6th ed. 2016)**
   - 平面设计通史**唯一权威教科书**。从字母发明到当代数字
   - Bab-ilu 用途：graphic aesthetic 条目的历史坐标定位首选

2. **Josef Müller-Brockmann, *Grid Systems in Graphic Design* (1981) + *The Graphic Artist and His Design Problems* (1961)**
   - 瑞士国际主义排版的方法论宣言。网格、模块、比例的系统化
   - Bab-ilu 用途：[[swiss-international-style]] / [[josef-muller-brockmann-grid]] 条目的 primary source；UI grid 条目的上游

3. **Robert Bringhurst, *The Elements of Typographic Style* (1992, 4th ed. 2013)**
   - 字体排印的**当代圣经**。细节密度极高（Tschichold 之后最权威）
   - Bab-ilu 用途：任何涉及字体选择/排版/字距的 graphic 和 UI 条目

4. **Jan Tschichold, *Die neue Typographie* (1928; En. *The New Typography* 1995, trans. McLean)**
   - 现代主义排版的**起源文本**。Bauhaus 圈的实操宣言
   - Bab-ilu 用途：[[bauhaus-typography]] 的 primary source；[[geometric-silence]] 面板的文献证据

5. **Ellen Lupton, *Thinking with Type* (2004, 2nd ed. 2010)**
   - 当代入门圣经。Bringhurst 的大众化补充
   - Bab-ilu 用途：入门级 graphic 条目、UI 文本 system 条目

## 非 canonical 但常用
- Beatrice Warde, "The Crystal Goblet" (1932) essay —— 透明排版立场声明
- Massimo Vignelli, *The Vignelli Canon* (2010) —— NYC subway signage 系列幕后
- Paul Rand 著作集（IBM / ABC logos）

## 相关
- [[cooperhewitt]]（机构）· [[moma]]（机构）· [[ernst-gombrich]]（*Sense of Order* 把秩序感带入装饰研究）
