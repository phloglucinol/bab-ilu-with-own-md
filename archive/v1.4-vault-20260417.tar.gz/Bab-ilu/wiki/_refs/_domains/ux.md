---
id: domain-ux
type: source
role: foundation
title: UX · 经典文献书架
format: book
domain: ux
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# UX · 5 部 canonical

1. **Don Norman, *The Design of Everyday Things* (1988; 修订版 2013)**
   - UX **奠基文本**。affordance、signifiers、gulfs of execution and evaluation、error-tolerant design
   - Bab-ilu 用途：所有 UX 条目的理论根基；[[nng-ten-heuristics]] 的前置文本

2. **Jakob Nielsen, *Usability Engineering* (1993)**
   - 10 启发式的学术出处。quantitative usability testing 方法
   - Bab-ilu 用途：[[nng-ten-heuristics]] 的 primary source；UX eval 方法学

3. **Steve Krug, *Don't Make Me Think* (2000, 3rd ed. 2014)**
   - UX 实务最畅销书。"obvious" 原则、5-second test、guerrilla usability
   - Bab-ilu 用途：入门级 UX 条目、checklist 构造引用

4. **Alan Cooper, *The Inmates Are Running the Asylum* (1999)**
   - persona 方法的起源。激进立场：程序员不该设计消费产品
   - Bab-ilu 用途：persona 方法条目、产品 UX 架构条目

5. **Indi Young, *Mental Models: Aligning Design Strategy with Human Behavior* (2008) 或 Kim Goodwin, *Designing for the Digital Age* (2009)**
   - 研究方法论权威。mental model 访谈、cognitive maps、目标对齐
   - Bab-ilu 用途：UX research 流程条目、survey/interview 方法

## 非 canonical 但常用
- NN/g 文章库（nngroup.com/articles）—— **实务权威**，见 [[nng]]
- ISO 9241-210:2019 —— Human-centred design for interactive systems
- ISO 9241-11:2018 —— Usability definitions
- WCAG 2.2 W3C standard —— 可访问性
- ACM CHI / UIST / CSCW / DIS proceedings —— 学术前沿

## 控制词表与标准
- NN/g 10 Heuristics（事实权威）
- ISO 9241-110:2020（interaction principles）
- ISO 9241-112:2017（information presentation）
- WCAG 2.2 success criteria (1.1.1 … 4.1.3)

## 相关
- [[nng]]（机构 · 事实权威） · [[domain-ui]]（分工：UI 关"视觉对不对"，UX 关"流程对不对"）· [[erwin-panofsky]]（三层图像学可借用到 UX 分析：pre/icono/iconological 映射 what-user-sees / what-user-recognizes / what-worldview-it-embeds）
