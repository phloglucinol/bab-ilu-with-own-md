---
id: domain-architecture
type: source
role: foundation
title: Architecture · 经典文献书架
format: book
domain: architecture
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Architecture · 5 部 canonical

1. **Vitruvius, *De architectura* / *Ten Books on Architecture* (c. 30–15 BCE)**
   - 西方建筑理论的**唯一古典文本**。三原则：firmitas（坚固）/ utilitas（实用）/ venustas（美）
   - Bab-ilu 用途：任何涉及建筑三原则分析的条目

2. **Leon Battista Alberti, *De re aedificatoria* (1485)**
   - 文艺复兴对 Vitruvius 的系统重新阐释。**第一部印刷建筑专著**
   - Bab-ilu 用途：古典主义/帕拉第奥血统条目的理论根基

3. **Le Corbusier, *Vers une architecture* / *Towards a New Architecture* (1923)**
   - 现代主义建筑**宣言**。"A house is a machine for living in"
   - Bab-ilu 用途：[[brutalism-unite-dhabitation]] 类现代条目 primary source

4. **Robert Venturi, *Complexity and Contradiction in Architecture* (1966)**
   - **后现代的转折点**。拒绝 Mies "less is more"，提出 "less is a bore"
   - Bab-ilu 用途：后现代建筑条目的 primary source

5. **Kenneth Frampton, *Modern Architecture: A Critical History* (1980, 5th ed. 2020)** 或 **Rem Koolhaas, *Delirious New York* (1978)**
   - Frampton 是现代建筑史教科书；Koolhaas 是纽约语境下都市建筑的激进重读
   - Bab-ilu 用途：20 世纪建筑史坐标（Frampton）或都市主义条目（Koolhaas）

## 非 canonical 但常用
- Charles Jencks, *The Language of Post-Modern Architecture* (1977) —— 后现代具体化
- Christian Norberg-Schulz, *Genius Loci* (1980) —— 场所精神理论
- Juhani Pallasmaa, *The Eyes of the Skin* (1996) —— 建筑与触觉现象学（Zumthor 传统的根基）
- Peter Zumthor, *Thinking Architecture* (1998) 与 *Atmospheres* (2006) —— Zumthor 自己的实务文本
- Reyner Banham, *Theory and Design in the First Machine Age* (1960)

## 专业词表 / 档案
- CIDOC-CRM（文化遗产本体论）
- Archnet（伊斯兰建筑）—— 见 [[archnet_id]] 候选字段
- RIBA Collections（英国）—— 见 [[riba_id]] 字段
- Avery Index to Architectural Periodicals（Columbia）
- Canadian Centre for Architecture (CCA)

## 相关
- [[getty-aat]]（建筑类型词表密集）· [[moma]]（Architecture & Design 部门）· [[peter-zumthor]] / [[tadao-ando]]（人物）
