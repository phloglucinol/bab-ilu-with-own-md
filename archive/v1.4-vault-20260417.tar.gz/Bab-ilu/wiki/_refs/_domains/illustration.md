---
id: domain-illustration
type: source
role: foundation
title: Illustration · 经典文献书架
format: book
domain: illustration
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Illustration · 5 部 canonical

1. **Walt Reed, *The Illustrator in America 1860–2000* (2001)**
   - 美国插画**通史权威**。Howard Pyle / N. C. Wyeth / Norman Rockwell / Maxfield Parrish 等
   - Bab-ilu 用途：西方商业插画条目的历史坐标

2. **Susan E. Meyer, *A Treasury of the Great Children's Book Illustrators* (1983)**
   - **儿童插画传统权威**。Tenniel / Caldecott / Greenaway / Sendak 等
   - Bab-ilu 用途：绘本插画 / 童书艺术条目

3. **Scott McCloud, *Understanding Comics: The Invisible Art* (1993)**
   - 漫画理论**奠基文本**。"icon"、"closure"、"time frame"、图文关系六类
   - Bab-ilu 用途：漫画 / graphic novel 条目；跨到 UI 条目时的信息设计引用

4. **Frederik L. Schodt, *Manga! Manga! The World of Japanese Comics* (1983) 与 *Dreamland Japan* (1996)**
   - 英语世界最早的**漫画史权威**
   - Bab-ilu 用途：[[wandering-blade]] / [[tactical-feminine]] 等日系条目的理论根基

5. **Steven Heller & Seymour Chwast, *Illustration: A Visual History* (2008)**
   - 跨东西方插画视觉史。Push Pin Studios 创始人写作
   - Bab-ilu 用途：编辑插画 / 海报插画 / 书籍插画的跨文化条目

## 非 canonical 但常用
- Iain McCaig, *Shadowline* 或 *The Skillful Huntsman* (Tang/Khang/Yamada 2005) —— 概念艺术教学权威
- Rodolphe Töpffer, *Essay on Physiognomy* (1845) —— 漫画理论最早文本
- *Illustrators* Annual（Society of Illustrators 年鉴，1959 起）
- *Pictoplasma* 系列 —— 当代 character design
- Andrew Loomis 素描丛书（1940s-50s，仍是人物插画基础）

## 专业档案
- Society of Illustrators (NYC) —— 美国插画权威
- LoC Cabinet of American Illustration —— 见 [[loc_cai]] 字段
- Kyoto International Manga Museum —— 日漫权威
- Grand Comics Database (GCD) —— 漫画书 metadata —— 见 [[gcd_id]]
- Anime News Network Encyclopedia

## 相关
- [[getty-aat]]（插画类型词表）· [[domain-graphic]]（边界重叠 · 海报插画）
- [[ronin-solitary-blade]] / [[kneeling-samurai-petal]] / [[falslander-infantry]]（日系当代条目，母题追到浮世绘武者绘）
