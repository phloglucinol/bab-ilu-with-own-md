---
id: domain-ui
type: source
role: foundation
title: UI · 经典文献书架
format: book
domain: ui
language: en
canonical: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# UI · 5 部 canonical

1. **Ben Shneiderman, *Designing the User Interface* (1986, 6th ed. 2016, 合作 Plaisant/Cohen/Jacobs/Elmqvist/Diakopoulos)**
   - **HCI 领域教科书的 CS 范式权威**。Shneiderman 的"直接操作"原则、"Visual Information-Seeking Mantra"（overview first, zoom and filter, details on demand）
   - Bab-ilu 用途：UI aesthetic 条目的技术根基引用

2. **Alan Cooper, *About Face: The Essentials of Interaction Design* (1995, 4th ed. 2014)**
   - 交互设计的**实务圣经**。persona 方法、Goal-directed Design
   - Bab-ilu 用途：UI 条目的 `[iconological]` 段落——"目标导向"世界观的来源

3. **Edward Tufte, *The Visual Display of Quantitative Information* (1983) + *Envisioning Information* (1990)**
   - 信息可视化权威。data-ink ratio、chartjunk、small multiples
   - Bab-ilu 用途：信息密集型 UI（dashboard、数据产品）条目的理论根基

4. **Bruce Tognazzini, *Tog on Interface* (1992)**
   - 早期 Apple HIG 首席设计师的实战笔记。Fitt's Law、Hick's Law 的 UI 应用
   - Bab-ilu 用途：[[apple-hig-visionos-depth]] 类 Apple 血统条目的历史根基

5. **Jef Raskin, *The Humane Interface* (2000)**
   - Macintosh 原始设计者的激进 UI 批判。"visibility" "monotony" 原则
   - Bab-ilu 用途：批判性 UI 条目、极简哲学条目（如 [[jony-ive-apple-hig]] 的延伸）

## 非 canonical 但常用
- Steve Krug, *Don't Make Me Think*（跨 UI/UX，见 ux.md）
- Apple Human Interface Guidelines（官方文档，持续更新）
- Material Design 官方文档（m3.material.io）
- Fluent 2 设计系统文档（fluent2.microsoft.design）
- MoMA Architecture & Design 藏品数据（含 Xerox Star UI、Mac 原型）

## 相关
- [[moma]]（机构，UI 原型主要藏）· [[cooperhewitt]]（机构，数字设计藏品）· [[domain-ux]]（同源但分道）
