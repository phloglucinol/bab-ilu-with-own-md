---
id: inst-iconclass
type: source
role: foundation
title: Iconclass — 图像学分类系统
format: vocabulary
domain: institution
language: en/nl/de/fr
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q1414406
url: https://iconclass.org/
---

# Iconclass

主题内容分类系统。Leiden 1973 由 Henri van de Waal 创立，作为 Warburg–Panofsky 图像学方法的数字化后裔。回答"这幅画**描绘什么**"，而非"它**是什么**"（AAT 回答后者）。

## URI 格式
- 概念：`https://iconclass.org/{notation}` （如 `https://iconclass.org/71H7131` = Bathsheba 单独持 David 的信）
- JSON API：`https://iconclass.org/{notation}.json`
- Linked Open Data 端点

## Notation 结构
- 十位系统：0=神话 / 1=神/宗教 / 2=自然 / 3=人类 / 4=社会 / 5=抽象概念 / 6=历史 / 7=圣经 / 8=文学 / 9=古典神话
- 字母+数字混合（如 48C11 = pictures of rural landscape with stormy sky）
- 深度分级：顶级分类 → 三位子分类 → 字母修饰 → 数字细分

## Bab-ilu 用途（核心）
- `iconclass` frontmatter 字段的权威来源（v1.4 加入）
- 覆盖 AAT 覆盖不到的主题维度
- **对 `painting` / `illustration` / `photo` 域的叙事性作品必填**
- 对纯抽象 / UI / 游戏艺术可以 null，不违反硬规则

## 与 AAT 互补
| 维度 | AAT | Iconclass |
|---|---|---|
| 是什么材料 | ✅ | ❌ |
| 什么风格时期 | ✅ | ❌ |
| 描绘什么主题 | ❌ | ✅ |
| 什么图像学原型 | ❌ | ✅ |

## 覆盖使用
- Rijksmuseum、Prado、KHM Vienna、British Museum catalogue 全部使用 Iconclass 编码
- Bab-ilu 引用 Iconclass 时，可反向找到这些博物馆的相关藏品

## 引用格式
学术溯源段：`Iconclass: [71H7131](https://iconclass.org/71H7131) — Bathsheba alone with David's letter`
