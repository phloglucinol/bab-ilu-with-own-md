---
id: inst-nng
type: source
role: foundation
title: Nielsen Norman Group Research Library
format: archive
domain: institution
language: en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q6991929
url: https://www.nngroup.com/articles/
---

# Nielsen Norman Group (NN/g)

Jakob Nielsen + Don Norman 1998 创立的 UX 研究公司。**UX 域的事实权威**。每篇研究文章有稳定 URL，可作为 Bab-ilu UX aesthetic 条目的学术锚点。

## URI 格式
- 文章：`https://www.nngroup.com/articles/{slug}/`
- 报告（付费）：`https://www.nngroup.com/reports/{slug}/`

## Bab-ilu 用途
- `nng_url` frontmatter 字段（UX 域的主要 authority 字段）
- 对 UX 条目的三大核心引用：
  1. **10 Usability Heuristics**（1990 Nielsen/Molich, NN/g 1994 修订版）— https://www.nngroup.com/articles/ten-usability-heuristics/
  2. **NN/g UX Research Methods**（量化与定性方法论）
  3. **Interaction Design Foundation** 互补（更学院派）

## 10 启发式（Bab-ilu UX aesthetic 条目的评价骨架）
1. Visibility of system status
2. Match between system and the real world
3. User control and freedom
4. Consistency and standards
5. Error prevention
6. Recognition rather than recall
7. Flexibility and efficiency of use
8. Aesthetic and minimalist design
9. Help users recognize, diagnose, and recover from errors
10. Help and documentation

**Bab-ilu UX prompt skeleton（schema §5.4.2）要求 `[iconological]` 段至少引用其中一条。**

## 与 ISO 9241 的关系
- NN/g 10 启发式是**实践层面**的 UX 评价标准
- ISO 9241-210（Human-centred design, 2019）是**过程层面**的标准
- 两者互补，Bab-ilu UX 条目应同时引用：`iso_standard: "9241-210:2019"` + `nng_url: "..."`

## 引用格式
学术溯源段：`NN/g: [*10 Usability Heuristics for UI Design*](https://www.nngroup.com/articles/ten-usability-heuristics/) · ISO 9241-210:2019`
