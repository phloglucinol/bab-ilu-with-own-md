---
id: inst-cooperhewitt
type: source
role: foundation
title: Cooper Hewitt Collection API
format: archive
domain: institution
language: en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q725000
url: https://collection.cooperhewitt.org/
---

# Cooper Hewitt, Smithsonian Design Museum

国家设计博物馆（美国），215,000+ 对象，全 CC0。**平面设计与工业设计的权威档案**。

## URI 格式
- 对象：`https://collection.cooperhewitt.org/objects/{id}/`
- REST API：`https://api.collection.cooperhewitt.org/`
- GraphQL：`https://collection.cooperhewitt.org/graphql`
- GitHub：https://github.com/cooperhewitt/collection

## Bab-ilu 用途
- `cooperhewitt_id` frontmatter 字段
- **平面设计（graphic domain）的首选 institution**
- 排版样本、海报、产品设计、图形识别系统档案
- 附属 Herb Lubalin Study Center 研究平面设计专项

## 覆盖强项
- 海报设计（大量 Müller-Brockmann / Rand / Brodovitch / AIGA 获奖作品）
- 产品设计（工业革命到当代）
- 壁纸、纺织、珠宝（丰厚的装饰艺术）

## 与 MoMA 的分工
- MoMA 更当代、更美术化；Cooper Hewitt 更工业、更设计史
- 字体样本：首选 Cooper Hewitt
- 产品原型：Cooper Hewitt 与 MoMA 互补

## 引用格式
学术溯源段：`Cooper Hewitt: [Müller-Brockmann poster](https://collection.cooperhewitt.org/objects/18618937/) (cooperhewitt:18618937)`
