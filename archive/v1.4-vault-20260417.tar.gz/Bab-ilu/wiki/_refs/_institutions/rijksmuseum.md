---
id: inst-rijksmuseum
type: source
role: foundation
title: Rijksmuseum API
format: archive
domain: institution
language: nl/en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q190804
url: https://www.rijksmuseum.nl/en/rijksstudio
---

# Rijksmuseum

阿姆斯特丹国立博物馆。荷兰黄金时代绘画权威馆藏（Rembrandt, Vermeer, Hals, Ruisdael）。所有对象高清 CC0，支持 IIIF。**对 `painting` 域尤其重要**——且每对象都标注 Iconclass。

## URI 格式
- 对象：`https://www.rijksmuseum.nl/en/collection/{accession}` （如 SK-C-5 = *The Night Watch*）
- JSON API：`https://www.rijksmuseum.nl/api/en/collection/{accession}?key=<API_KEY>`
- Rijksstudio 用户可免费申请 API key

## Bab-ilu 用途
- `rijks_id` frontmatter 字段
- **painting 域首选——尤其 17 世纪北方绘画**
- 每对象自带 Iconclass notation → 可直接反向填充 `iconclass` 字段
- IIIF 高分图像可嵌入 Aesthetic MD

## 覆盖强项
- 荷兰黄金时代绘画（全世界最全）
- Delft 学派（Vermeer 重点）
- Rembrandt 单人超过 100 件
- 早期摄影、印刷、家具

## 关键映射
- `iconclass` 字段填充：Rijks API `iconography` 属性直接给标准 Iconclass notation
- `wikidata` 字段填充：大多数标志性作品都有 Q

## 引用格式
学术溯源段：`Rijksmuseum: [Vermeer, *The Milkmaid*](https://www.rijksmuseum.nl/en/collection/SK-A-2344) (rijks:SK-A-2344) · Iconclass: [41C32(+25)](https://iconclass.org/41C32)`
