---
id: inst-getty-aat
type: source
role: foundation
title: Getty Art & Architecture Thesaurus (AAT)
format: vocabulary
domain: institution
language: en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q740134
url: http://vocab.getty.edu/aat/
---

# Getty AAT

受控词表，约 55,000 概念，跨七大 facet（Associated Concepts / Physical Attributes / Styles and Periods / Agents / Activities / Materials / Objects）。1990 至今由 Getty Research Institute 维护。

## URI 格式
- 概念：`http://vocab.getty.edu/aat/{id}`（如 `http://vocab.getty.edu/aat/300015650`）
- SPARQL 端点：`http://vocab.getty.edu/sparql`
- Linked Open Data：全 CC0

## Bab-ilu 用途
- `aat_id` frontmatter 字段的权威来源
- "风格/时期"类查询首选（Style and Period facet）
- 生成 prompt 时的词汇锚点——generation 模型训练集含大量 AAT 术语，引用提升输出具体性

## 覆盖边界
- ✅ 风格（Brutalism, Minimalism）、材料（cadmium red, tempera）、物理属性（impasto, chiaroscuro）
- ❌ 主题内容（"David 与 Goliath"、"Nativity"）——用 [[iconclass]]
- ❌ 艺术家实体——用 Getty ULAN（`ulan_id`）

## 引用格式
Aesthetic MD 学术溯源段：`Getty AAT: [aat:300015650](http://vocab.getty.edu/aat/300015650) — <hierarchy path>`
