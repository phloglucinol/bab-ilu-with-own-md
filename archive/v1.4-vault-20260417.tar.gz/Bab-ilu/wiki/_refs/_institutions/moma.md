---
id: inst-moma
type: source
role: foundation
title: Museum of Modern Art Collection Dataset
format: archive
domain: institution
language: en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q188740
url: https://www.moma.org/collection/
---

# MoMA Collection

纽约现代艺术博物馆，现代 / 当代艺术权威。80,000+ 对象公开数据。包含绘画、摄影、设计、建筑模型、电影、视频游戏（2012 起）。

## URI 格式
- 对象页面：`https://www.moma.org/collection/works/{id}`
- CSV dump：https://github.com/MuseumofModernArt/collection （Zenodo DOI: 10.5281/zenodo.266290）
- OAuth REST API：https://api.moma.org/Help

## Bab-ilu 用途
- `moma_id` frontmatter 字段
- **最重要：现代设计与 UI 历史**——Mac System 1 原始文件、Dieter Rams 原型、Braun 产品、Ive 时期 Apple 产品都在收藏
- 当代摄影（Szarkowski 遗产）
- 视频游戏收藏（2012 起，`shadow-of-colossus` / `journey` / `ico` 等 40+ 条目）

## 覆盖强项
- 20 世纪起的几乎所有主要运动
- Architecture & Design 部门独立运营（Ellen Lupton 等策展）
- Photography 部门由 Szarkowski 奠定方向

## 常用字段
- `Title` · `Artist` · `Date` · `Medium` · `Classification` · `Department` · `URL` · `ThumbnailURL` · `OnView`
- 每对象映射到 Wikidata Q 与 AAT 概念（部分）

## 引用格式
学术溯源段：`MoMA: [Rams, *606 Universal Shelving System*](https://www.moma.org/collection/works/78646) (moma:78646)`
