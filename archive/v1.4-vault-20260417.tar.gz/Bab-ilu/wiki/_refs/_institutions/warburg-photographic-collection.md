---
id: inst-warburg-photographic-collection
type: source
role: foundation
title: Warburg Institute Photographic Collection
format: archive
domain: institution
language: en/de
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q1498530
url: https://warburg.sas.ac.uk/collections/photographic-collection
---

# Warburg Institute Photographic Collection

伦敦大学 Warburg Institute 的**图像档案**（~400,000 张照片、明信片、复制品），**直接继承 Aby Warburg 在汉堡 1909-1925 建立的图像学档案**。按图像学主题分类，而非按艺术家——这就是 Bab-ilu 的 `wiki/_panels/` 的组织方式的直接祖先。

## URI 格式
- 搜索：https://iconographic.warburg.sas.ac.uk
- 每图像有 Warburg catalog number（传统格式）
- Linked Open Data 正在推进（PHAROS 联盟成员）

## Bab-ilu 用途
- **Bab-ilu 理论骨架的实体馆藏对应物**
- `wiki/_panels/` 组织原理的文献证据
- 学术溯源段引用："Warburg Photographic Collection, folder [主题名]"——证明某个 Pathosformel 在 Warburg 自己的档案里确有一组照片

## 与 PHAROS 联盟
PHAROS = 14 个欧美照片档案馆联盟（Warburg + Frick + Fondazione Zeri + KHI Florence + 其他）。共享图像学元数据。

## 引用格式
学术溯源段：`Warburg Photographic Collection: folder *Pathos of the Wanderer* (sublime-solitude 面板的实体档案对应) · PHAROS consortium`

## 重要度
这个 institution 不是"可选"——它是 Bab-ilu 项目身份的**物理证据锚点**。每个重要 Warburg panel 的学术溯源都应尝试引用此 collection 的对应 folder 或 theme，证明 Bab-ilu 的跨时代主题组织有百年学术档案传统支持。
