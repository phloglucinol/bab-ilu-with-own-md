---
id: inst-wikidata
type: source
role: foundation
title: Wikidata
format: vocabulary
domain: institution
language: multilingual
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q2013
url: https://www.wikidata.org/
---

# Wikidata

协作维护的 Linked Open Data 知识库。~1 亿 Q 标识符，覆盖所有领域实体。每个实体有稳定 URI、多语言标签、语义属性。Wikipedia 的底层数据源。

## URI 格式
- 实体：`https://www.wikidata.org/wiki/Q<id>` （如 Q4692 = Bauhaus）
- SPARQL 端点：`https://query.wikidata.org/`
- 全 CC0

## Bab-ilu 用途
- `wikidata` frontmatter 字段的权威来源
- 作为"Linked Open Data 中枢"——Wikidata Q-ID 通常反向映射到 Getty AAT / Iconclass / 各博物馆 ID
- 多语言标签自动解析（`original_terms` 字段的跨语种对齐）

## 覆盖边界
- ✅ 几乎所有有名之物：艺术运动、作品、艺术家、概念、电影、游戏、UI 系统
- ⚠ 专业深度不及 AAT / Iconclass——Wikidata 标签多样但不规范
- ⚠ 对小众当代艺术家覆盖稀疏；遇到无 Q-ID 的当代作品应 null + 尝试 ULAN / institution ID

## 常用属性
- P31 = instance of（分类）
- P136 = genre
- P170 = creator
- P276 = location
- P2092 = BBF (British Film Institute) ID
- P7818 = Getty AAT ID （直接反向映射）

## 引用格式
学术溯源段：`Wikidata: [Q4692](https://www.wikidata.org/wiki/Q4692)`
