---
id: inst-metmuseum
type: source
role: foundation
title: The Metropolitan Museum of Art Collection API
format: archive
domain: institution
language: en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q160236
url: https://metmuseum.github.io/
---

# Met Collection API

纽约大都会艺术博物馆公开 API，470,000+ 对象，CC0，**无需认证**。

## URI 格式
- 对象：`https://collectionapi.metmuseum.org/public/collection/v1/objects/{id}` （如 436535 = Vermeer 《Young Woman with a Water Pitcher》）
- 搜索：`https://collectionapi.metmuseum.org/public/collection/v1/search?q=<query>`
- GitHub 开放数据 dump：https://github.com/metmuseum/openaccess

## Bab-ilu 用途
- `met_id` frontmatter 字段
- painting / sculpture / decorative arts / photography 条目的高质量引用源
- 每个 object 带 IIIF 兼容的高分辨率图像 URL（可嵌入 Aesthetic MD 的 `## Visual evidence` 段落）

## 覆盖强项
- 欧洲绘画（Renaissance 到 19 世纪）非常强
- 美国艺术旗舰馆藏
- 伊斯兰艺术 / 亚洲艺术优秀覆盖
- 摄影 collection 与 MoMA 并列第一梯队

## 常用字段
- `objectID` · `title` · `artistDisplayName` · `objectDate` · `medium` · `primaryImage` · `primaryImageSmall` · `classification` · `department`
- 可映射到 `ulan_id` / `aat_id` / `iconclass`

## 引用格式
学术溯源段：`Met: [Vermeer, *Young Woman with a Water Pitcher*](https://www.metmuseum.org/art/collection/search/436535) (met:436535)`
