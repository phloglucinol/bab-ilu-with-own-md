---
id: inst-bfi
type: source
role: foundation
title: British Film Institute Collections
format: archive
domain: institution
language: en
canonical: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
wikidata: Q1049178
url: https://collections-search.bfi.org.uk/web
---

# BFI Collections

英国电影协会，1933 起连续运营的电影档案。世界上最大的公共电影档案之一。独立于 IMDb 的**学术级**电影元数据来源。

## URI 格式
- 搜索：`https://collections-search.bfi.org.uk/web/search/all/keyword/{query}`
- 每个 title 有稳定 record ID
- SIFT（Summary of Information on Film and Television）数据库是核心

## Bab-ilu 用途
- `bfi_id` frontmatter 字段（cinema 域）
- **BFI Film Classics / Modern Classics 专论丛书**（150+ 卷，每卷一部经典电影单独作为一本专著）是 Bab-ilu cinema aesthetic 条目的理想引用
  - 如：Redmond *Blade Runner 2049* (BFI Film Classics 2023)

## 覆盖强项
- 英国电影史第一档案
- 早期电影（前 1920）全欧洲第一梯队
- 世界电影的跨国索引（与 FIAF 协作）

## 配套词表
- FIAF Moving Image Cataloguing Manual 是 BFI 的词表骨干（参见 [[fiaf-standard]]，待写）
- EN 15907 欧盟电影元数据标准

## 引用格式
学术溯源段：`BFI: [*Blade Runner 2049*](https://collections-search.bfi.org.uk/web/record/...) (bfi:150073977) · BFI Film Classics: Redmond 2023`

## Reuben Library
BFI 还运营 Reuben Library（伦敦 Southbank），6 万+ 电影相关图书 / 5 万+ 期刊卷，对 Bab-ilu 深度考据条目有纸本末端。
