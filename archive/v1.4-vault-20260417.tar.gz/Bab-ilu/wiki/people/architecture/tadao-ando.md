---
id: tadao-ando
type: person
title: Tadao Ando
aliases: [安藤忠雄]
role: architect
wikidata: "Q190368"
aat_id: "300024983"
domain: architecture
signature_traits:
  - "Unadorned smooth concrete (混凝土清水模) as primary material"
  - "Controlled natural light via precisely cut openings treated sculpturally"
  - "Geometric primary forms (cube, cylinder, circle) in strict orthogonal or radial composition"
  - "Landscape and architecture as continuous experiential sequence"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[geometric-silence]]}
---

# Tadao Ando

## 认知钩子

Ando 的 smooth concrete + directed light 是功能主义几何在 1970s 之后最纯粹的建筑实例之一。他把 Le Corbusier 的混凝土使用传到东亚语境,结合日本传统对光、阴影、时间的感知(参考谷崎润一郎《阴翳礼赞》),形成一种**建筑几何沉默 × 日本诗学**的独特综合。

## 作为 reference library 成员的价值

taste-lineage subagent 识别以下特征时应参考 Ando:
- 大面积清水混凝土墙面
- 精密切割的几何开口(十字光、缝光、圆光)作为光的雕塑器
- 严格正交或放射几何
- 建筑与庭院/水体/山坡的连续序列

## 核心作品

- Church of the Light (光之教堂, 1989) — 十字光切口
- Row House in Sumiyoshi (1976) — 早期代表作
- Water Temple (水御堂, 1991)
- Chichu Art Museum (地中美术馆, 2004) — 直岛
- Benesse House (1992) — 直岛综合体

## 作为 Pathosformel 承载者

Ando 参与 [[geometric-silence]] Pathosformel 的**日本现代主义分支**:

- 上溯:Le Corbusier 混凝土 + Bauhaus 几何
- 同代:Mies van der Rohe(但 Ando 比 Mies 多一层材料温度)
- 东亚同代:丹下健三(但 Tange 更巨构,Ando 更内省)
- 后续:SANAA(但 SANAA 更轻盈抽象;Ando 更厚重物质)

他的价值在于证明**几何沉默**可以在非西方文化语境中独立成立——不是复制 Bauhaus,是用日本的阴翳传统重新解释功能主义。

## 学术外部锚

- Wikidata: [Q190368](https://www.wikidata.org/wiki/Q190368)
- Pritzker Prize 1995
- 核心文本:Kenneth Frampton 论 Ando(《Modern Architecture: A Critical History》相关章节);Ando 自传《建築家 安藤忠雄》(2008)
