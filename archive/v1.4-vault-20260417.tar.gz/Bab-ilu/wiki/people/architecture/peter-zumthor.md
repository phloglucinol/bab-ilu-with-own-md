---
id: peter-zumthor
type: person
title: Peter Zumthor
aliases: []
role: architect
wikidata: "Q160432"
aat_id: "300024983"
domain: architecture
signature_traits:
  - "Material honesty — single material extended to its expressive limit per project"
  - "Acoustic and atmospheric design treated as primary architectural concern"
  - "Slow reveal sequences — buildings unfold as experiential duration, not object"
  - "Small-scale work refusing parametric / digital fabrication aesthetics"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations: []
---

# Peter Zumthor

## 认知钩子

Zumthor 每一个项目选择**一种主材料**,并推到表达极限——Therme Vals 的当地片岩、Bruder Klaus Field Chapel 的内部烧蚀松木、Kolumba Museum 的定制长砖——建筑不是形式练习,是**材料与空间的共同现象学**。他把"氛围"(atmosphere)当作可设计对象,不是玄学。

## 作为 reference library 成员的价值

taste-lineage subagent 识别以下特征时应参考 Zumthor:
- 单一材料推到极限的空间
- 光作为材料而非装饰
- 小尺度项目但有史诗时间感
- 现象学氛围主导而非几何形式主导

## 核心作品

- Therme Vals (1996) — 温泉浴场,瑞士格劳宾登片岩
- Bruder Klaus Field Chapel (2007) — 德国田间小教堂,火烧木模板
- Kolumba Museum (2007) — 科隆,长砖叠加战后废墟
- Pavilion Zumthor (Serpentine 2011) — 黑色冥思花园

## 作为 Pathosformel 承载者

Zumthor 的工作横跨两条 Pathosformel:
1. [[geometric-silence]] — 极简几何 + 功能主义克制
2. [[sublime-solitude]] — 小尺度空间中的崇高感(Bruder Klaus Chapel 尤其如此)

他是理解"小而崇高"的关键个案——不是靠规模达到崇高,而是靠**材料深度 + 光 + 时间**。

## 学术外部锚

- Wikidata: [Q160432](https://www.wikidata.org/wiki/Q160432)
- Getty AAT:[aat:300024983](http://vocab.getty.edu/aat/300024983) — architects
- Pritzker Prize 2009
- 核心文本:Zumthor, *Thinking Architecture* (1999) / *Atmospheres* (2006)
