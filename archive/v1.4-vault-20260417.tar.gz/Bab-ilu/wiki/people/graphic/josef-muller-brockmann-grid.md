---
id: josef-muller-brockmann-grid
type: person
title: Josef Müller-Brockmann
aliases: [JMB]
role: graphic_designer
wikidata: "Q1708075"
domain: graphic
signature_traits:
  - "Grid as moral discipline — not a tool but an ethics of communication"
  - "Akzidenz-Grotesk typography in rigorous weight hierarchy"
  - "Red/black/white palette with photographic image discipline"
  - "Asymmetric composition anchored by geometric logic"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[swiss-international-style]]}
---

# Josef Müller-Brockmann

## 认知钩子

Müller-Brockmann 的 *Grid Systems in Graphic Design* (1961) 不是"教如何用网格",是**把设计重定义为伦理**:栅格是对设计师随意性的约束,让作品变成可测量、可复制、可批评的对象。这个立场使瑞士风格在 1950s–70s 成为国际信息传达的标准。

## 作为 reference library 成员的价值

taste-lineage subagent 识别以下特征时应参考 Müller-Brockmann:
- 严格 12 或 16 列栅格可见或潜在存在
- 非衬线字体(尤其是 Akzidenz-Grotesk、Helvetica)的体重对比
- 非对称布局但整体几何平衡
- 红/黑/白 三色调性,图像做硬裁切对齐网格

## 关键作品

- *Grid Systems in Graphic Design* (1961) — 教科书化
- Zurich Tonhalle Concert Series 海报 (1950s–60s) — 瑞士风格的完美实例化
- Olivetti 委托作品
- *Der Film* 展览海报 (1960)

## 作为 Pathosformel 承载者

Müller-Brockmann 不是发明栅格(栅格在 Gutenberg 排版和 Bauhaus 已存在),而是**把栅格理论化、可教化、可传承**。这让他成为 [[geometric-silence]] Pathosformel 在平面设计领域的关键传承者——从 Jan Tschichold 的新印刷术、Bauhaus 到 Rams、再到数字时代的 Apple HIG / Material Design,Müller-Brockmann 是中继点。

## 学术外部锚

- Wikidata: [Q1708075](https://www.wikidata.org/wiki/Q1708075)
- 核心文本:Müller-Brockmann, *Grid Systems in Graphic Design* (1961) / *Grafische Gestaltung* (1971)
- 研究文本:Kerry William Purcell, *Josef Müller-Brockmann* (Phaidon, 2006)
