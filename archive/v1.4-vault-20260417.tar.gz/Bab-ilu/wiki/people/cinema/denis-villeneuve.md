---
id: denis-villeneuve
type: person
title: Denis Villeneuve
aliases: []
role: director
wikidata: "Q193078"
domain: cinema
signature_traits:
  - "Monumental scale with human intimacy coexisting within a single frame"
  - "Slow narrative pace, extended scene durations, careful use of silence"
  - "Architectural attention to space — frames as inhabitable environments"
  - "Collaboration with Roger Deakins as signature visual partnership"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: frames, target: [[blade-runner-2049-orange-sublime]]}
---

# Denis Villeneuve

## 认知钩子

Villeneuve 是当代美国-加拿大商业电影中最一贯参与 [[sublime-solitude]] Pathosformel 的导演。*Arrival* (2016) 的雾中外星飞船、*Blade Runner 2049* (2017) 的橙色废墟、*Dune* (2021) / *Dune Part Two* (2024) 的沙漠——每一部都把"小人物立于吞没性世界"这个德国浪漫主义公式现代化地重做一次。

## 作为 reference library 成员的价值

taste-lineage subagent 识别以下特征时应参考 Villeneuve:
- 巨大尺度物体(飞船、城市、沙虫、建筑)与单一人物共画面
- 静默长镜头
- 大气感(沙尘、雾、光粒子)
- Hans Zimmer / Jóhann Jóhannsson 类低频冥想性配乐

## 关键作品

- *Incendies* (2010) — 早期作
- *Prisoners* (2013) —— 与 Deakins 首次合作
- *Sicario* (2015) —— 沙漠边境
- *Arrival* (2016)
- *Blade Runner 2049* (2017)
- *Dune* (2021)
- *Dune: Part Two* (2024)

## 作为 Pathosformel 承载者

Villeneuve 不原创 Pathosformel,但他**系统性地把崇高公式纳入商业叙事电影**——这是一个值得单独研究的工业现象。1970s 以来,崇高在商业影院几乎消失(Spielberg 的惊奇是乐观的,诺兰的规模是工程的),Villeneuve 把 Tarkovsky-Deakins 血统重新带回宽银幕。

## 学术外部锚

- Wikidata: [Q193078](https://www.wikidata.org/wiki/Q193078)
- 与 Roger Deakins 合作:Prisoners (2013), Sicario (2015), Blade Runner 2049 (2017)
- 与 Greig Fraser 合作:Dune (2021), Dune Part Two (2024)
