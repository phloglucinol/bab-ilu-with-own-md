---
id: andrei-tarkovsky
type: person
title: Andrei Tarkovsky
aliases: [Андрей Тарковский, Tarkovsky]
role: director
wikidata: "Q46599"
domain: cinema
signature_traits:
  - "Long takes with imperceptible camera motion"
  - "Time as sculptural material (Tarkovsky's own term: 'sculpting in time')"
  - "Natural elements (water, fire, earth, fog) as metaphysical presences, not decoration"
  - "Human figure dissolving into landscape"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
  - {type: inspired_by, target: [[caspar-david-friedrich-wanderer]]}
---

# Andrei Tarkovsky

## 认知钩子

Tarkovsky 把电影时间变成**形而上学的物质**:长镜头不是节奏选择,是让观众与画面一起经历"存在本身"的技术。他的孤身人物几乎总是立于吞没性的自然/废墟之前——这是 19 世纪德国浪漫主义崇高公式在东欧形而上学语境里的再现。

## 作为 reference library 成员的价值

taste-lineage subagent 在识别以下特征的视觉时应参考 Tarkovsky:
- 极长的时间感(即使画面是静态的也要"慢")
- 水、雾、火的物质性渲染
- 人物与自然/废墟边界的溶解
- 形而上学诗性而非情节叙事的空间

## 关键作品

- *Ivan's Childhood* (1962) — 战争废墟中的童年
- *Andrei Rublev* (1966) — 中世纪俄罗斯画家,七段式诗性叙事
- *Solaris* (1972) — 宇宙意识与记忆
- *Mirror* (1975) — 时间与记忆的非线性拼贴
- *Stalker* (1979) — Zone 禁区,崇高公式的经典变体
- *Nostalghia* (1983) — 流亡与时间
- *The Sacrifice* (1986) — 末日祭献

## 作为 Pathosformel 承载者

Tarkovsky 是 Friedrich → 当代电影的一条直接血统。他本人大量引用德国浪漫主义绘画(Friedrich、Böcklin),并把这些图像公式在胶片时间上扩展。

从 Warburg 角度看,Tarkovsky 的价值在于:他证明了**同一 Pathosformel 在视觉媒介内跨时代可传递**——不是靠拷贝图像,而是靠保持公式的结构要素(人形小 / 自然吞没 / 大气感 / 观看者借人物视角)同时让材料层面完全不同(油画 vs 彩色胶片,静态 vs 长镜头)。

## 学术外部锚

- Wikidata: [Q46599](https://www.wikidata.org/wiki/Q46599)
- Getty AAT 相关:Soviet cinema (aat 等级中)
- 核心文本:Tarkovsky, *Sculpting in Time* (1986) — 导演本人的美学自述
