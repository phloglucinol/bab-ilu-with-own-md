---
id: roger-deakins
type: person
title: Roger Deakins
aliases: [Sir Roger Deakins, R. Deakins]
role: cinematographer
wikidata: "Q362639"
domain: cinema
notable_collaborations: [coen-brothers, sam-mendes, denis-villeneuve]
signature_traits:
  - "Wide anamorphic compositions with shallow center-of-frame subjects"
  - "Monochromatic atmospheric palettes that collapse foreground/background into unified mood"
  - "Hard horizon-as-divider layouts with radical negative space"
  - "Natural-seeming light with extremely controlled direction"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: frames, target: [[blade-runner-2049-orange-sublime]]}
  - {type: exemplifies, target: [[sublime-solitude]]}
---

# Roger Deakins

## 认知钩子

Deakins 的摄影语言:**把极少的视觉元素置于被大气统一的浩渺空间,让光成为叙事的主角**。他的作品反复落入"孤身崇高"(sublime solitude) Pathosformel——《1917》战壕、《老无所依》沙漠、《刺杀神枪侠》雪原、《银翼杀手 2049》橙色废墟。

## 作为 reference library 成员的价值

taste-lineage subagent 在识别具有以下特征的视觉时应优先参考 Deakins:
- 单色主导的宽幅画面
- 人物占画面极小比例的构图
- 大气感压过细节的深度渲染
- 自然感强但方向性极精准的光

## 合作脉络

- Coen Brothers(*No Country for Old Men* 2007, *True Grit* 2010, *Inside Llewyn Davis* 2013)
- Sam Mendes(*Skyfall* 2012, *1917* 2019)
- Denis Villeneuve(*Prisoners* 2013, *Sicario* 2015, *Blade Runner 2049* 2017)

## 作为 Pathosformel 承载者

Deakins 不发明 Pathosformel,他**现代化地物质化**已存在的视觉公式。他的贡献在于用当代数字工具(ACES 色彩管理、广色域投影、大气粒子模拟)重做 Friedrich-Ford-Tarkovsky 传统已经建立的形式任务。

这让 Deakins 成为研究 Nachleben 机制的理想个案:**你能看到 19 世纪油画逻辑在 21 世纪 IMAX 胶片-数字管线上重新成立**。

## 学术外部锚

- Wikidata: [Q362639](https://www.wikidata.org/wiki/Q362639)
- Getty AAT 相关父概念:Cinematography (aat:300139140)
- 学术研究推荐:Stephen Pizzello, *Deakins on Deakins* (ASC Magazine 系列访谈)
