---
id: andreas-gursky
type: person
title: Andreas Gursky
aliases: []
role: photographer
wikidata: "Q57272"
domain: photo
signature_traits:
  - "Large-format photography (often 6×9+ meters printed)"
  - "Digital compositing of multiple viewpoints into a single hyper-resolved image"
  - "Human scale suppressed by architectural / industrial vastness"
  - "Aestheticization of late-capitalist spectacle (stock exchanges, raves, logistics centers)"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: stable
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations:
  - {type: exemplifies, target: [[sublime-solitude]]}
---

# Andreas Gursky

## 认知钩子

Gursky 用 6×9 米级数字拼合照片把晚期资本主义的**规模本身**变成视觉对象——99 Cent 超市、芝加哥期货交易所、莱茵河岸、Rave 派对——每张照片像"现代崇高",但不是自然崇高而是**基础设施崇高**。

## 作为 reference library 成员的价值

taste-lineage subagent 识别以下特征时应参考 Gursky:
- 极高分辨率 / 极大画幅的工业 / 基础设施 / 大规模人群场景
- 消除中心焦点的平均构图——整张图每处都同样"重要"
- 人物作为规模参照物出现,不作为情感主体
- 消色差、冷静、分析性的色彩

## 核心作品

- 99 Cent (1999)
- Rhein II (1999) — 一度是世界最贵照片
- Chicago Board of Trade (1999)
- May Day IV (2000)
- Bahrain I (2005)

## 作为 Pathosformel 承载者

Gursky 参与 [[sublime-solitude]] Pathosformel 的**基础设施变体**——人类在自己建造的无限基础设施中变得渺小。这条血统:

- Bernd and Hilla Becher(Gursky 的老师,Düsseldorf 学派,工业塔水塔"类型学")
- Ed Burtynsky(景观改造)
- Edward Hopper(前摄影时代,建筑尺度的孤独)
- 上溯至 Caspar David Friedrich 自然崇高公式的当代后世

Gursky 的贡献在于把 19 世纪自然崇高的**视觉任务**迁移到 21 世纪基础设施领域,材料层面完全重做(油画→超高分辨率数字拼合),结构层面保留——这是典型 Warburg Nachleben。

## 学术外部锚

- Wikidata: [Q57272](https://www.wikidata.org/wiki/Q57272)
- 所属传统:Düsseldorf School of Photography
- 核心文本:Peter Galassi, *Andreas Gursky* (MoMA catalogue, 2001)
