---
id: henri-cartier-bresson
type: person
title: Henri Cartier-Bresson
aliases: [HCB, Cartier-Bresson]
role: photographer
wikidata: "Q170042"
aat_id: "300265007"
domain: photo
signature_traits:
  - "The decisive moment (l'instant décisif) — geometry + narrative + gesture coinciding for 1/125th of a second"
  - "Leica 35mm handheld, natural light, never cropped in post"
  - "Geometry under street chaos — triangles, diagonals, echoes of form across frame"
  - "Human-scale framing, never aestheticizing distance"
language: zh
created: "2026-04-16"
updated: "2026-04-16"
freshness_class: evergreen
confidence: 0.95
last_validated: "2026-04-16"
schema_version: "1.4.0"
relations: []
---

# Henri Cartier-Bresson

## 认知钩子

**决定性瞬间**(le moment décisif):一张照片成立,当场景的几何结构、人物姿态、叙事含义在同一瞬间对齐——这个瞬间几乎无法预测,只能通过长期训练后让手指在那 1/125 秒按下快门。HCB 把摄影定义为**预判的艺术**,而非构图的艺术。

## 作为 reference library 成员的价值

taste-lineage subagent 识别以下特征时应参考 HCB:
- 人物姿态与背景几何形成紧张关系的街头构图
- 未经裁切的 3:2 Leica 画幅
- 自然光、黑白、中灰地带丰富
- 瞬间性明确但非摆拍——"时间晶体"感

## 核心作品

- *The Decisive Moment* (1952) 中译《决定性瞬间》
- Behind the Gare Saint-Lazare (1932)
- Seville (1933) 孩子在废墟
- Shanghai Gold Rush (1948)
- Gandhi's funeral (1948)

## 作为 Pathosformel 承载者

HCB 确立了**街头决定性瞬间**这一独立 Pathosformel,区别于同代其他摄影传统(Cartier-Bresson vs Walker Evans 的记录传统 vs Brassaï 的夜景传统 vs Weegee 的犯罪现场)。这个 Pathosformel 的后世出现在:

- Robert Doisneau(1950s 巴黎)
- Garry Winogrand(1960s–70s 美国街头)
- Vivian Maier(1950s 芝加哥)
- Sebastião Salgado(社会纪实转向,但保留几何感)
- 当代手机街拍社区(Instagram "Fr2day" 等)

## 学术外部锚

- Wikidata: [Q170042](https://www.wikidata.org/wiki/Q170042)
- Getty AAT 人物条目:[aat:300265007](http://vocab.getty.edu/aat/300265007)
- Magnum Photos 共同创始人(1947)
- 核心文本:Cartier-Bresson, *The Mind's Eye* (1999)
