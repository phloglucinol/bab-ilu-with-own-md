---
id: wiki-log
type: concept
role: foundation
title: Bab-ilu Wiki Activity Log
description: Append-only human-readable chronological record of writes. LLM appends on every successful /ingest, /taste, /distill, /compile, /prompt. Queries (`/ask`) are NOT recorded here — they go to `_log/usage.jsonl` only.
llm_owned: true
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# Wiki Activity Log

> Karpathy primitive: append-only timeline of what entered the vault and when. Human-readable companion to `_log/usage.jsonl`. Most recent entries on top.

Format: `- <YYYY-MM-DD> <action> <input> → <outcome>`

Reserved actions: `/ingest` `/taste` `/distill` `/compile` `/prompt` `/check --migrate` `/genesis`.

---

## 2026-04-16

- 2026-04-16 `/check --migrate` v1.4 full — PRD/CLAUDE/schema synced; 35 aesthetic cards across 9 domains; 22 authoritative refs; 8 person entries migrated to `wiki/people/{domain}/`; backward-compat symlinks active for 30 days. Domain counts after migration: cinema 4 · graphic 2 · ui 5 · ux 5 · painting 5 · photo 1 · architecture 3 · illustration 5 · game 5.
- 2026-04-16 `/taste` × 13 (v1.4 seed rebalance) — **painting 域**：[[vermeer-milkmaid-interior-light]] · [[turner-light-atmosphere]] · [[cezanne-mont-sainte-victoire-structure]] · [[rothko-color-field-iconoclasm]] · [[friedrich-monk-by-the-sea]] · **ux 域**：[[nng-ten-heuristics]] · [[norman-gulfs-execution-evaluation]] · [[iso-9241-210-hcd-cycle]] · [[cooper-persona-method]] · [[krug-dont-make-me-think]] · **ui 域补**：[[material-expressive-2025]] · [[apple-hig-visionos-depth]] · [[fluent-2-acrylic-mica]] · **architecture 补**：[[brutalism-unite-dhabitation]] · [[postmodern-piazza-ditalia]] · [[parametric-guangzhou-opera]] · **game 补**：[[ico-negative-space-companionship]] · [[breath-of-the-wild-wind-grass]] · [[shadow-of-colossus-scale-sublime]]
- 2026-04-16 `/compile _refs` (v1.4) — 22 权威参考条目落地：`_spine/` 3 · `_institutions/` 10 · `_domains/` 9
- 2026-04-16 `/check --migrate` — 8 person 条目从 `wiki/aesthetics/{domain}/` 迁至 `wiki/people/{domain}/`，30 天 backward-compat symlinks
- 2026-04-16 schema.md bump 1.3.0 → 1.4.0（additive only）—— 加 `iconclass`/`ulan_id`/16 institutional ID 字段 + `ux`+`painting` 域 + `ux_flow`/`painting`/`motion` opt-in 模态 + §11 权威引用硬规则
- 2026-04-16 OmegaWiki 学术基础设施物理落地 —— MCP llm-review 服务器 + 10 Python tools (5,079 LOC) + 33 tests + daily-arxiv cron + `.mcp.json` 注册；18 OmegaWiki skill 拷贝到 `.claude/skills/`（总计 25 skill = 7 Bab-ilu + 18 OmegaWiki）
- 2026-04-16 `/genesis` v1.4 reforge — initialized `wiki/index.md` and `wiki/log.md` (Karpathy primitives). Schema advancing 1.3.0 → 1.4.0.

---

## Prior activity (before v1.4 primitives existed)

Imported from directory mtime scan for historical record. Pre-2026-04-16 activity was not logged here because `log.md` did not exist yet; see `_log/usage.jsonl` for machine record.

- 2026-04-16 `/taste` (v1.3) × 6 — created Warburg panels: [[geometric-silence]], [[wandering-blade]], [[volumetric-light-descent]], [[chromatic-organism]], [[tactical-feminine]], [[sublime-solitude]]
- 2026-04-16 `/taste` (v1.3) × 24 — seeded aesthetic cards across cinema / photo / ui / graphic / game / architecture / illustration domains
- 2026-04-15 `/genesis` (v1.2) — vault scaffold created; `.claude/skills/` + `.claude/agents/` symlinked from `~/code/bab-ilu/`
