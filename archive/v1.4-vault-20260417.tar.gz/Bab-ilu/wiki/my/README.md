---
id: my-notes-index
type: concept
role: foundation
title: 我的笔记(用户命名空间)
author: phoenix
llm_owned: false
created: 2026-04-16
updated: 2026-04-16
schema_version: "1.4.0"
---

# `wiki/my/` —— 你的笔记命名空间

这个目录是**用户专属**。LLM 会读,**不会改**。你在这里写任何东西——观影笔记、设计决策日志、对某张 Aesthetic 的反驳/补充、个人 mood board 思路——都进入知识图谱,`/ask` 能查到,`/cross-link` 会自动链接,但 `/taste`、`/ingest`、`/compile` 等写入 skill **不会覆盖**这里的任何文件。

## 契约

每个你写的 MD 应带 frontmatter:

```yaml
---
type: concept              # 或 idea / question / summary / claim
role: ...                  # 可选:methodology / philosophy / foundation / question
author: phoenix
llm_owned: false           # ← 关键:LLM 不 overwrite
---
```

没有这个字段的文件,`/check` 会在审计时提示添加。

## 什么该写在这里(vs 写在别处)

| 类型 | 位置 |
|------|------|
| 参考图、参考 PDF | `raw/` |
| LLM 分析产出的 Aesthetic 卡 | `wiki/aesthetics/{domain}/` |
| Warburg 面板(LLM 起草,你策展) | `wiki/_panels/` |
| **你自己的观看笔记、想法、补充、异议** | `wiki/my/` ← 这里 |
| 你的 ideation(未验证想法) | `wiki/my/ideas/` |
| 你的决策日志 | `wiki/my/decisions/` |

## 推荐的子结构

```
wiki/my/
├── notes/        # 散装观看笔记
├── ideas/        # 未成熟的 seed/developing ideas
├── decisions/    # 决策日志(ADR 风格)
└── mood-boards/  # 你的 mood board 草稿(与 LLM 合成的 panel 并行)
```

所有这些都和 `wiki/aesthetics/`、`wiki/_panels/` 交叉链接——你的笔记会进入**同一个知识图谱**。
