# raw/images/inbox/

**Auto-populated by the Bab-ilu `ingest-image` hook.**

Every time you paste or attach an image to Claude Code in this project, a `UserPromptSubmit` hook extracts it from the conversation transcript and drops the binary here with filename:

```
YYYYMMDD-HHMMSS-<8charhash>.<ext>
```

## Downstream consumption

- `/taste` — with no path argument, picks the **newest** file in this directory and runs the full aesthetic-archaeology pipeline against it. After a successful run, the source file is optionally moved to `raw/images/processed/{YYYY-MM}/` by `taste-synthesis`, leaving `inbox/` clean.
- `/ingest --panel` — with no argument, processes all current inbox files as one set, producing a Warburg panel synthesis across them.

## Why this exists

Bab-ilu's UX contract: **users only send images; the system handles everything else.** Without this hook, a user pasting an image in chat would have no disk artifact, and `/taste` would have nothing to consume. The hook closes the gap between chat-attached images and the filesystem-as-platform.

## Dedup

The hook hashes image contents and skips re-saving when a matching file already exists in the inbox. Re-pasting the same image is a silent no-op.

## Manual drop

You can also drop image files here manually — `/taste` doesn't care whether a file arrived via hook or manual copy. The filename convention is a suggestion, not a requirement.
