# Demo raw image

This directory holds the demo visual input for Bab-ilu v0.

## Expected file

`blade-runner-2049-las-vegas.jpg` — the orange-dust wasteland frame from *Blade Runner 2049* (2017), dir. Denis Villeneuve, DP Roger Deakins. K walks toward the orange-obscured horizon of post-apocalypse Las Vegas.

This is a reference still for the v0 demo Aesthetic:
- `wiki/aesthetics/cinema/blade-runner-2049-orange-sublime.md`
- `wiki/_panels/sublime-solitude.md`

The file itself is not redistributed in this repo — `raw/` is user-owned. When you clone Bab-ilu, save your own copy of the frame from a legal source into this directory. The demo MD files reference the image by filename; as long as the filename matches, the demo is reproducible.

## Why this image

This frame is a near-ideal demonstration of Warburg Nachleben across media and centuries. Its Pathosformel — the small human before the vast, indifferent landscape — is a 200-year lineage:

- Caspar David Friedrich, *Wanderer above the Sea of Fog* (1818)
- John Ford westerns in Monument Valley (1939–1956)
- Michelangelo Antonioni, *L'Avventura* (1960)
- Andrei Tarkovsky, *Stalker* (1979)
- Denis Villeneuve & Roger Deakins, *Blade Runner 2049* (2017)
- *Dune* (2021)

The v0 demo shows Bab-ilu identifying this Pathosformel, placing it in a Warburg panel, and producing generation prompts that participate in the lineage rather than copying the single frame.
